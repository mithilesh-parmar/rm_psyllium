// Variant C — "New Standard"
// Bold disruptor. Deep green + chalk + warm yellow. Space Grotesk + JetBrains Mono.
// Massive type, asymmetric grids, scroll-driven feel, alternating dark/light slabs.

const C = {
  green: '#0d2818',
  greenDeep: '#081e11',
  greenSoft: '#1a3a25',
  chalk: '#f3efe6',
  chalkBright: '#faf7ee',
  yellow: '#e8c547',
  yellowSoft: '#f0d97a',
  dust: '#c8b89a',
  ink: '#0d1a12',
  rule: 'rgba(243,239,230,0.18)',
  ruleDark: 'rgba(13,40,24,0.18)'
};

const cFont = {
  display: '"Space Grotesk", -apple-system, system-ui, sans-serif',
  body: '"Space Grotesk", -apple-system, system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace'
};

(function ensureCFonts() {
  if (document.getElementById('c-fonts')) return;
  const link = document.createElement('link');
  link.id = 'c-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap';
  document.head.appendChild(link);
})();

function CPlaceholder({ label, h = 360, tone = 'green' }) {
  const stripeColor = tone === 'green' ? 'rgba(243,239,230,0.18)' : 'rgba(13,40,24,0.18)';
  const bg = tone === 'green' ? C.greenSoft : C.dust;
  const fg = tone === 'green' ? 'rgba(243,239,230,0.6)' : 'rgba(13,40,24,0.6)';
  return (
    <div style={{
      width: '100%', height: h, background: bg, position: 'relative', overflow: 'hidden',
      backgroundImage: `repeating-linear-gradient(45deg, ${stripeColor} 0 1px, transparent 1px 16px)`
    }}>
      <div style={{
        position: 'absolute', left: 16, top: 16, fontFamily: cFont.mono, fontSize: 10,
        letterSpacing: '0.18em', textTransform: 'uppercase', color: fg
      }}>{label}</div>
    </div>);

}

function CLogo({ inverted }) {
  const fg = inverted ? C.green : C.chalk;
  const bg = inverted ? C.chalk : C.green;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: 34, height: 34, borderRadius: 8, background: C.yellow, color: C.green,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: cFont.display, fontSize: 16, fontWeight: 700, letterSpacing: '-0.05em'
      }}>RM</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: cFont.display, fontSize: 17, color: fg, fontWeight: 600, letterSpacing: '-0.03em' }}>RM Psyllium</div>
        <div style={{ fontFamily: cFont.mono, fontSize: 9, color: fg, opacity: 0.55, letterSpacing: '0.2em', marginTop: 3 }}>NEW · STANDARD · 2026</div>
      </div>
    </div>);

}

function CNav() {
  const link = { fontFamily: cFont.display, fontSize: 13, color: C.chalk, textDecoration: 'none', fontWeight: 500, letterSpacing: '-0.01em' };
  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '24px 56px', background: C.green, position: 'sticky', top: 0, zIndex: 10
    }}>
      <CLogo />
      <div style={{ display: 'flex', gap: 32 }}>
        {['Products', 'Quality', 'Facility', 'For pharma', 'For food', 'For industry', 'Talk'].map((t) =>
        <a key={t} href="#" style={link}>{t}</a>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 10, color: C.dust, letterSpacing: '0.2em' }}>EN · ES · DE · AR · 中</span>
        <a href="#" style={{
          fontFamily: cFont.display, fontSize: 13, color: C.green, background: C.yellow,
          padding: '10px 16px', borderRadius: 999, textDecoration: 'none', fontWeight: 600, letterSpacing: '-0.01em'
        }}>Book a call →</a>
      </div>
    </nav>);

}

function CHero() {
  return (
    <section style={{
      padding: '64px 56px 80px', background: C.green, color: C.chalk, position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Ticker */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        fontFamily: cFont.mono, fontSize: 11, color: C.dust, letterSpacing: '0.2em',
        textTransform: 'uppercase', marginBottom: 64
      }}>
        <span>◉ &nbsp;Unjha, India · 23°48′N 72°44′E</span>
        <span>2026 sourcing window: <span style={{ color: C.yellow }}>OPEN</span></span>
        <span>Avg. quote in 4 hrs ↘</span>
      </div>

      <h1 style={{
        fontFamily: cFont.display, fontSize: 220, lineHeight: 0.86, color: C.chalk, margin: 0,
        letterSpacing: '-0.06em', fontWeight: 500
      }}>
        The new<br />
        <span style={{ color: C.yellow }}>standard</span> in<br />
        <span style={{ display: 'inline-block', position: 'relative' }}>
          psyllium.
          <span style={{
            position: 'absolute', right: -120, bottom: 20, fontFamily: cFont.mono,
            fontSize: 11, color: C.dust, letterSpacing: '0.16em', fontWeight: 400,
            transform: 'rotate(-4deg)', whiteSpace: 'nowrap'
          }}>↗ from the fields<br />that invented it</span>
        </span>
      </h1>

      <div style={{ marginTop: 72, display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 64, alignItems: 'end' }}>
        <p style={{
          fontFamily: cFont.display, fontSize: 22, color: C.chalk, opacity: 0.85,
          lineHeight: 1.4, margin: 0, maxWidth: 540, fontWeight: 400
        }}>
          We grow, mill and ship pharma-, food- and industrial-grade Psyllium
          from a new 12,000&nbsp;MT facility in Unjha, Gujarat — the village
          where 80% of the world's psyllium has been traded for a century. The
          industry hasn't been disrupted in forty years. We're disrupting it.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 16, color: C.green, background: C.yellow,
            padding: '20px 28px', borderRadius: 999, textDecoration: 'none', fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', letterSpacing: '-0.01em'
          }}>
            Book a 20-min call →
            <span style={{ fontFamily: cFont.mono, fontSize: 11, opacity: 0.65, fontWeight: 500 }}>1 click</span>
          </a>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 16, color: C.chalk,
            padding: '20px 28px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
            border: `1px solid rgba(243,239,230,0.3)`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', letterSpacing: '-0.01em'
          }}>
            Send me the spec PDF
            <span style={{ fontFamily: cFont.mono, fontSize: 11, opacity: 0.6 }}>2.4 MB</span>
          </a>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 16, color: C.chalk,
            padding: '20px 28px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
            border: `1px solid rgba(243,239,230,0.3)`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', letterSpacing: '-0.01em'
          }}>
            Free 250g sample
            <span style={{ fontFamily: cFont.mono, fontSize: 11, opacity: 0.6 }}>FedEx</span>
          </a>
        </div>
      </div>
    </section>);

}

function CMarquee() {
  const items = ['ISO 22000', 'FSSAI', 'HACCP', 'GMP', 'USDA Organic*', 'EU Organic*', 'Kosher*', 'Halal*', 'BRCGS-ready', 'Non-GMO', 'Pharmacopoeia USP', 'Pharmacopoeia EP'];
  return (
    <section style={{ background: C.yellow, color: C.green, padding: '20px 0', overflow: 'hidden', borderTop: `1px solid ${C.green}`, borderBottom: `1px solid ${C.green}` }}>
      <div style={{ display: 'flex', gap: 56, fontFamily: cFont.display, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>
        {[...items, ...items].map((t, i) =>
        <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 56 }}>
            {t}
            <span style={{ fontSize: 16, opacity: 0.6 }}>✦</span>
          </span>
        )}
      </div>
    </section>);

}

function CNumbers() {
  return (
    <section style={{ padding: '120px 56px', background: C.chalk, color: C.green }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 56, borderTop: `2px solid ${C.green}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em' }}>01 — RM IN NUMBERS</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.6, letterSpacing: '0.14em' }}>Updated weekly · last sync: 2026-05-13</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '64px 96px' }}>
        {[
        ['12,000', 'MT', 'Annual milling capacity at our Unjha facility — enough to supply roughly 40 million households for a year.'],
        ['4,500', 'acres', 'Under direct farmer contract across Banaskantha, Patan and Mehsana. 1,200+ smallholder families.'],
        ['38', 'countries', 'Export markets served in 2026 — from Rotterdam to Riyadh, São Paulo to Seoul.'],
        ['47', 'tests', 'Performed on every shipment. NIR fingerprint, HPLC, ICP-MS, microbial. Plain-language COA attached.']].
        map(([n, u, d], i) =>
        <div key={i} style={{ display: 'flex', gap: 28, alignItems: 'start' }}>
            <div style={{ fontFamily: cFont.mono, fontSize: 12, color: C.green, opacity: 0.5, letterSpacing: '0.12em', minWidth: 24, marginTop: 28 }}>0{i + 1}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
                <div style={{ fontFamily: cFont.display, fontSize: 140, fontWeight: 500, color: C.green, lineHeight: 0.9, letterSpacing: '-0.06em' }}>{n}</div>
                <div style={{ fontFamily: cFont.display, fontSize: 28, color: C.green, opacity: 0.55, letterSpacing: '-0.02em' }}>{u}</div>
              </div>
              <p style={{ fontFamily: cFont.display, fontSize: 17, color: C.ink, opacity: 0.8, lineHeight: 1.45, marginTop: 12, maxWidth: 460, fontWeight: 400 }}>{d}</p>
            </div>
          </div>
        )}
      </div>
    </section>);

}

const C_PRODUCTS = [
{ code: '99', name: 'Husk · 99%', sub: 'Pharma · Clinical', color: C.yellow },
{ code: '98', name: 'Husk · 98%', sub: 'Premium supplement', color: C.dust },
{ code: '95', name: 'Husk · 95%', sub: 'General food & supplement', color: C.dust },
{ code: 'PWD', name: 'Husk Powder', sub: 'Drink mixes, bakery', color: C.dust },
{ code: 'SEED', name: 'Whole Seed', sub: 'Pet food, milling, sowing', color: C.dust },
{ code: 'IND', name: 'Industrial Powder', sub: 'Drilling mud, binders', color: C.dust },
{ code: 'RX', name: 'Pharma Grade', sub: 'USP / EP compliant', color: C.yellow },
{ code: 'FOOD', name: 'Food Grade', sub: 'BRCGS-ready', color: C.dust },
{ code: 'ORG', name: 'Organic', sub: 'USDA / EU pending', color: C.yellow }];


function CProducts() {
  return (
    <section style={{ padding: '120px 56px', background: C.green, color: C.chalk }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 32, borderTop: `2px solid ${C.chalk}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em', color: C.yellow }}>02 — THE RANGE</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.55, letterSpacing: '0.14em' }}>09 grades · one species · zero blends</span>
      </div>
      <h2 style={{
        fontFamily: cFont.display, fontSize: 160, color: C.chalk, margin: 0, lineHeight: 0.86,
        letterSpacing: '-0.06em', fontWeight: 500, maxWidth: 1200
      }}>
        Every grade<br />of <span style={{ color: C.yellow, fontStyle: 'italic' }}>ispaghol,</span><br />milled here.
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginTop: 80 }}>
        {C_PRODUCTS.map((p, i) =>
        <article key={p.code} style={{
          background: C.greenSoft, borderRadius: 24, padding: '36px 32px 28px',
          minHeight: 280, display: 'flex', flexDirection: 'column',
          border: `1px solid rgba(243,239,230,0.08)`
        }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
              <div style={{
              width: 64, height: 64, borderRadius: 16, background: p.color, color: C.green,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: cFont.display, fontSize: 18, fontWeight: 700, letterSpacing: '-0.04em'
            }}>{p.code}</div>
              <span style={{ fontFamily: cFont.mono, fontSize: 11, color: C.dust, letterSpacing: '0.16em', marginTop: 6 }}>0{i + 1} / 09</span>
            </div>
            <div style={{ marginTop: 'auto' }}>
              <div style={{ fontFamily: cFont.display, fontSize: 30, color: C.chalk, lineHeight: 1.05, fontWeight: 500, letterSpacing: '-0.02em' }}>{p.name}</div>
              <div style={{ fontFamily: cFont.display, fontSize: 16, color: C.dust, marginTop: 6, fontWeight: 400 }}>{p.sub}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24, paddingTop: 18, borderTop: `1px solid rgba(243,239,230,0.12)` }}>
                <span style={{ fontFamily: cFont.mono, fontSize: 11, color: C.dust, letterSpacing: '0.14em' }}>SPEC + COA</span>
                <span style={{ fontFamily: cFont.display, fontSize: 14, color: C.yellow, fontWeight: 500 }}>Open →</span>
              </div>
            </div>
          </article>
        )}
      </div>
    </section>);

}

function CForWho() {
  const segs = [
  {
    tag: 'PHARMA',
    h: 'For formulators',
    d: 'USP/EP-compliant husk for OTC bulk-forming laxatives, fibre supplements, and prescription formulations. Every batch HPLC-fingerprinted, retains kept for 5 years.',
    bullets: ['USP / EP / IP grade', 'Heavy metals ≤ 10 ppm', 'Salmonella absent / 25g', '5-year retain samples']
  },
  {
    tag: 'FOOD',
    h: 'For food brands',
    d: 'BRCGS-ready husk and powder for cereal bars, gluten-free bakery, drink mixes, fibre-enriched dairy. Allergen-controlled facility, private label welcome.',
    bullets: ['BRCGS audit Q4 2026', 'Allergen-controlled line', 'Custom mesh (40–100)', 'Private label & retail-ready']
  },
  {
    tag: 'INDUSTRY',
    h: 'For industrial buyers',
    d: 'Technical-grade powder for drilling mud, paint binders, paper-coating. Bulk pricing, FCL only, custom mesh and viscosity targets on quote.',
    bullets: ['Custom viscosity targets', 'FCL / multi-FCL', 'Industrial big-bag packing', 'Indicative pricing in 4 hrs']
  }];

  return (
    <section style={{ padding: '120px 56px', background: C.chalk, color: C.green }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 32, borderTop: `2px solid ${C.green}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em' }}>03 — BY SECTOR</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.6, letterSpacing: '0.14em' }}>Pharma · food · industrial</span>
      </div>
      <h2 style={{
        fontFamily: cFont.display, fontSize: 100, color: C.green, margin: 0, lineHeight: 0.92,
        letterSpacing: '-0.05em', fontWeight: 500, maxWidth: 1100
      }}>
        Three buyers.<br />Three lines.<br />
        <span style={{ color: C.green, opacity: 0.45 }}>One operator.</span>
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginTop: 64 }}>
        {segs.map((s, i) =>
        <div key={i} style={{
          background: i === 0 ? C.green : C.chalkBright, color: i === 0 ? C.chalk : C.green,
          borderRadius: 28, padding: '40px 36px',
          border: i !== 0 ? `1px solid ${C.ruleDark}` : 'none'
        }}>
            <div style={{
            display: 'inline-block', fontFamily: cFont.mono, fontSize: 11,
            letterSpacing: '0.22em', padding: '6px 12px', borderRadius: 999,
            background: i === 0 ? C.yellow : C.green,
            color: i === 0 ? C.green : C.chalk,
            fontWeight: 600
          }}>{s.tag}</div>
            <h3 style={{ fontFamily: cFont.display, fontSize: 44, fontWeight: 500, margin: '24px 0 16px', letterSpacing: '-0.04em', lineHeight: 1 }}>{s.h}</h3>
            <p style={{ fontFamily: cFont.display, fontSize: 16, lineHeight: 1.5, margin: 0, opacity: i === 0 ? 0.85 : 0.8, fontWeight: 400 }}>{s.d}</p>
            <ul style={{ listStyle: 'none', padding: 0, margin: '28px 0 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {s.bullets.map((b, j) =>
            <li key={j} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              fontFamily: cFont.mono, fontSize: 12,
              letterSpacing: '0.04em',
              opacity: 0.9
            }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: i === 0 ? C.yellow : C.green }}></span>
                  {b}
                </li>
            )}
            </ul>
            <a href="#" style={{
            marginTop: 36, display: 'inline-flex', alignItems: 'center', gap: 8,
            fontFamily: cFont.display, fontSize: 14, fontWeight: 600,
            color: i === 0 ? C.yellow : C.green, textDecoration: 'none'
          }}>Open the {s.tag.toLowerCase()} brief →</a>
          </div>
        )}
      </div>
    </section>);

}

function CProcess() {
  const steps = [
  ['Seed', 'Banaskantha · 4,500 acres'],
  ['Pre-clean', 'Magnetic + de-stoner'],
  ['Condition', '12 hr · 18% humidity'],
  ['Mill', 'Roller line · no bleach'],
  ['Grade', '30–100 mesh · own silos'],
  ['NIR', 'Every 500 kg fingerprinted'],
  ['Wet lab', 'HPLC + ICP-MS @ SGS'],
  ['Pack', '25kg / 500kg / your label'],
  ['Ship', 'FOB Mundra · CIF anywhere']];

  return (
    <section style={{ padding: '120px 56px', background: C.greenDeep, color: C.chalk }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 32, borderTop: `2px solid ${C.chalk}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em', color: C.yellow }}>04 — SEED TO CONTAINER</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.55, letterSpacing: '0.14em' }}>9 steps · 1 site · 0 co-packers</span>
      </div>
      <h2 style={{
        fontFamily: cFont.display, fontSize: 100, color: C.chalk, margin: '0 0 64px',
        letterSpacing: '-0.05em', fontWeight: 500, lineHeight: 0.92, maxWidth: 1100
      }}>
        From the field<br />to your <span style={{ color: C.yellow }}>fill-line.</span>
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(9, 1fr)', gap: 12 }}>
        {steps.map(([t, d], i) =>
        <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{
            fontFamily: cFont.mono, fontSize: 11, color: C.yellow,
            letterSpacing: '0.16em'
          }}>0{i + 1}</div>
            <div style={{ height: 2, background: i === 0 ? C.yellow : 'rgba(243,239,230,0.15)' }}></div>
            <div style={{ fontFamily: cFont.display, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', color: C.chalk }}>{t}</div>
            <div style={{ fontFamily: cFont.mono, fontSize: 10, color: C.dust, letterSpacing: '0.08em', lineHeight: 1.45 }}>{d}</div>
          </div>
        )}
      </div>
      <div style={{ marginTop: 80, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
        <CPlaceholder label="Roller mill line · 02" h={300} />
        <CPlaceholder label="NIR bench · QC lab" h={300} />
      </div>
    </section>);

}

function CStory() {
  return (
    <section style={{ padding: '160px 56px', background: C.chalk, color: C.green, position: 'relative' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 80, alignItems: 'start' }}>
        <div>
          <div style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em', borderTop: `2px solid ${C.green}`, paddingTop: 16, marginBottom: 28 }}>05 — THE OPERATOR</div>
          <CPlaceholder label="Founder · Ramji Mehta · Unjha mandi 1989" h={480} tone="dust" />
          <div style={{ fontFamily: cFont.mono, fontSize: 11, color: C.green, opacity: 0.6, letterSpacing: '0.14em', marginTop: 12 }}>↑ FAMILY ARCHIVE · UNJHA APMC · 1989</div>
        </div>
        <div>
          <h2 style={{
            fontFamily: cFont.display, fontSize: 84, color: C.green, margin: '0 0 32px',
            letterSpacing: '-0.05em', fontWeight: 500, lineHeight: 0.92
          }}>
            Forty years<br />in the husk.<br />
            <span style={{ color: C.green, opacity: 0.4 }}>One year</span> on the<br />internet.
          </h2>
          <p style={{ fontFamily: cFont.display, fontSize: 22, lineHeight: 1.45, color: C.ink, opacity: 0.82, maxWidth: 620, fontWeight: 400 }}>
            My grandfather sold ispaghol in jute sacks at the Unjha mandi. My father
            shipped the first container to Hamburg in '89. We've watched a dozen
            companies grow on this seed without changing how it's bought or sold.
            RM Psyllium is the same family — finally with the facility, the
            software, and the impatience the seed deserves.
          </p>
          <div style={{ fontFamily: cFont.mono, fontSize: 12, color: C.green, opacity: 0.7, letterSpacing: '0.2em', textTransform: 'uppercase', marginTop: 32 }}>
            — Ramji Mehta · Founder · third-generation Unjha trader
          </div>
          <div style={{ marginTop: 56, display: 'grid', gridTemplateColumns: '100px 1fr', rowGap: 18, columnGap: 24 }}>
            {[
            ['1983', 'Mehta family begins trading psyllium at Unjha APMC'],
            ['1989', 'First export container · Hamburg, West Germany'],
            ['2007', 'Banaskantha farmer-contract programme'],
            ['2019', 'In-house NIR + HPLC lab commissioned'],
            ['2024', 'RM Psyllium facility opens · 12,000 MT/yr'],
            ['2026', 'Active in 38 export markets · this site goes live']].
            map(([y, t]) =>
            <React.Fragment key={y}>
                <span style={{ fontFamily: cFont.mono, fontSize: 13, color: C.green, fontWeight: 600, letterSpacing: '0.06em' }}>{y}</span>
                <span style={{ fontFamily: cFont.display, fontSize: 16, color: C.ink, opacity: 0.8, lineHeight: 1.5 }}>{t}</span>
              </React.Fragment>
            )}
          </div>
        </div>
      </div>
    </section>);

}

function CQuality() {
  return (
    <section style={{ padding: '120px 56px', background: C.green, color: C.chalk }} data-comment-anchor="815e3b181a-section-440-5">
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 32, borderTop: `2px solid ${C.chalk}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em', color: C.yellow }}>06 — QUALITY</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.55, letterSpacing: '0.14em' }}>47 parameters · plain language · attached to your invoice</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 80, alignItems: 'start' }}>
        <div>
          <h2 style={{ fontFamily: cFont.display, fontSize: 120, color: C.chalk, margin: 0, letterSpacing: '-0.05em', fontWeight: 500, lineHeight: 0.9 }}>
            A COA<br />with every<br /><span style={{ color: C.yellow }}>kilogram.</span>
          </h2>
          <p style={{ fontFamily: cFont.display, fontSize: 18, color: C.chalk, opacity: 0.8, lineHeight: 1.5, marginTop: 32, maxWidth: 540, fontWeight: 400 }}>
            Every batch fingerprinted on our NIR & HPLC bench, shadow-checked at
            SGS. Forty-seven parameters, in plain language, attached to your
            invoice — not hidden behind a buyer portal you forgot the password to.
          </p>
          <a href="#" style={{
            marginTop: 32, display: 'inline-flex', alignItems: 'center', gap: 10,
            fontFamily: cFont.display, fontSize: 14, fontWeight: 600,
            color: C.green, background: C.yellow, padding: '14px 22px', borderRadius: 999, textDecoration: 'none'
          }}>See a sample COA →</a>
        </div>
        <div style={{ background: C.greenSoft, borderRadius: 24, padding: '32px 32px 24px' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            paddingBottom: 18, borderBottom: `1px solid rgba(243,239,230,0.18)`
          }}>
            <div>
              <div style={{ fontFamily: cFont.mono, fontSize: 11, color: C.dust, letterSpacing: '0.18em' }}>COA · SAMPLE</div>
              <div style={{ fontFamily: cFont.display, fontSize: 22, color: C.chalk, marginTop: 4, fontWeight: 500 }}>Lot RM-24-1147 · Husk 99%</div>
            </div>
            <span style={{
              fontFamily: cFont.mono, fontSize: 11, color: C.green, background: C.yellow,
              padding: '6px 12px', borderRadius: 999, letterSpacing: '0.14em', fontWeight: 600
            }}>● PASS</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', padding: '14px 0 6px', fontFamily: cFont.mono, fontSize: 10, color: C.dust, letterSpacing: '0.16em', textTransform: 'uppercase' }}>
            <span>Parameter</span><span>Spec</span><span>Result</span>
          </div>
          {[
          ['Purity (husk)', '≥ 99.0%', '99.4%'],
          ['Swelling volume', '≥ 45 ml/g', '47.2 ml/g'],
          ['Moisture', '≤ 10%', '8.1%'],
          ['Total ash', '≤ 3.0%', '2.4%'],
          ['Heavy metals', '≤ 10 ppm', '2.1 ppm'],
          ['Salmonella / 25g', 'Absent', 'Absent'],
          ['E. coli / 10g', 'Absent', 'Absent'],
          ['Aflatoxin total', '≤ 4 ppb', '< 0.5 ppb'],
          ['Pesticide (EU MRL)', 'Conforms', 'Conforms'],
          ['Extraneous matter', '≤ 0.5%', '0.18%']].
          map(([k, spec, res], i) =>
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr',
            padding: '11px 0', borderTop: `1px solid rgba(243,239,230,0.08)`,
            fontFamily: cFont.mono, fontSize: 12, color: C.chalk
          }}>
              <span style={{ opacity: 0.85 }}>{k}</span>
              <span style={{ opacity: 0.6 }}>{spec}</span>
              <span style={{ color: C.yellow, fontWeight: 500 }}>{res}</span>
            </div>
          )}
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: `1px solid rgba(243,239,230,0.18)`, display: 'flex', justifyContent: 'space-between', fontFamily: cFont.mono, fontSize: 11, color: C.dust, letterSpacing: '0.1em' }}>
            <span>+ 37 more parameters on the full COA</span>
            <span>SGS Ref · GJ-24-1147-A</span>
          </div>
        </div>
      </div>
    </section>);

}

function CFAQ() {
  const faqs = [
  ['What is your MOQ?', 'One 20-ft FCL — about 12 MT of husk or 16 MT of seed. For samples, none — we ship 250g free via FedEx.'],
  ['Lead time from PO to B/L?', 'In-stock SKUs: 7–10 days from cleared payment to bill of lading. Made-to-order: 21–28 days. Pharma & organic: add 5 days for compliance docs.'],
  ['Do you offer private label?', 'Yes — from carton printing on 25kg sacks up to fully retail-ready pouches. Minimum 500 kg per SKU for private label.'],
  ['Pharmacopoeia compliance?', 'USP, EP and IP grades available. We share retain samples for 5 years and can support DMF / supplier qualification audits.'],
  ['Pricing model?', 'Quoted per shipment, against your spec, not ours. Indicative landed price (FOB / CIF / DDP) in 4 business hours.'],
  ['Why "RM Psyllium" and not the family name?', 'Because the seed is older than us. RM is the operator, not the legend.']];

  return (
    <section style={{ padding: '120px 56px', background: C.chalk, color: C.green }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 32, borderTop: `2px solid ${C.green}`, paddingTop: 16 }}>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.18em' }}>07 — BUYERS ASK</span>
        <span style={{ fontFamily: cFont.mono, fontSize: 12, opacity: 0.6, letterSpacing: '0.14em' }}>Indexed for procurement + AI search</span>
      </div>
      <h2 style={{ fontFamily: cFont.display, fontSize: 96, color: C.green, margin: '0 0 56px', letterSpacing: '-0.05em', fontWeight: 500, lineHeight: 0.92 }}>
        The questions<br />buyers actually ask.
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 64px' }}>
        {faqs.map(([q, a], i) =>
        <div key={i} style={{
          padding: '28px 0', borderTop: `1px solid ${C.ruleDark}`,
          borderBottom: i >= faqs.length - 2 ? `1px solid ${C.ruleDark}` : 'none'
        }}>
            <div style={{ fontFamily: cFont.mono, fontSize: 11, color: C.green, opacity: 0.55, letterSpacing: '0.14em', marginBottom: 12 }}>Q{(i + 1).toString().padStart(2, '0')}</div>
            <h3 style={{ fontFamily: cFont.display, fontSize: 24, color: C.green, margin: 0, letterSpacing: '-0.02em', fontWeight: 500, lineHeight: 1.25 }}>{q}</h3>
            <p style={{ fontFamily: cFont.display, fontSize: 15, color: C.ink, opacity: 0.78, lineHeight: 1.55, margin: '14px 0 0', fontWeight: 400 }}>{a}</p>
          </div>
        )}
      </div>
    </section>);

}

function CCTA() {
  return (
    <section style={{ padding: '120px 56px', background: C.yellow, color: C.green, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'relative', zIndex: 2 }}>
        <div style={{ fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.22em', textTransform: 'uppercase' }}>08 — LET'S TALK</div>
        <h2 style={{
          fontFamily: cFont.display, fontSize: 220, color: C.green, margin: '24px 0',
          letterSpacing: '-0.06em', fontWeight: 500, lineHeight: 0.84
        }}>
          Book.<br />The.<br />Call.
        </h2>
        <p style={{ fontFamily: cFont.display, fontSize: 22, color: C.green, opacity: 0.85, lineHeight: 1.4, maxWidth: 620, fontWeight: 400, margin: 0 }}>
          Twenty minutes with our export desk. Sample dispatched the same day.
          Indicative landed price before you hang up. That's the offer.
        </p>
        <div style={{ display: 'flex', gap: 16, marginTop: 56 }}>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 18, fontWeight: 600, color: C.yellow, background: C.green,
            padding: '22px 36px', borderRadius: 999, textDecoration: 'none', letterSpacing: '-0.01em'
          }}>Pick a time →</a>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 18, fontWeight: 600, color: C.green,
            padding: '22px 36px', borderRadius: 999, textDecoration: 'none', border: `2px solid ${C.green}`, letterSpacing: '-0.01em'
          }}>WhatsApp the desk</a>
        </div>
        <div style={{ marginTop: 48, display: 'flex', gap: 48, fontFamily: cFont.mono, fontSize: 12, letterSpacing: '0.16em', color: C.green, opacity: 0.7 }}>
          <span>● avg response: 4 hrs</span>
          <span>● export@rmpsyllium.com</span>
          <span>● +91 2767 333 444</span>
        </div>
      </div>
    </section>);

}

function CFooter() {
  return (
    <footer style={{ background: C.greenDeep, color: C.chalk, padding: '80px 56px 32px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 72 }}>
        <div>
          <CLogo />
          <p style={{ fontFamily: cFont.display, fontSize: 15, opacity: 0.7, lineHeight: 1.55, marginTop: 24, maxWidth: 360, fontWeight: 400 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
          <div style={{ fontFamily: cFont.mono, fontSize: 11, opacity: 0.55, letterSpacing: '0.14em', marginTop: 18 }}>
            IEC 0124007841 · APEDA RCMC/UNJ/2024 · CIN U15499GJ2024PTC141802
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <a href="#" style={{
            fontFamily: cFont.display, fontSize: 14, fontWeight: 600, color: C.green, background: C.yellow,
            padding: '14px 22px', borderRadius: 999, textDecoration: 'none', display: 'inline-block'
          }}>Book a call →</a>
          <div style={{ fontFamily: cFont.mono, fontSize: 11, opacity: 0.55, letterSpacing: '0.14em', marginTop: 14 }}>
            export@rmpsyllium.com · +91 2767 333 444
          </div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 36, paddingTop: 40, borderTop: `1px solid ${C.rule}` }}>
        {[
        ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Powder', 'Seed', 'Pharma', 'Industrial', 'Food', 'Organic']],
        ['By sector', ['Pharma', 'Food brands', 'Industrial', 'Pet food', 'Private label']],
        ['Quality', ['COA samples', 'Spec sheets', 'Certifications', 'Sustainability', 'Whitepapers']],
        ['Company', ['Story', 'Facility', 'Sourcing', 'Careers', 'Journal', 'Press']],
        ['Contact', ['Book a call', 'WhatsApp', 'RFQ', 'Sample request', 'Find on LinkedIn']]].
        map(([h, items], i) =>
        <div key={i}>
            <div style={{ fontFamily: cFont.mono, fontSize: 10, letterSpacing: '0.22em', opacity: 0.6, textTransform: 'uppercase' }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
              {items.map((t, j) =>
            <a key={j} href="#" style={{ fontFamily: cFont.display, fontSize: 14, color: C.chalk, opacity: 0.82, textDecoration: 'none', fontWeight: 400 }}>{t}</a>
            )}
            </div>
          </div>
        )}
      </div>
      {/* huge wordmark */}
      <div style={{ marginTop: 80, lineHeight: 0.84, overflow: 'hidden' }}>
        <div style={{ fontFamily: cFont.display, fontSize: 280, fontWeight: 600, color: C.greenSoft, letterSpacing: '-0.06em' }}>
          RM PSYLLIUM
        </div>
      </div>
      <div style={{
        marginTop: 24, paddingTop: 20, borderTop: `1px solid ${C.rule}`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: cFont.mono, fontSize: 10, opacity: 0.55, letterSpacing: '0.18em'
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD · UNJHA · GUJARAT</span>
        <span>PRIVACY · TERMS · MODERN SLAVERY · COOKIES</span>
      </div>
    </footer>);

}

function VariantC() {
  return (
    <div style={{ background: C.green, fontFamily: cFont.body, color: C.chalk, width: '100%' }}>
      <CNav />
      <CHero />
      <CMarquee />
      <CNumbers />
      <CProducts />
      <CForWho />
      <CProcess />
      <CStory />
      <CQuality />
      <CFAQ />
      <CCTA />
      <CFooter />
    </div>);

}

window.VariantC = VariantC;