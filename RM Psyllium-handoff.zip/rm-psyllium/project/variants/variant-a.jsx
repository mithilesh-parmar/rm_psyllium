// Variant A — "Field & Form"
// Earthy editorial. Cream + deep forest. Serif display + neutral sans.
// Storytelling-led, premium-tea-brand energy, agrocrops-inspired but elevated.

const A = {
  cream: '#f3ede0',
  paper: '#faf6ec',
  forest: '#1d2a1f',
  forestSoft: '#2c3a2e',
  ink: '#26221c',
  ochre: '#a87d4a',
  ochreSoft: '#c9a577',
  rule: 'rgba(29,42,31,0.18)',
  ruleSoft: 'rgba(29,42,31,0.08)',
  mute: 'rgba(38,34,28,0.62)',
};

const aFont = {
  display: '"Instrument Serif", "Cormorant Garamond", Georgia, serif',
  body: '"Geist", -apple-system, BlinkMacSystemFont, system-ui, sans-serif',
  mono: '"Geist Mono", "JetBrains Mono", ui-monospace, monospace',
};

// Inject Google Fonts once for variant A.
(function ensureAFonts() {
  if (document.getElementById('a-fonts')) return;
  const link = document.createElement('link');
  link.id = 'a-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@300;400;500;600&family=Geist+Mono:wght@400;500&display=swap';
  document.head.appendChild(link);
})();

// Placeholder photo: striped warm SVG with mono caption.
function APlaceholder({ label, h = 360, tone = 'forest' }) {
  const stripeColor = tone === 'forest' ? '#2c3a2e' : '#b89466';
  const bg = tone === 'forest' ? '#1d2a1f' : '#d9c5a3';
  const fg = tone === 'forest' ? 'rgba(243,237,224,0.55)' : 'rgba(29,42,31,0.55)';
  return (
    <div style={{
      width: '100%', height: h, background: bg, position: 'relative', overflow: 'hidden',
      backgroundImage: `repeating-linear-gradient(135deg, ${stripeColor} 0 1px, transparent 1px 14px)`,
    }}>
      <div style={{
        position: 'absolute', left: 16, bottom: 14, fontFamily: aFont.mono, fontSize: 10,
        letterSpacing: '0.18em', textTransform: 'uppercase', color: fg,
      }}>{label}</div>
    </div>
  );
}

function ALogo({ inverted }) {
  const fg = inverted ? A.cream : A.forest;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 36, height: 36, borderRadius: '50%', border: `1.2px solid ${fg}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: aFont.display, fontSize: 18, color: fg, fontStyle: 'italic',
        letterSpacing: '-0.02em',
      }}>rm</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: aFont.display, fontSize: 20, color: fg, letterSpacing: '0.01em' }}>RM Psyllium</div>
        <div style={{ fontFamily: aFont.mono, fontSize: 9, color: fg, opacity: 0.65, letterSpacing: '0.22em', marginTop: 3 }}>EST · UNJHA · 2024</div>
      </div>
    </div>
  );
}

function ASectionMark({ numeral, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontFamily: aFont.mono, fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: A.mute }}>
      <span style={{ fontFamily: aFont.display, fontStyle: 'italic', fontSize: 16, color: A.ochre, letterSpacing: 0, textTransform: 'none' }}>{numeral}</span>
      <span style={{ width: 36, height: 1, background: A.rule }}></span>
      <span>{label}</span>
    </div>
  );
}

function ANav() {
  const link = { fontFamily: aFont.body, fontSize: 13, color: A.ink, textDecoration: 'none', letterSpacing: '0.02em' };
  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '24px 64px', borderBottom: `1px solid ${A.ruleSoft}`,
    }}>
      <ALogo />
      <div style={{ display: 'flex', gap: 36 }}>
        <a style={link} href="#">Products</a>
        <a style={link} href="#">Quality</a>
        <a style={link} href="#">Facility</a>
        <a style={link} href="#">Story</a>
        <a style={link} href="#">Journal</a>
        <a style={link} href="#">Contact</a>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <span style={{ fontFamily: aFont.mono, fontSize: 10, color: A.mute, letterSpacing: '0.2em' }}>EN · ES · DE · AR</span>
        <a href="#" style={{
          fontFamily: aFont.body, fontSize: 13, color: A.cream, background: A.forest,
          padding: '10px 18px', borderRadius: 999, textDecoration: 'none', letterSpacing: '0.02em',
        }}>Schedule a call →</a>
      </div>
    </nav>
  );
}

function AHero() {
  return (
    <section style={{ padding: '88px 64px 96px', position: 'relative' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 64, alignItems: 'end' }}>
        <div>
          <div style={{ fontFamily: aFont.mono, fontSize: 11, letterSpacing: '0.28em', textTransform: 'uppercase', color: A.ochre, marginBottom: 28 }}>
            ◌ &nbsp;Psyllium, refined since 1983 — relaunched 2024
          </div>
          <h1 style={{
            fontFamily: aFont.display, fontSize: 116, lineHeight: 0.96, color: A.forest,
            margin: 0, letterSpacing: '-0.025em', fontWeight: 400,
          }}>
            The quiet<br/>
            standard in <span style={{ fontStyle: 'italic', color: A.ochre }}>psyllium.</span>
          </h1>
          <p style={{
            fontFamily: aFont.body, fontSize: 19, lineHeight: 1.5, color: A.ink, opacity: 0.82,
            maxWidth: 520, marginTop: 36, fontWeight: 300,
          }}>
            Grown across 4,500 contracted acres in Gujarat's Banaskantha belt,
            milled at our new Unjha facility, and shipped to formulators, fillers
            and pharmacies in thirty-eight countries.
          </p>
          <div style={{ display: 'flex', gap: 16, marginTop: 44, alignItems: 'center' }}>
            <a href="#" style={{
              fontFamily: aFont.body, fontSize: 14, color: A.cream, background: A.forest,
              padding: '16px 26px', borderRadius: 999, textDecoration: 'none', letterSpacing: '0.02em',
            }}>Schedule a sourcing call →</a>
            <a href="#" style={{
              fontFamily: aFont.body, fontSize: 14, color: A.forest, padding: '16px 0',
              textDecoration: 'none', letterSpacing: '0.02em', borderBottom: `1px solid ${A.forest}`,
            }}>Download spec sheet (PDF)</a>
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <APlaceholder label="Hero · psyllium fields at dawn, Banaskantha" h={520} tone="ochre" />
          <div style={{
            position: 'absolute', bottom: -28, left: -28, background: A.paper,
            padding: '20px 24px', border: `1px solid ${A.rule}`, maxWidth: 280,
          }}>
            <div style={{ fontFamily: aFont.mono, fontSize: 10, letterSpacing: '0.2em', color: A.mute, textTransform: 'uppercase' }}>Lot · RM-24-1147</div>
            <div style={{ fontFamily: aFont.display, fontSize: 22, color: A.forest, marginTop: 6 }}>Husk · 99% purity</div>
            <div style={{ fontFamily: aFont.body, fontSize: 12, color: A.mute, marginTop: 4 }}>Mesh 40 · &lt; 0.5% extraneous · COA ready</div>
          </div>
        </div>
      </div>
      <div style={{
        marginTop: 96, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0,
        borderTop: `1px solid ${A.rule}`, borderBottom: `1px solid ${A.rule}`,
      }}>
        {[
          ['12,000', 'MT annual capacity'],
          ['4,500', 'acres contracted'],
          ['38', 'countries served'],
          ['47', 'tests per shipment'],
        ].map(([num, label], i) => (
          <div key={i} style={{
            padding: '32px 28px', borderLeft: i ? `1px solid ${A.ruleSoft}` : 'none',
          }}>
            <div style={{ fontFamily: aFont.display, fontSize: 52, color: A.forest, lineHeight: 1 }}>{num}</div>
            <div style={{ fontFamily: aFont.mono, fontSize: 10, letterSpacing: '0.22em', color: A.mute, marginTop: 12, textTransform: 'uppercase' }}>{label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ATrustBand() {
  const items = ['ISO 22000', 'FSSAI Certified', 'USDA Organic*', 'Kosher*', 'Halal*', 'EU Organic*', 'GMP', 'Non-GMO'];
  return (
    <section style={{ padding: '40px 64px', background: A.forest, color: A.cream }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 32, justifyContent: 'space-between' }}>
        <div style={{ fontFamily: aFont.mono, fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.6, whiteSpace: 'nowrap' }}>Certifications →</div>
        <div style={{ display: 'flex', gap: 36, flexWrap: 'wrap', flex: 1 }}>
          {items.map((c, i) => (
            <span key={i} style={{ fontFamily: aFont.display, fontSize: 22, fontStyle: 'italic', letterSpacing: 0 }}>{c}</span>
          ))}
        </div>
        <div style={{ fontFamily: aFont.mono, fontSize: 10, opacity: 0.5, letterSpacing: '0.18em', whiteSpace: 'nowrap' }}>* in progress</div>
      </div>
    </section>
  );
}

const PRODUCTS = [
  { code: 'PSH-95', name: 'Psyllium Husk', grade: '95% purity', use: 'General supplement & food', mesh: '40 / 60 / 80' },
  { code: 'PSH-98', name: 'Psyllium Husk', grade: '98% purity', use: 'Premium nutraceutical', mesh: '40 / 60' },
  { code: 'PSH-99', name: 'Psyllium Husk', grade: '99% purity', use: 'Pharma & clinical', mesh: '30 / 40' },
  { code: 'PHP-FN', name: 'Husk Powder', grade: 'Fine 80 mesh', use: 'Drink mixes, bakery', mesh: '80 / 100' },
  { code: 'PSD-WH', name: 'Whole Seed', grade: 'Cleaned & graded', use: 'Pet food, sowing, milling', mesh: '—' },
  { code: 'PSI-IN', name: 'Industrial Powder', grade: 'Tech grade', use: 'Mud drilling, binders', mesh: '60 / 80' },
  { code: 'PSP-RX', name: 'Pharma Grade Husk', grade: 'USP / EP compliant', use: 'OTC laxatives, formulations', mesh: '30 / 40' },
  { code: 'PSF-FD', name: 'Food Grade Husk', grade: 'BRCGS-ready', use: 'Cereal, bakery, gluten-free', mesh: '40 / 60' },
  { code: 'PSO-OR', name: 'Organic Husk & Powder', grade: 'USDA / EU pending', use: 'Premium organic SKUs', mesh: '40 / 60 / 80' },
];

function AProducts() {
  return (
    <section style={{ padding: '120px 64px 96px', background: A.paper }}>
      <ASectionMark numeral="I." label="The Range" />
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', marginTop: 28, gap: 80, alignItems: 'end' }}>
        <h2 style={{ fontFamily: aFont.display, fontSize: 72, color: A.forest, margin: 0, lineHeight: 1, letterSpacing: '-0.02em', fontWeight: 400 }}>
          Nine grades.<br/>
          One <span style={{ fontStyle: 'italic', color: A.ochre }}>obsession</span> with cleanliness.
        </h2>
        <p style={{ fontFamily: aFont.body, fontSize: 16, color: A.ink, lineHeight: 1.6, opacity: 0.78, maxWidth: 460, fontWeight: 300 }}>
          From bulk industrial powder to pharmacopoeia-grade husk — every SKU is
          milled on the same line, batch-tested 47 ways, and shipped with a
          plain-language COA. No hidden blends. No mystery binders.
        </p>
      </div>
      <div style={{
        marginTop: 64, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0,
        border: `1px solid ${A.rule}`, background: A.paper,
      }}>
        {PRODUCTS.map((p, i) => (
          <article key={p.code} style={{
            padding: '32px 28px 28px',
            borderRight: (i % 3 !== 2) ? `1px solid ${A.ruleSoft}` : 'none',
            borderTop: i >= 3 ? `1px solid ${A.ruleSoft}` : 'none',
            display: 'flex', flexDirection: 'column', gap: 14, minHeight: 260,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontFamily: aFont.mono, fontSize: 10, color: A.ochre, letterSpacing: '0.2em' }}>{p.code}</span>
              <span style={{ fontFamily: aFont.mono, fontSize: 10, color: A.mute, letterSpacing: '0.2em' }}>0{i + 1}</span>
            </div>
            <div>
              <div style={{ fontFamily: aFont.display, fontSize: 30, color: A.forest, lineHeight: 1.05, letterSpacing: '-0.01em' }}>{p.name}</div>
              <div style={{ fontFamily: aFont.display, fontStyle: 'italic', fontSize: 18, color: A.ochre, marginTop: 4 }}>{p.grade}</div>
            </div>
            <div style={{ fontFamily: aFont.body, fontSize: 13, color: A.ink, opacity: 0.75, lineHeight: 1.55, fontWeight: 300 }}>{p.use}</div>
            <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 18, borderTop: `1px solid ${A.ruleSoft}` }}>
              <span style={{ fontFamily: aFont.mono, fontSize: 10, color: A.mute, letterSpacing: '0.18em' }}>MESH · {p.mesh}</span>
              <a href="#" style={{ fontFamily: aFont.body, fontSize: 12, color: A.forest, textDecoration: 'none', borderBottom: `1px solid ${A.forest}` }}>View spec →</a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function AStory() {
  return (
    <section style={{ padding: '140px 64px', background: A.cream }}>
      <ASectionMark numeral="II." label="The Story" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, marginTop: 28, alignItems: 'start' }}>
        <div style={{ position: 'sticky', top: 40 }}>
          <h2 style={{ fontFamily: aFont.display, fontSize: 88, color: A.forest, margin: 0, lineHeight: 0.98, letterSpacing: '-0.025em', fontWeight: 400 }}>
            Three<br/>generations<br/>
            <span style={{ fontStyle: 'italic', color: A.ochre }}>in the husk.</span>
          </h2>
          <div style={{ marginTop: 40 }}>
            <APlaceholder label="Founder portrait · Ramji Mehta, Unjha" h={420} tone="ochre" />
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 36, paddingTop: 32 }}>
          <p style={{ fontFamily: aFont.display, fontSize: 28, color: A.forest, lineHeight: 1.35, margin: 0, fontWeight: 400 }}>
            "My grandfather sold ispaghol in jute sacks at the Unjha mandi. My
            father exported the first container to Hamburg in 1989. RM Psyllium
            is the same family, finally with the facility the seed deserves."
          </p>
          <div style={{ fontFamily: aFont.mono, fontSize: 11, color: A.mute, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
            — Ramji Mehta, Founder
          </div>
          <div style={{ height: 1, background: A.rule, margin: '8px 0' }}></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '20px 32px' }}>
            {[
              ['1983', 'Mehta family begins trading psyllium at Unjha APMC.'],
              ['1989', 'First container exported to West Germany.'],
              ['2007', 'Partnership program with Banaskantha farmers begins.'],
              ['2019', 'NIR & HPLC lab commissioned for in-house QC.'],
              ['2024', 'RM Psyllium facility opens — 12,000 MT line.'],
              ['2026', 'Direct relationships in 38 export markets.'],
            ].map(([year, line]) => (
              <React.Fragment key={year}>
                <div style={{ fontFamily: aFont.mono, fontSize: 12, color: A.ochre, letterSpacing: '0.16em' }}>{year}</div>
                <div style={{ fontFamily: aFont.body, fontSize: 15, color: A.ink, lineHeight: 1.5, opacity: 0.82, fontWeight: 300 }}>{line}</div>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function AQuality() {
  return (
    <section style={{ padding: '140px 64px', background: A.forest, color: A.cream }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontFamily: aFont.mono, fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', opacity: 0.7 }}>
        <span style={{ fontFamily: aFont.display, fontStyle: 'italic', fontSize: 16, color: A.ochreSoft, letterSpacing: 0, textTransform: 'none' }}>III.</span>
        <span style={{ width: 36, height: 1, background: 'rgba(243,237,224,0.3)' }}></span>
        <span>The Lab</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, marginTop: 28, alignItems: 'start' }}>
        <h2 style={{ fontFamily: aFont.display, fontSize: 88, color: A.cream, margin: 0, lineHeight: 0.98, letterSpacing: '-0.025em', fontWeight: 400 }}>
          A COA<br/>with every<br/>
          <span style={{ fontStyle: 'italic', color: A.ochreSoft }}>kilogram.</span>
        </h2>
        <div style={{ paddingTop: 32 }}>
          <p style={{ fontFamily: aFont.body, fontSize: 17, lineHeight: 1.6, opacity: 0.85, fontWeight: 300 }}>
            Every batch is fingerprinted at our in-house NIR & HPLC lab and
            shadow-checked at SGS. Forty-seven parameters, plain-language,
            attached to your invoice — not hidden behind a portal login.
          </p>
          <div style={{ marginTop: 40, display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '14px 28px' }}>
            {[
              'Swelling volume (≥ 40 ml/g)',
              'Total ash (≤ 4%)',
              'Acid insoluble ash',
              'Loss on drying',
              'Salmonella (absent / 25g)',
              'E. coli (absent / 10g)',
              'Heavy metals (Pb, As, Cd, Hg)',
              'Pesticide residue (EU MRL)',
              'Aflatoxin (≤ 4 ppb)',
              'Microbial total count',
              'Extraneous matter (≤ 0.5%)',
              'Particle size distribution',
            ].map((t, i) => (
              <div key={i} style={{ fontFamily: aFont.mono, fontSize: 12, opacity: 0.82, letterSpacing: '0.04em', display: 'flex', gap: 10 }}>
                <span style={{ color: A.ochreSoft }}>·</span><span>{t}</span>
              </div>
            ))}
          </div>
          <a href="#" style={{
            marginTop: 40, display: 'inline-block', fontFamily: aFont.body, fontSize: 14,
            color: A.forest, background: A.cream, padding: '14px 22px', borderRadius: 999,
            textDecoration: 'none', letterSpacing: '0.02em',
          }}>See a sample COA →</a>
        </div>
      </div>
    </section>
  );
}

function AGlobal() {
  return (
    <section style={{ padding: '120px 64px', background: A.paper }}>
      <ASectionMark numeral="IV." label="Reach" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, marginTop: 28, alignItems: 'start' }}>
        <div>
          <h2 style={{ fontFamily: aFont.display, fontSize: 72, color: A.forest, margin: 0, lineHeight: 1, letterSpacing: '-0.02em', fontWeight: 400 }}>
            Mundra to <span style={{ fontStyle: 'italic', color: A.ochre }}>Rotterdam</span>, in nineteen days.
          </h2>
          <p style={{ fontFamily: aFont.body, fontSize: 16, color: A.ink, opacity: 0.78, lineHeight: 1.6, marginTop: 24, fontWeight: 300, maxWidth: 480 }}>
            FOB Mundra, CIF anywhere. We handle phyto, fumigation, EUR.1,
            certificate of origin, and the awkward customs questions — so your
            procurement team doesn't have to.
          </p>
          <div style={{ marginTop: 40, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0, border: `1px solid ${A.rule}` }}>
            {[
              ['North America', 'USA · Canada · Mexico'],
              ['Europe', 'DE · NL · UK · IT · ES · PL'],
              ['Middle East', 'UAE · KSA · Egypt'],
              ['Asia-Pacific', 'JP · KR · AU · VN · ID'],
              ['South America', 'BR · CL · AR'],
              ['Africa', 'ZA · KE · MA'],
            ].map(([region, list], i) => (
              <div key={i} style={{
                padding: '20px 22px',
                borderRight: (i % 2 === 0) ? `1px solid ${A.ruleSoft}` : 'none',
                borderTop: i >= 2 ? `1px solid ${A.ruleSoft}` : 'none',
              }}>
                <div style={{ fontFamily: aFont.display, fontSize: 22, color: A.forest, fontStyle: 'italic' }}>{region}</div>
                <div style={{ fontFamily: aFont.mono, fontSize: 11, color: A.mute, letterSpacing: '0.16em', marginTop: 6 }}>{list}</div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <APlaceholder label="Container loading · Mundra port" h={420} tone="ochre" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 0, border: `1px solid ${A.rule}`, borderTop: 'none' }}>
            {[
              ['25kg', 'multi-wall paper sack'],
              ['500kg', 'big bag, food-grade liner'],
              ['Custom', 'private label, retail-ready'],
            ].map(([s, l], i) => (
              <div key={i} style={{ padding: '20px 18px', borderRight: i < 2 ? `1px solid ${A.ruleSoft}` : 'none' }}>
                <div style={{ fontFamily: aFont.display, fontSize: 24, color: A.forest }}>{s}</div>
                <div style={{ fontFamily: aFont.mono, fontSize: 10, color: A.mute, letterSpacing: '0.16em', marginTop: 4 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ACTA() {
  return (
    <section style={{ padding: '140px 64px', background: A.cream, position: 'relative' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'center' }}>
        <div>
          <ASectionMark numeral="V." label="Begin" />
          <h2 style={{ fontFamily: aFont.display, fontSize: 96, color: A.forest, margin: '28px 0 0', lineHeight: 0.98, letterSpacing: '-0.025em', fontWeight: 400 }}>
            Let's talk<br/>
            <span style={{ fontStyle: 'italic', color: A.ochre }}>sourcing.</span>
          </h2>
          <p style={{ fontFamily: aFont.body, fontSize: 17, color: A.ink, opacity: 0.78, lineHeight: 1.6, marginTop: 32, fontWeight: 300, maxWidth: 460 }}>
            Twenty-minute call with our export desk. We'll send a sample, a
            current COA, and an honest landed price before the call ends.
          </p>
        </div>
        <div style={{ background: A.paper, padding: 40, border: `1px solid ${A.rule}` }}>
          <div style={{ fontFamily: aFont.mono, fontSize: 10, letterSpacing: '0.2em', color: A.mute, textTransform: 'uppercase' }}>Request a quote / sample</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 24 }}>
            {['Name', 'Company', 'Country', 'Email', 'Phone', 'Volume / month (MT)'].map((f, i) => (
              <label key={i} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontFamily: aFont.mono, fontSize: 9, letterSpacing: '0.2em', color: A.mute, textTransform: 'uppercase' }}>{f}</span>
                <div style={{ borderBottom: `1px solid ${A.rule}`, height: 28 }}></div>
              </label>
            ))}
          </div>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 20 }}>
            <span style={{ fontFamily: aFont.mono, fontSize: 9, letterSpacing: '0.2em', color: A.mute, textTransform: 'uppercase' }}>Product interest</span>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
              {['Husk 99%', 'Husk 98%', 'Husk Powder', 'Pharma', 'Industrial', 'Organic'].map(t => (
                <span key={t} style={{
                  fontFamily: aFont.body, fontSize: 12, color: A.forest,
                  padding: '6px 12px', border: `1px solid ${A.rule}`, borderRadius: 999,
                }}>{t}</span>
              ))}
            </div>
          </label>
          <a href="#" style={{
            display: 'block', textAlign: 'center', marginTop: 32, fontFamily: aFont.body, fontSize: 14,
            color: A.cream, background: A.forest, padding: '16px 22px', borderRadius: 999, textDecoration: 'none', letterSpacing: '0.02em',
          }}>Schedule the call →</a>
          <div style={{ fontFamily: aFont.mono, fontSize: 10, color: A.mute, letterSpacing: '0.16em', marginTop: 16, textAlign: 'center' }}>
            Avg. response · 4 business hours
          </div>
        </div>
      </div>
    </section>
  );
}

function AFooter() {
  return (
    <footer style={{ background: A.forest, color: A.cream, padding: '80px 64px 40px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 60 }}>
        <div>
          <ALogo inverted />
          <p style={{ fontFamily: aFont.body, fontSize: 13, opacity: 0.7, lineHeight: 1.6, marginTop: 20, maxWidth: 280, fontWeight: 300 }}>
            RM Psyllium Pvt. Ltd. · Survey No. 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
          <div style={{ fontFamily: aFont.mono, fontSize: 11, opacity: 0.6, letterSpacing: '0.16em', marginTop: 16 }}>
            IEC · 0124007841 &nbsp;·&nbsp; APEDA · RCMC/UNJ/2024
          </div>
        </div>
        {[
          ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Husk Powder', 'Pharma Grade', 'Industrial', 'Organic']],
          ['Company', ['Story', 'Facility', 'Sustainability', 'Press', 'Careers', 'Journal']],
          ['Contact', ['+91 2767 333 444', 'export@rmpsyllium.com', 'Schedule a call →', 'WhatsApp Business']],
        ].map(([title, items], i) => (
          <div key={i}>
            <div style={{ fontFamily: aFont.mono, fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', opacity: 0.6 }}>{title}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
              {items.map((t, j) => (
                <a key={j} href="#" style={{ fontFamily: aFont.body, fontSize: 14, color: A.cream, textDecoration: 'none', opacity: 0.85, fontWeight: 300 }}>{t}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 64, paddingTop: 24, borderTop: `1px solid rgba(243,237,224,0.18)`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontFamily: aFont.mono, fontSize: 10, opacity: 0.55, letterSpacing: '0.18em',
      }}>
        <span>© 2026 RM PSYLLIUM PVT. LTD. · UNJHA, GUJARAT</span>
        <span>PRIVACY · TERMS · CODE OF CONDUCT</span>
      </div>
    </footer>
  );
}

function VariantA() {
  return (
    <div style={{ background: A.cream, fontFamily: aFont.body, color: A.ink, width: '100%' }}>
      <ANav />
      <AHero />
      <ATrustBand />
      <AProducts />
      <AStory />
      <AQuality />
      <AGlobal />
      <ACTA />
      <AFooter />
    </div>
  );
}

window.VariantA = VariantA;
