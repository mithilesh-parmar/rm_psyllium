// Variant E — "Particle Field"
// Editorial elegance + a full-bleed canvas of falling psyllium husk particles.
// Cream + forest + ochre. Big serif over slow, ambient motion.

const E = {
  cream: '#efe9d8',
  paper: '#f8f3e6',
  forest: '#1b2519',
  forestSoft: '#2a3a26',
  ink: '#231e16',
  ochre: '#b08454',
  ochreDeep: '#8a653d',
  rule: 'rgba(35,30,22,0.16)',
  ruleSoft: 'rgba(35,30,22,0.08)',
  mute: 'rgba(35,30,22,0.6)',
};

const eFont = {
  display: '"Instrument Serif", Georgia, serif',
  body: '"Geist", -apple-system, system-ui, sans-serif',
  mono: '"Geist Mono", "JetBrains Mono", ui-monospace, monospace',
};

(function ensureEFonts() {
  if (document.getElementById('e-fonts')) return;
  const link = document.createElement('link');
  link.id = 'e-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@300;400;500;600&family=Geist+Mono:wght@400;500&display=swap';
  document.head.appendChild(link);
})();

(function ensureEKeyframes() {
  if (document.getElementById('e-keyframes')) return;
  const s = document.createElement('style');
  s.id = 'e-keyframes';
  s.textContent = `
    @keyframes e-fade { from{opacity:0; transform:translateY(12px)} to{opacity:1; transform:translateY(0)} }
    @keyframes e-shimmer { 0%,100%{opacity:.85} 50%{opacity:1} }
    @keyframes e-marquee { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
  `;
  document.head.appendChild(s);
})();

function EHuskCanvas({ height = 720 }) {
  // Falling husk flakes — slow, ambient, painterly.
  const ref = React.useRef(null);
  React.useEffect(() => {
    const cnv = ref.current;
    if (!cnv) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = cnv.offsetWidth, h = cnv.offsetHeight;
    cnv.width = w * dpr; cnv.height = h * dpr;
    const ctx = cnv.getContext('2d');
    ctx.scale(dpr, dpr);

    const count = 90;
    const flakes = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: 1.2 + Math.random() * 3.4,
      vy: 0.12 + Math.random() * 0.32,
      vx: (Math.random() - 0.5) * 0.18,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 0.012,
      hue: Math.random(),
      op: 0.18 + Math.random() * 0.5,
    }));

    let raf;
    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      for (const f of flakes) {
        f.x += f.vx;
        f.y += f.vy;
        f.rot += f.vr;
        if (f.y > h + 10) { f.y = -10; f.x = Math.random() * w; }
        if (f.x < -10) f.x = w + 10;
        if (f.x > w + 10) f.x = -10;
        const color = f.hue < 0.6
          ? `rgba(176,132,84,${f.op})`
          : f.hue < 0.85
            ? `rgba(138,101,61,${f.op})`
            : `rgba(27,37,25,${f.op * 0.6})`;
        ctx.save();
        ctx.translate(f.x, f.y);
        ctx.rotate(f.rot);
        ctx.fillStyle = color;
        // husk-flake = thin oblong
        ctx.beginPath();
        ctx.ellipse(0, 0, f.r * 2.4, f.r * 0.6, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();

    const ro = new ResizeObserver(() => {
      w = cnv.offsetWidth; h = cnv.offsetHeight;
      cnv.width = w * dpr; cnv.height = h * dpr;
      ctx.scale(dpr, dpr);
    });
    ro.observe(cnv);

    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, []);
  return <canvas ref={ref} style={{ width: '100%', height, display: 'block' }} />;
}

function ELogo({ inverted }) {
  const fg = inverted ? E.cream : E.forest;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 36, height: 36, borderRadius: '50%', border: `1.2px solid ${fg}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: eFont.display, fontSize: 18, color: fg, fontStyle: 'italic',
      }}>rm</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: eFont.display, fontSize: 21, color: fg }}>RM Psyllium</div>
        <div style={{ fontFamily: eFont.mono, fontSize: 9, color: fg, opacity: 0.65, letterSpacing: '0.22em', marginTop: 3 }}>EST · UNJHA · 2024</div>
      </div>
    </div>
  );
}

function ENav() {
  const link = { fontFamily: eFont.body, fontSize: 13, color: E.cream, textDecoration: 'none', letterSpacing: '0.02em', opacity: 0.92 };
  return (
    <nav style={{
      position: 'absolute', top: 0, left: 0, right: 0, zIndex: 5,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '28px 64px',
    }}>
      <ELogo inverted />
      <div style={{ display: 'flex', gap: 32 }}>
        {['Products', 'Quality', 'Facility', 'Story', 'Journal', 'Contact'].map(t => (
          <a key={t} href="#" style={link}>{t}</a>
        ))}
      </div>
      <a href="#" style={{
        fontFamily: eFont.body, fontSize: 13, color: E.forest, background: E.cream,
        padding: '10px 18px', borderRadius: 999, textDecoration: 'none', letterSpacing: '0.02em',
      }}>Schedule a call →</a>
    </nav>
  );
}

function EHero() {
  return (
    <section style={{ position: 'relative', background: E.forest, color: E.cream, overflow: 'hidden', minHeight: 820 }}>
      <ENav />
      {/* canvas particle field */}
      <div style={{ position: 'absolute', inset: 0 }}>
        <EHuskCanvas height={820} />
      </div>
      {/* vignette */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at center, transparent 0%, rgba(27,37,25,0.4) 70%, rgba(27,37,25,0.85) 100%)',
        pointerEvents: 'none',
      }} />
      <div style={{ position: 'relative', zIndex: 2, padding: '180px 64px 120px', display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 64, alignItems: 'end', minHeight: 820, boxSizing: 'border-box' }}>
        <div style={{ animation: 'e-fade 1.2s ease-out' }}>
          <div style={{ fontFamily: eFont.mono, fontSize: 11, letterSpacing: '0.28em', color: E.ochre, marginBottom: 28, textTransform: 'uppercase' }}>
            ◌ &nbsp;Plantago ovata · cultivar A-37 · falling at 0.3 m/s
          </div>
          <h1 style={{
            fontFamily: eFont.display, fontSize: 140, lineHeight: 0.92, color: E.cream, margin: 0,
            letterSpacing: '-0.025em', fontWeight: 400, textWrap: 'pretty',
          }}>
            A seed,<br/>
            <span style={{ fontStyle: 'italic', color: E.ochre }}>caught in</span><br/>
            slow time.
          </h1>
          <p style={{
            fontFamily: eFont.body, fontSize: 19, lineHeight: 1.55, color: E.cream,
            opacity: 0.82, maxWidth: 560, marginTop: 36, fontWeight: 300,
          }}>
            What you're watching is the moment we look for — when the husk leaves
            the seed, in our milling line, at a fall rate of 0.3 m/s. Get it
            wrong and the mucilage scorches. Get it right and you have the
            cleanest psyllium money can buy.
          </p>
          <div style={{ display: 'flex', gap: 14, marginTop: 44, alignItems: 'center' }}>
            <a href="#" style={{
              fontFamily: eFont.body, fontSize: 14, color: E.forest, background: E.cream,
              padding: '16px 26px', borderRadius: 999, textDecoration: 'none',
            }}>Schedule a sourcing call →</a>
            <a href="#" style={{
              fontFamily: eFont.body, fontSize: 14, color: E.cream, padding: '16px 0',
              textDecoration: 'none', borderBottom: `1px solid ${E.cream}`, opacity: 0.85,
            }}>Watch the full process film (3:48)</a>
          </div>
        </div>
        <div style={{ alignSelf: 'end' }}>
          <div style={{
            background: 'rgba(248,243,230,0.06)',
            backdropFilter: 'blur(8px)',
            border: `1px solid rgba(248,243,230,0.18)`,
            padding: '24px 28px', maxWidth: 360,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ fontFamily: eFont.mono, fontSize: 10, letterSpacing: '0.2em', color: E.ochre }}>● LIVE · MILL 02</span>
              <span style={{ fontFamily: eFont.mono, fontSize: 10, opacity: 0.6, letterSpacing: '0.16em' }}>14:48 IST</span>
            </div>
            <div style={{ fontFamily: eFont.display, fontSize: 36, fontStyle: 'italic', color: E.cream, lineHeight: 1.1 }}>Lot RM-26-0512</div>
            <div style={{ fontFamily: eFont.body, fontSize: 13, opacity: 0.78, marginTop: 8, fontWeight: 300 }}>Husk · 99% purity · mesh 40</div>
            <div style={{
              marginTop: 18, paddingTop: 14, borderTop: `1px solid rgba(248,243,230,0.18)`,
              display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12,
            }}>
              {[['Yield', '99.4%'], ['Swelling', '47.2 ml/g'], ['Moisture', '8.1%'], ['Ash', '2.4%']].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontFamily: eFont.mono, fontSize: 9, opacity: 0.55, letterSpacing: '0.2em' }}>{k.toUpperCase()}</div>
                  <div style={{ fontFamily: eFont.display, fontSize: 22, color: E.ochre, marginTop: 2, fontStyle: 'italic' }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* bottom band — slow marquee */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, padding: '14px 0',
        borderTop: `1px solid rgba(248,243,230,0.18)`,
        background: 'rgba(27,37,25,0.6)', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'e-marquee 80s linear infinite', fontFamily: eFont.display, fontStyle: 'italic', fontSize: 20, color: E.cream, opacity: 0.85 }}>
          {Array.from({ length: 4 }).flatMap((_, i) => [
            'Unjha, Gujarat',
            <span key={`s${i}a`} style={{ color: E.ochre, padding: '0 28px' }}>✦</span>,
            'Banaskantha · 4,500 acres',
            <span key={`s${i}b`} style={{ color: E.ochre, padding: '0 28px' }}>✦</span>,
            'Rotterdam · 19 days',
            <span key={`s${i}c`} style={{ color: E.ochre, padding: '0 28px' }}>✦</span>,
            'Tokyo · 14 days',
            <span key={`s${i}d`} style={{ color: E.ochre, padding: '0 28px' }}>✦</span>,
            'São Paulo · 32 days',
            <span key={`s${i}e`} style={{ color: E.ochre, padding: '0 28px' }}>✦</span>,
          ]).map((t, i) => <span key={i} style={{ padding: '0 28px' }}>{t}</span>)}
        </div>
      </div>
    </section>
  );
}

function EChapter({ num, title, kicker }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, fontFamily: eFont.mono, fontSize: 11, letterSpacing: '0.24em', color: E.mute, textTransform: 'uppercase', marginBottom: 32 }}>
      <span style={{ fontFamily: eFont.display, fontStyle: 'italic', fontSize: 18, color: E.ochre, letterSpacing: 0, textTransform: 'none' }}>{num}</span>
      <span style={{ width: 32, height: 1, background: E.rule }}></span>
      <span>{title}</span>
      <span style={{ flex: 1 }}></span>
      <span style={{ opacity: 0.6 }}>{kicker}</span>
    </div>
  );
}

function ENumbers() {
  return (
    <section style={{ padding: '120px 64px', background: E.cream, color: E.ink }}>
      <EChapter num="I." title="In numbers" kicker="updated weekly" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, border: `1px solid ${E.rule}` }}>
        {[
          ['12,000', 'MT annual capacity'],
          ['4,500', 'acres contracted'],
          ['38', 'countries served'],
          ['47', 'tests per shipment'],
        ].map(([n, l], i) => (
          <div key={i} style={{ padding: '40px 32px', borderRight: i < 3 ? `1px solid ${E.ruleSoft}` : 'none' }}>
            <div style={{ fontFamily: eFont.display, fontSize: 80, color: E.forest, lineHeight: 0.95, letterSpacing: '-0.02em' }}>{n}</div>
            <div style={{ fontFamily: eFont.mono, fontSize: 11, color: E.mute, letterSpacing: '0.18em', marginTop: 14, textTransform: 'uppercase' }}>{l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function EProcessFilm() {
  // "Film strip" of process stills — 5 cards with subtle CSS shimmer.
  const steps = [
    { t: 'Seed', s: 'Banaskantha · 4,500 ac', tone: 1 },
    { t: 'Mill', s: 'Roller line · no bleach', tone: 2 },
    { t: 'Grade', s: '30–100 mesh · own silos', tone: 3 },
    { t: 'Test', s: 'NIR + HPLC · 47 params', tone: 4 },
    { t: 'Ship', s: 'FOB Mundra · CIF anywhere', tone: 5 },
  ];
  const grads = {
    1: 'linear-gradient(135deg, #c9a577 0%, #8a653d 100%)',
    2: 'linear-gradient(135deg, #2a3a26 0%, #1b2519 100%)',
    3: 'linear-gradient(135deg, #b08454 0%, #c9a577 100%)',
    4: 'linear-gradient(135deg, #1b2519 0%, #2a3a26 50%, #b08454 100%)',
    5: 'linear-gradient(135deg, #8a653d 0%, #2a3a26 100%)',
  };
  return (
    <section style={{ padding: '120px 64px', background: E.paper, color: E.ink }}>
      <EChapter num="II." title="Process film" kicker="5 frames · 1 line · 0 co-packers" />
      <h2 style={{ fontFamily: eFont.display, fontSize: 88, color: E.forest, margin: '0 0 56px', letterSpacing: '-0.025em', lineHeight: 0.95, fontWeight: 400 }}>
        Seed to <span style={{ fontStyle: 'italic', color: E.ochre }}>container,</span><br/>in five frames.
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
        {steps.map((st, i) => (
          <article key={i} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{
              aspectRatio: '3/4', background: grads[st.tone],
              position: 'relative', overflow: 'hidden',
              backgroundImage: `${grads[st.tone]}, repeating-linear-gradient(45deg, rgba(248,243,230,0.07) 0 1px, transparent 1px 12px)`,
              animation: 'e-shimmer 4s ease-in-out infinite',
              animationDelay: `${i * 0.4}s`,
            }}>
              <div style={{
                position: 'absolute', top: 12, left: 12,
                fontFamily: eFont.mono, fontSize: 10, color: 'rgba(248,243,230,0.7)',
                letterSpacing: '0.18em',
              }}>FRAME 0{i + 1}</div>
              <div style={{
                position: 'absolute', bottom: 14, left: 14,
                fontFamily: eFont.display, fontSize: 28, color: E.cream, fontStyle: 'italic',
              }}>{st.t}</div>
            </div>
            <div style={{ fontFamily: eFont.mono, fontSize: 11, color: E.mute, letterSpacing: '0.14em' }}>{st.s}</div>
          </article>
        ))}
      </div>
    </section>
  );
}

function EProducts() {
  const items = [
    ['Husk · 99%', 'Pharma · clinical'],
    ['Husk · 98%', 'Premium supplement'],
    ['Husk · 95%', 'General food'],
    ['Husk Powder', 'Drink mixes, bakery'],
    ['Whole Seed', 'Pet food, milling'],
    ['Industrial Powder', 'Drilling, binders'],
    ['Pharma Grade', 'USP / EP compliant'],
    ['Food Grade', 'BRCGS-ready'],
    ['Organic', 'USDA / EU pending'],
  ];
  return (
    <section style={{ padding: '120px 64px', background: E.cream, color: E.ink }}>
      <EChapter num="III." title="The range" kicker="09 grades" />
      <h2 style={{ fontFamily: eFont.display, fontSize: 88, color: E.forest, margin: '0 0 56px', letterSpacing: '-0.025em', lineHeight: 0.95, fontWeight: 400 }}>
        Nine grades,<br/>milled on the <span style={{ fontStyle: 'italic', color: E.ochre }}>same line.</span>
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, border: `1px solid ${E.rule}` }}>
        {items.map(([n, s], i) => (
          <div key={i} style={{
            padding: '28px 28px 24px',
            borderRight: (i % 3 !== 2) ? `1px solid ${E.ruleSoft}` : 'none',
            borderTop: i >= 3 ? `1px solid ${E.ruleSoft}` : 'none',
            display: 'flex', flexDirection: 'column', gap: 8, minHeight: 180,
          }}>
            <span style={{ fontFamily: eFont.mono, fontSize: 10, color: E.ochre, letterSpacing: '0.18em' }}>0{i + 1}</span>
            <div style={{ fontFamily: eFont.display, fontSize: 32, color: E.forest, fontStyle: i % 3 === 0 ? 'italic' : 'normal', letterSpacing: '-0.01em' }}>{n}</div>
            <div style={{ fontFamily: eFont.body, fontSize: 13, color: E.mute, fontWeight: 300, marginTop: 'auto' }}>{s}</div>
            <a href="#" style={{ fontFamily: eFont.body, fontSize: 12, color: E.forest, textDecoration: 'none', borderBottom: `1px solid ${E.forest}`, alignSelf: 'flex-start' }}>View spec →</a>
          </div>
        ))}
      </div>
    </section>
  );
}

function ECTA() {
  return (
    <section style={{ padding: '140px 64px', background: E.forest, color: E.cream, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, opacity: 0.6 }}>
        <EHuskCanvas height={680} />
      </div>
      <div style={{ position: 'relative', zIndex: 2, maxWidth: 900 }}>
        <EChapter num="IV." title="Begin" kicker="20-min call · sample dispatched same day" />
        <h2 style={{ fontFamily: eFont.display, fontSize: 120, color: E.cream, margin: '20px 0 32px', lineHeight: 0.95, letterSpacing: '-0.03em', fontWeight: 400 }}>
          Let's talk<br/><span style={{ fontStyle: 'italic', color: E.ochre }}>sourcing.</span>
        </h2>
        <p style={{ fontFamily: eFont.body, fontSize: 18, lineHeight: 1.6, opacity: 0.85, maxWidth: 560, fontWeight: 300 }}>
          Twenty minutes with our export desk. A 250g sample dispatched the same
          day. An indicative landed price before the call ends. That is the
          whole offer.
        </p>
        <div style={{ display: 'flex', gap: 14, marginTop: 40 }}>
          <a href="#" style={{
            fontFamily: eFont.body, fontSize: 15, color: E.forest, background: E.cream,
            padding: '18px 28px', borderRadius: 999, textDecoration: 'none',
          }}>Schedule the call →</a>
          <a href="#" style={{
            fontFamily: eFont.body, fontSize: 15, color: E.cream,
            padding: '18px 28px', borderRadius: 999, textDecoration: 'none',
            border: `1px solid rgba(248,243,230,0.4)`,
          }}>Download spec PDF</a>
        </div>
      </div>
    </section>
  );
}

function EFooter() {
  return (
    <footer style={{ background: E.forest, color: E.cream, padding: '64px 64px 28px', borderTop: `1px solid rgba(248,243,230,0.18)` }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: 56 }}>
        <div>
          <ELogo inverted />
          <p style={{ fontFamily: eFont.body, fontSize: 13, opacity: 0.7, lineHeight: 1.6, marginTop: 18, maxWidth: 280, fontWeight: 300 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
        </div>
        {[
          ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Powder', 'Pharma', 'Industrial', 'Organic']],
          ['Company', ['Story', 'Facility', 'Sustainability', 'Journal', 'Press']],
          ['Contact', ['+91 2767 333 444', 'export@rmpsyllium.com', 'WhatsApp', 'Schedule a call']],
        ].map(([h, items], i) => (
          <div key={i}>
            <div style={{ fontFamily: eFont.mono, fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', opacity: 0.6 }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
              {items.map((t, j) => (
                <a key={j} href="#" style={{ fontFamily: eFont.body, fontSize: 13, color: E.cream, opacity: 0.85, textDecoration: 'none', fontWeight: 300 }}>{t}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 56, paddingTop: 20, borderTop: `1px solid rgba(248,243,230,0.18)`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: eFont.mono, fontSize: 10, opacity: 0.55, letterSpacing: '0.18em',
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD · UNJHA · GUJARAT</span>
        <span>PRIVACY · TERMS · CODE OF CONDUCT</span>
      </div>
    </footer>
  );
}

function VariantE() {
  return (
    <div style={{ background: E.cream, fontFamily: eFont.body, color: E.ink, width: '100%' }}>
      <EHero />
      <ENumbers />
      <EProcessFilm />
      <EProducts />
      <ECTA />
      <EFooter />
    </div>
  );
}

window.VariantE = VariantE;
