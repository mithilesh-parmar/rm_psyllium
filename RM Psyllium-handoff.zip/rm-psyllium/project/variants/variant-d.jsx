// Variant D — "Live Feed"
// Industrial precision + multi-pane "live facility cam" hero with motion.
// Looping CSS gradients act as the video; a grain overlay sells the feed.

const D = {
  paper: '#0a0b08',
  paperAlt: '#13140f',
  ink: '#f4f1e8',
  inkSoft: '#a8a698',
  sage: '#9aab78',
  signal: '#ff4d1f',
  amber: '#f4b942',
  rule: 'rgba(244,241,232,0.16)',
  ruleSoft: 'rgba(244,241,232,0.08)',
};

const dFont = {
  sans: '"IBM Plex Sans", -apple-system, system-ui, sans-serif',
  mono: '"IBM Plex Mono", ui-monospace, monospace',
};

(function ensureDFonts() {
  if (document.getElementById('d-fonts')) return;
  const link = document.createElement('link');
  link.id = 'd-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap';
  document.head.appendChild(link);
})();

// Inject keyframes once.
(function ensureDKeyframes() {
  if (document.getElementById('d-keyframes')) return;
  const s = document.createElement('style');
  s.id = 'd-keyframes';
  s.textContent = `
    @keyframes d-pan { 0%{transform:scale(1.15) translate(-2%,-2%)} 50%{transform:scale(1.2) translate(2%,2%)} 100%{transform:scale(1.15) translate(-2%,-2%)} }
    @keyframes d-pan2 { 0%{transform:scale(1.1) translate(1%,-1%) rotate(0deg)} 100%{transform:scale(1.18) translate(-2%,2%) rotate(2deg)} }
    @keyframes d-pulse { 0%,100%{opacity:.6} 50%{opacity:1} }
    @keyframes d-tick { 0%{transform:translateY(0)} 100%{transform:translateY(-100%)} }
    @keyframes d-scan { 0%{transform:translateY(-10%)} 100%{transform:translateY(110%)} }
    @keyframes d-grain { 0%,100%{transform:translate(0,0)} 25%{transform:translate(-2%,3%)} 50%{transform:translate(3%,-1%)} 75%{transform:translate(-1%,-2%)} }
    @keyframes d-count { from{opacity:.4;transform:translateY(4px)} to{opacity:1;transform:translateY(0)} }
    @keyframes d-marquee { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
    @keyframes d-blink { 0%,49%{opacity:1} 50%,100%{opacity:0} }
  `;
  document.head.appendChild(s);
})();

function DLiveCam({ label, location, ts, kind = 1, accent = D.sage }) {
  // Each cam is a gradient + grain + scanline + chrome.
  const gradient = ({
    1: 'radial-gradient(circle at 30% 40%, #2a3a1f 0%, #0d1408 60%, #050702 100%)',
    2: 'radial-gradient(ellipse at 70% 30%, #5a4220 0%, #1a1208 50%, #0a0703 100%)',
    3: 'linear-gradient(160deg, #14201a 0%, #0a1208 50%, #1e2818 100%)',
    4: 'radial-gradient(circle at 50% 70%, #3a2e18 0%, #14100a 60%, #0a0805 100%)',
  })[kind];

  return (
    <div style={{
      position: 'relative', overflow: 'hidden', background: '#040502',
      border: `1px solid ${D.rule}`, aspectRatio: '4/3',
    }}>
      {/* "video" layer */}
      <div style={{
        position: 'absolute', inset: 0, background: gradient,
        animation: 'd-pan 18s ease-in-out infinite',
        animationDelay: `-${kind * 3}s`,
      }} />
      {/* particulate / texture */}
      <div style={{
        position: 'absolute', inset: '-10%',
        backgroundImage: `radial-gradient(rgba(244,241,232,0.06) 1px, transparent 1px), radial-gradient(rgba(244,241,232,0.04) 1px, transparent 1px)`,
        backgroundSize: '3px 3px, 7px 7px',
        backgroundPosition: '0 0, 1px 1px',
        animation: 'd-grain 2.4s steps(8) infinite',
        mixBlendMode: 'overlay',
      }} />
      {/* scanline */}
      <div style={{
        position: 'absolute', left: 0, right: 0, height: '32%',
        background: 'linear-gradient(180deg, transparent 0%, rgba(255,255,255,0.06) 50%, transparent 100%)',
        animation: 'd-scan 6s linear infinite',
        animationDelay: `-${kind * 1.5}s`,
      }} />
      {/* chrome top */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, padding: '10px 12px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        background: 'linear-gradient(180deg, rgba(0,0,0,0.6), transparent)',
        fontFamily: dFont.mono, fontSize: 10, letterSpacing: '0.16em', color: D.ink,
      }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: D.signal, animation: 'd-pulse 1.6s ease-in-out infinite' }}></span>
          REC · {label}
        </span>
        <span style={{ color: accent }}>{ts}</span>
      </div>
      {/* chrome bottom */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, padding: '10px 12px',
        background: 'linear-gradient(0deg, rgba(0,0,0,0.7), transparent)',
        fontFamily: dFont.mono, fontSize: 10, letterSpacing: '0.14em', color: D.inkSoft,
        display: 'flex', justifyContent: 'space-between',
      }}>
        <span>{location}</span>
        <span style={{ color: accent }}>● LIVE</span>
      </div>
      {/* corner crosshairs */}
      {[[8, 8], [8, 'r'], ['b', 8], ['b', 'r']].map(([t, l], i) => {
        const pos = {};
        if (t === 'b') pos.bottom = 8; else pos.top = t;
        if (l === 'r') pos.right = 8; else pos.left = l;
        return <div key={i} style={{
          position: 'absolute', ...pos, width: 10, height: 10,
          borderTop: t !== 'b' ? `1px solid ${accent}` : 'none',
          borderBottom: t === 'b' ? `1px solid ${accent}` : 'none',
          borderLeft: l !== 'r' ? `1px solid ${accent}` : 'none',
          borderRight: l === 'r' ? `1px solid ${accent}` : 'none',
        }} />;
      })}
    </div>
  );
}

function DTicker({ items }) {
  // Vertical scrolling stat ticker.
  return (
    <div style={{
      height: 28, overflow: 'hidden', position: 'relative',
      fontFamily: dFont.mono, fontSize: 12, letterSpacing: '0.12em', color: D.ink,
    }}>
      <div style={{ animation: 'd-tick 12s linear infinite', display: 'flex', flexDirection: 'column' }}>
        {[...items, ...items].map((t, i) => (
          <div key={i} style={{ height: 28, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: D.sage }}>●</span>{t}
          </div>
        ))}
      </div>
    </div>
  );
}

function DLogo() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 32, height: 32, background: D.ink, color: D.paper,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: dFont.mono, fontSize: 14, fontWeight: 600, letterSpacing: '-0.04em',
        position: 'relative',
      }}>
        RM
        <span style={{
          position: 'absolute', top: -3, right: -3, width: 8, height: 8,
          borderRadius: '50%', background: D.signal, animation: 'd-pulse 1.6s ease-in-out infinite',
        }}></span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: dFont.sans, fontSize: 16, color: D.ink, fontWeight: 600, letterSpacing: '-0.01em' }}>RM Psyllium</div>
        <div style={{ fontFamily: dFont.mono, fontSize: 9, color: D.inkSoft, letterSpacing: '0.18em', marginTop: 3 }}>● LIVE FROM UNJHA</div>
      </div>
    </div>
  );
}

function DNav() {
  const link = { fontFamily: dFont.sans, fontSize: 13, color: D.ink, textDecoration: 'none', fontWeight: 500 };
  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '20px 56px', borderBottom: `1px solid ${D.rule}`, background: D.paper,
    }}>
      <DLogo />
      <div style={{ display: 'flex', gap: 28 }}>
        {['Live feed', 'Products', 'Quality', 'Facility', 'Logistics', 'Sourcing', 'Contact'].map(t => (
          <a key={t} href="#" style={link}>{t}</a>
        ))}
      </div>
      <a href="#" style={{
        fontFamily: dFont.sans, fontSize: 13, color: D.paper, background: D.ink,
        padding: '10px 18px', textDecoration: 'none', fontWeight: 600,
        display: 'inline-flex', alignItems: 'center', gap: 8,
      }}>
        <span style={{ width: 7, height: 7, background: D.signal, borderRadius: '50%', animation: 'd-pulse 1.6s ease-in-out infinite' }}></span>
        Book a call
      </a>
    </nav>
  );
}

function DHero() {
  const stats = [
    'Roller line 02 · 487 kg/hr · 99.2% husk yield',
    'Silo 04 · receiving · Banaskantha lot B-2641',
    'QC NIR · batch RM-26-0512 · purity 99.4%',
    'Bagging line 01 · 25kg sacks · 1,240 done today',
    'Container loading · MUNDRA bound · 19/24 pallets',
    'Wet lab · HPLC running · Salmonella absent',
  ];

  return (
    <section style={{ padding: '48px 56px 64px', background: D.paper, color: D.ink, position: 'relative', overflow: 'hidden' }}>
      {/* status bar */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontFamily: dFont.mono, fontSize: 11, color: D.inkSoft, letterSpacing: '0.16em',
        textTransform: 'uppercase', paddingBottom: 18, marginBottom: 48, borderBottom: `1px solid ${D.rule}`,
      }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: D.signal, animation: 'd-pulse 1.6s ease-in-out infinite' }}></span>
          Live · 16 May 2026 · 14:48 IST
        </span>
        <span>Unjha, GJ · 23°48′N 72°44′E · 27°C · clear</span>
        <span style={{ color: D.amber }}>FACILITY · ONLINE</span>
        <span>Shift B / 8 of 9 ops on-floor</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 56, alignItems: 'start' }}>
        <div>
          <div style={{ fontFamily: dFont.mono, fontSize: 11, color: D.sage, letterSpacing: '0.22em', marginBottom: 28 }}>
            ● BROADCASTING NOW · CH 01–04
          </div>
          <h1 style={{
            fontFamily: dFont.sans, fontSize: 96, lineHeight: 0.94, color: D.ink, margin: 0,
            letterSpacing: '-0.04em', fontWeight: 500,
          }}>
            Watch your<br/>
            psyllium<br/>
            <span style={{ color: D.signal }}>get made.</span>
          </h1>
          <p style={{
            fontFamily: dFont.sans, fontSize: 18, lineHeight: 1.5, color: D.inkSoft,
            maxWidth: 520, marginTop: 36, fontWeight: 400,
          }}>
            Four live cameras inside our Unjha facility. Roller line, QC bench,
            bagging, container loading. No edits, no filters — the same feed
            our buyers in Frankfurt and São Paulo are watching right now.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 36, flexWrap: 'wrap' }}>
            <a href="#" style={{
              fontFamily: dFont.sans, fontSize: 14, color: D.paper, background: D.amber,
              padding: '14px 22px', textDecoration: 'none', fontWeight: 600,
            }}>Book a virtual facility tour →</a>
            <a href="#" style={{
              fontFamily: dFont.sans, fontSize: 14, color: D.ink, padding: '14px 22px',
              textDecoration: 'none', fontWeight: 500, border: `1px solid ${D.rule}`,
            }}>Request a sample</a>
          </div>
          <div style={{ marginTop: 40, border: `1px solid ${D.rule}`, padding: '16px 20px', background: D.paperAlt }}>
            <div style={{ fontFamily: dFont.mono, fontSize: 10, color: D.inkSoft, letterSpacing: '0.18em', marginBottom: 8 }}>● FLOOR TICKER · last 90 sec</div>
            <DTicker items={stats} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <DLiveCam label="CAM 01" location="ROLLER LINE 02" ts="14:48:02" kind={1} accent={D.sage} />
          <DLiveCam label="CAM 02" location="QC · NIR BENCH" ts="14:48:02" kind={2} accent={D.amber} />
          <DLiveCam label="CAM 03" location="BAGGING · 25KG" ts="14:48:02" kind={3} accent={D.sage} />
          <DLiveCam label="CAM 04" location="LOADING · GATE 2" ts="14:48:02" kind={4} accent={D.signal} />
        </div>
      </div>

      {/* big counter strip */}
      <div style={{
        marginTop: 56, display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
        border: `1px solid ${D.rule}`, background: D.paperAlt,
      }}>
        {[
          ['487', 'kg/hr', 'Line 02 throughput'],
          ['99.4%', 'purity', 'Latest QC pass'],
          ['1,240', 'sacks', 'Bagged today'],
          ['8 of 9', 'ops', 'On-floor · shift B'],
          ['4 hr', 'avg', 'RFQ response'],
        ].map(([n, u, l], i) => (
          <div key={i} style={{
            padding: '24px 22px', borderLeft: i ? `1px solid ${D.ruleSoft}` : 'none',
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontFamily: dFont.sans, fontSize: 36, fontWeight: 500, color: D.ink, letterSpacing: '-0.03em', animation: 'd-count 1s ease-out' }}>{n}</span>
              <span style={{ fontFamily: dFont.mono, fontSize: 11, color: D.amber, letterSpacing: '0.14em' }}>{u}</span>
            </div>
            <div style={{ fontFamily: dFont.mono, fontSize: 10, color: D.inkSoft, letterSpacing: '0.16em', marginTop: 6, textTransform: 'uppercase' }}>{l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function DMarquee() {
  const items = ['● ISO 22000', '● FSSAI', '● HACCP', '● GMP', '● USDA Organic*', '● EU Organic*', '● Kosher*', '● Halal*', '● BRCGS-ready', '● Non-GMO', '● USP / EP'];
  return (
    <section style={{ background: D.amber, color: D.paper, padding: '14px 0', overflow: 'hidden', borderTop: `1px solid ${D.paper}` }}>
      <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'd-marquee 40s linear infinite', fontFamily: dFont.mono, fontSize: 13, fontWeight: 600, letterSpacing: '0.16em' }}>
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i} style={{ paddingRight: 56 }}>{t}</span>
        ))}
      </div>
    </section>
  );
}

function DProducts() {
  return (
    <section style={{ padding: '96px 56px', background: D.paper, color: D.ink, borderBottom: `1px solid ${D.rule}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderTop: `1px solid ${D.ink}`, paddingTop: 18, marginBottom: 36 }}>
        <span style={{ fontFamily: dFont.mono, fontSize: 11, color: D.signal, letterSpacing: '0.16em' }}>§01 · CATALOGUE</span>
        <span style={{ fontFamily: dFont.mono, fontSize: 11, color: D.inkSoft, letterSpacing: '0.16em' }}>09 SKUS · click any row to open the datasheet</span>
      </div>
      <h2 style={{ fontFamily: dFont.sans, fontSize: 80, color: D.ink, margin: '0 0 40px', letterSpacing: '-0.04em', fontWeight: 500, lineHeight: 0.94 }}>
        One line. Nine grades. <span style={{ color: D.sage }}>Zero blends.</span>
      </h2>
      <div style={{ border: `1px solid ${D.rule}` }}>
        {[
          ['PSH-99', 'Husk · 99%', '≥ 99.0%', '30/40', 'Pharma · clinical', 'IN'],
          ['PSH-98', 'Husk · 98%', '≥ 98.0%', '40/60', 'Premium supplement', 'IN'],
          ['PSH-95', 'Husk · 95%', '≥ 95.0%', '40/60/80', 'General food', 'IN'],
          ['PHP-FN', 'Husk Powder', 'Fine', '80/100', 'Drink mixes, bakery', 'IN'],
          ['PSD-WH', 'Whole Seed', 'Cleaned', '—', 'Pet food, milling', 'IN'],
          ['PSI-IN', 'Industrial Powder', 'Tech', '60/80', 'Drilling mud, binders', 'IN'],
          ['PSP-RX', 'Pharma Grade', 'USP/EP', '30/40', 'OTC laxatives', 'MTO'],
          ['PSF-FD', 'Food Grade', 'BRCGS-ready', '40/60', 'Cereal, bakery', 'IN'],
          ['PSO-OR', 'Organic', 'USDA/EU*', '40/60/80', 'Organic SKUs', 'MTO'],
        ].map((p, i) => (
          <div key={p[0]} style={{
            display: 'grid', gridTemplateColumns: '100px 1.4fr 1fr 1fr 1.4fr 80px',
            padding: '18px 20px', gap: 16, alignItems: 'center',
            borderTop: i ? `1px solid ${D.ruleSoft}` : 'none',
            fontFamily: dFont.mono, fontSize: 13,
          }}>
            <span style={{ color: D.amber, fontWeight: 500, letterSpacing: '0.1em' }}>{p[0]}</span>
            <span style={{ fontFamily: dFont.sans, fontSize: 16, fontWeight: 500, color: D.ink }}>{p[1]}</span>
            <span style={{ color: D.inkSoft }}>{p[2]}</span>
            <span style={{ color: D.inkSoft }}>{p[3]}</span>
            <span style={{ color: D.inkSoft }}>{p[4]}</span>
            <span style={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: p[5] === 'IN' ? D.sage : D.signal, animation: p[5] === 'IN' ? 'd-pulse 2s ease-in-out infinite' : 'none' }}></span>
              <span style={{ color: D.inkSoft, letterSpacing: '0.14em' }}>{p[5]}</span>
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

function DCTA() {
  return (
    <section style={{ padding: '96px 56px', background: D.paperAlt, color: D.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ borderTop: `1px solid ${D.ink}`, paddingTop: 18, marginBottom: 36, display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontFamily: dFont.mono, fontSize: 11, color: D.signal, letterSpacing: '0.16em' }}>§02 · TALK</span>
        <span style={{ fontFamily: dFont.mono, fontSize: 11, color: D.inkSoft, letterSpacing: '0.16em' }}>Avg. response · 4 hrs · 24/5</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 64, alignItems: 'center' }}>
        <h2 style={{ fontFamily: dFont.sans, fontSize: 96, color: D.ink, margin: 0, letterSpacing: '-0.045em', fontWeight: 500, lineHeight: 0.92 }}>
          See the line.<br/>Send the spec.<br/><span style={{ color: D.amber }}>Ship the FCL.</span>
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            ['Book a virtual facility tour', '20 min · live walk-through with our QC head', D.amber],
            ['Upload your spec sheet', 'Quote in 4 business hours · pricing against your params', D.ink],
            ['Request a 250g sample', 'Free, with full COA · FedEx, 5–7 days', D.ink],
          ].map(([t, sub, bg], i) => (
            <a key={i} href="#" style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '20px 24px', background: i === 0 ? bg : 'transparent', color: i === 0 ? D.paper : D.ink,
              textDecoration: 'none', border: i === 0 ? 'none' : `1px solid ${D.rule}`,
            }}>
              <div>
                <div style={{ fontFamily: dFont.sans, fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>{t}</div>
                <div style={{ fontFamily: dFont.mono, fontSize: 12, opacity: 0.75, letterSpacing: '0.08em', marginTop: 4 }}>{sub}</div>
              </div>
              <span style={{ fontFamily: dFont.sans, fontSize: 20 }}>→</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function DFooter() {
  return (
    <footer style={{ background: D.paper, color: D.ink, padding: '56px 56px 28px', borderTop: `1px solid ${D.rule}` }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 48 }}>
        <div>
          <DLogo />
          <p style={{ fontFamily: dFont.sans, fontSize: 13, color: D.inkSoft, lineHeight: 1.6, marginTop: 18, maxWidth: 280, fontWeight: 400 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
          <div style={{ marginTop: 14, fontFamily: dFont.mono, fontSize: 10, color: D.inkSoft, opacity: 0.6, letterSpacing: '0.16em' }}>
            IEC 0124007841 · APEDA RCMC/UNJ/2024
          </div>
        </div>
        {[
          ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Powder', 'Pharma', 'Industrial', 'Organic']],
          ['Watch', ['Live cameras', 'Facility tour', 'Process video', 'Founder talk']],
          ['Contact', ['+91 2767 333 444', 'export@rmpsyllium.com', 'WhatsApp', 'Book a call']],
        ].map(([h, items], i) => (
          <div key={i}>
            <div style={{ fontFamily: dFont.mono, fontSize: 10, letterSpacing: '0.22em', color: D.inkSoft, textTransform: 'uppercase' }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 16 }}>
              {items.map((t, j) => (
                <a key={j} href="#" style={{ fontFamily: dFont.sans, fontSize: 13, color: D.ink, opacity: 0.85, textDecoration: 'none' }}>{t}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 48, paddingTop: 18, borderTop: `1px solid ${D.rule}`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: dFont.mono, fontSize: 10, color: D.inkSoft, opacity: 0.55, letterSpacing: '0.18em',
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD</span>
        <span>SITEMAP · PRIVACY · TERMS</span>
      </div>
    </footer>
  );
}

function VariantD() {
  return (
    <div style={{ background: D.paper, fontFamily: dFont.sans, color: D.ink, width: '100%' }}>
      <DNav />
      <DHero />
      <DMarquee />
      <DProducts />
      <DCTA />
      <DFooter />
    </div>
  );
}

window.VariantD = VariantD;
