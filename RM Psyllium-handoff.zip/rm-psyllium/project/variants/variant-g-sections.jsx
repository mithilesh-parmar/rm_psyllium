// Variant G — sections. See variant-g-shared.jsx for helpers.
// Light, minimal, story-driven. White + cream + sage. Motion via Reveal + Counter.

// ─────────────────────────────────────────────────────────────
// NAV
// ─────────────────────────────────────────────────────────────
function GLogo({ size = 'md' }) {
  const isS = size === 'sm';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: isS ? 32 : 38, height: isS ? 32 : 38, borderRadius: '50%',
        border: `1.2px solid ${G.ink}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: gFont.display, fontSize: isS ? 16 : 19, color: G.ink,
        fontStyle: 'italic', letterSpacing: '-0.02em'
      }}>rm</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: gFont.display, fontSize: isS ? 18 : 22, color: G.ink, letterSpacing: '-0.01em', fontWeight: 500 }}>RM Psyllium</div>
        <div style={{ fontFamily: gFont.mono, fontSize: 9, color: G.inkMute, letterSpacing: '0.22em', marginTop: 4 }}>UNJHA · GUJARAT · EST 2024</div>
      </div>
    </div>);

}

// Language dropdown — small button + popover. Self-contained.
function GLanguageMenu() {
  const [open, setOpen] = React.useState(false);
  const [current, setCurrent] = React.useState('EN');
  const ref = React.useRef(null);
  const LANGS = [
    ['EN', 'English'],
    ['ES', 'Español'],
    ['DE', 'Deutsch'],
    ['FR', 'Français'],
    ['IT', 'Italiano'],
    ['PT', 'Português'],
    ['AR', 'العربية'],
    ['ZH', '中文'],
    ['JA', '日本語'],
    ['KO', '한국어'],
    ['HI', 'हिन्दी'],
    ['GU', 'ગુજરાતી'],
  ];
  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [open]);
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(o => !o)}
        aria-expanded={open}
        aria-haspopup="listbox"
        className="g-cta-ghost"
        style={{
          fontFamily: gFont.mono, fontSize: 11, color: G.ink, letterSpacing: '0.16em',
          background: 'transparent', border: `1px solid ${G.rule}`, borderRadius: 999,
          padding: '8px 12px 8px 14px', cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 8,
          transition: 'border-color .2s, background .2s',
        }}
      >
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: G.sage }}></span>
        {current}
        <span style={{
          display: 'inline-block', transition: 'transform .25s',
          transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
          fontSize: 9, color: G.inkMute,
        }}>▾</span>
      </button>
      {open && (
        <div
          role="listbox"
          style={{
            position: 'absolute', top: 'calc(100% + 8px)', right: 0,
            background: G.white, border: `1px solid ${G.rule}`,
            boxShadow: '0 18px 40px -22px rgba(26,28,24,0.25)',
            minWidth: 200, padding: 4, zIndex: 60,
            maxHeight: 360, overflowY: 'auto',
            animation: 'g-rise .25s cubic-bezier(.2,.7,.3,1)',
          }}
        >
          {LANGS.map(([code, name]) => {
            const active = code === current;
            return (
              <button
                key={code}
                role="option"
                aria-selected={active}
                onClick={() => { setCurrent(code); setOpen(false); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  width: '100%', padding: '10px 12px',
                  background: active ? G.cream : 'transparent', border: 'none',
                  fontFamily: gFont.body, fontSize: 13, color: G.ink,
                  textAlign: 'left', cursor: 'pointer', borderRadius: 4,
                  fontWeight: active ? 500 : 400,
                  transition: 'background .15s',
                }}
                onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = G.paper; }}
                onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
              >
                <span style={{ fontFamily: gFont.mono, fontSize: 11, color: active ? G.sage : G.inkMute, letterSpacing: '0.14em', minWidth: 22 }}>{code}</span>
                <span style={{ flex: 1 }}>{name}</span>
                {active && <span style={{ fontSize: 12, color: G.sage }}>✓</span>}
              </button>
            );
          })}
          <div style={{
            padding: '10px 12px 6px', borderTop: `1px solid ${G.ruleSoft}`, marginTop: 4,
            fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.14em',
          }}>
            More languages coming — tell us which you need.
          </div>
        </div>
      )}
    </div>
  );
}

function GNav() {
  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '20px 56px',
      background: 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(12px)',
      borderBottom: `1px solid ${G.ruleSoft}`,
      position: 'sticky', top: 0, zIndex: 50
    }}>
      <GLogo />
      <div style={{ display: 'flex', gap: 32 }}>
        {['Products', 'Quality', 'Facility', 'Story', 'Education', 'Contact'].map((t) =>
        <a key={t} href="#" className="g-nav-link" style={{
          fontFamily: gFont.body, fontSize: 13, color: G.ink, textDecoration: 'none',
          letterSpacing: '0.01em', fontWeight: 500
        }}>{t}</a>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <GLanguageMenu />
        <a href="#" className="g-cta" style={{
          fontFamily: gFont.body, fontSize: 13, color: G.white, background: G.ink,
          padding: '11px 20px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
          display: 'inline-flex', alignItems: 'center', gap: 8
        }}>
          Book a call
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: G.sage, animation: 'g-pulse 1.8s ease-in-out infinite' }}></span>
        </a>
      </div>
    </nav>);

}

// ─────────────────────────────────────────────────────────────
// HERO
// ─────────────────────────────────────────────────────────────
function GHero() {
  return (
    <section style={{ padding: '64px 56px 96px', background: G.white, position: 'relative', overflow: 'hidden' }}>
      {/* Soft sage glow upper-right — sets mood without being heavy. */}
      <div style={{
        position: 'absolute', top: '-20%', right: '-15%',
        width: 700, height: 700, borderRadius: '50%',
        background: `radial-gradient(circle, ${G.sagePale} 0%, transparent 70%)`,
        opacity: 0.55,
        animation: 'g-drift 22s ease-in-out infinite',
        pointerEvents: 'none'
      }} />

      <div style={{ position: 'relative' }}>
        <Reveal delay={0}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            fontFamily: gFont.mono, fontSize: 11, color: G.sage,
            letterSpacing: '0.22em', textTransform: 'uppercase',
            padding: '7px 14px', border: `1px solid ${G.sagePale}`,
            background: 'rgba(223,228,207,0.3)', borderRadius: 999
          }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: G.sage, animation: 'g-pulse 1.8s ease-in-out infinite' }}></span>
            2026 harvest · direct from Unjha, Gujarat
          </div>
        </Reveal>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 64, marginTop: 28, alignItems: 'end' }}>
          <div>
            <Reveal delay={120}>
              <h1 style={{
                fontFamily: gFont.display, fontSize: 124, lineHeight: 0.96, color: G.ink, margin: 0,
                letterSpacing: '-0.025em', fontWeight: 400, textWrap: 'pretty'
              }}>
                The world's<br />
                <span style={{ fontStyle: 'italic', color: G.sage }}>quietest</span> psyllium,<br />
                made loud.
              </h1>
            </Reveal>
            <Reveal delay={280}>
              <p style={{
                fontFamily: gFont.body, fontSize: 19, lineHeight: 1.55, color: G.inkSoft,
                maxWidth: 540, marginTop: 36, fontWeight: 400
              }}>
                We grow, mill and export pharma-, food- and industrial-grade
                psyllium from a new 12,000&nbsp;MT facility in Unjha, Gujarat —
                the village where psyllium has been traded for a century. Built
                for global buyers who deserve more than a Whatsapp price quote.
              </p>
            </Reveal>
            <Reveal delay={420}>
              <div style={{ display: 'flex', gap: 14, marginTop: 40, alignItems: 'center', flexWrap: 'wrap' }}>
                <a href="#" className="g-cta" style={{
                  fontFamily: gFont.body, fontSize: 14, color: G.white, background: G.ink,
                  padding: '16px 26px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
                  display: 'inline-flex', alignItems: 'center', gap: 10
                }}>
                  Schedule a sourcing call
                  <span style={{ fontSize: 16 }}>→</span>
                </a>
                <a href="#" className="g-cta g-cta-ghost" style={{
                  fontFamily: gFont.body, fontSize: 14, color: G.ink, background: 'transparent',
                  padding: '16px 26px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
                  border: `1px solid ${G.rule}`
                }}>Download spec PDF · 2.4 MB</a>
                <a href="#" className="g-link" style={{
                  fontFamily: gFont.body, fontSize: 14, color: G.ink, padding: '16px 6px',
                  textDecoration: 'none', fontWeight: 500
                }}>Watch the 3-min film</a>
              </div>
            </Reveal>
          </div>

          <Reveal delay={520}>
            <div style={{ position: 'relative' }}>
              {/* hero image — swap URL for your own facility/farm photography when you have it */}
              <div style={{
                width: '100%', aspectRatio: '4/5', overflow: 'hidden',
                background: G.sagePale,
                position: 'relative',
              }}>
                <img
                  src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
                  alt="Golden grain fields at sunset — placeholder for real psyllium farm photography from Banaskantha, Gujarat"
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                />
                <div style={{
                  position: 'absolute', left: 16, bottom: 14,
                  fontFamily: gFont.mono, fontSize: 10, letterSpacing: '0.18em',
                  textTransform: 'uppercase',
                  color: 'rgba(255,255,255,0.92)',
                  textShadow: '0 1px 8px rgba(0,0,0,0.4)',
                }}>Banaskantha · harvest at dawn</div>
              </div>
              {/* floating "what happens when you reach out" card */}
              <div className="g-card" style={{
                position: 'absolute', left: -32, bottom: -32, width: 320,
                background: G.white, border: `1px solid ${G.rule}`,
                padding: '22px 24px 20px',
                boxShadow: '0 12px 28px -16px rgba(26,28,24,0.18)'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                  <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.sage, letterSpacing: '0.22em', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: G.sage, animation: 'g-pulse 1.8s ease-in-out infinite' }}></span>
                    HOW IT WORKS
                  </span>
                  <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.16em' }}>3 steps</span>
                </div>
                <div style={{ fontFamily: gFont.display, fontSize: 26, color: G.ink, fontWeight: 500, lineHeight: 1.05, letterSpacing: '-0.015em' }}>From hello to <span style={{ fontStyle: 'italic', color: G.sage }}>first container.</span></div>
                <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {[
                    ['01', 'Call', '20 min · same-day, direct line'],
                    ['02', 'Sample', '250g · FedEx · 5–7 days worldwide'],
                    ['03', 'Quote', 'Landed price within 4 hrs'],
                  ].map(([n, t, sub]) => (
                    <div key={n} style={{ display: 'flex', gap: 14, alignItems: 'baseline' }}>
                      <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.12em', fontWeight: 500, minWidth: 22 }}>{n}</span>
                      <div>
                        <div style={{ fontFamily: gFont.display, fontSize: 17, color: G.ink, fontWeight: 500, letterSpacing: '-0.01em' }}>{t}</div>
                        <div style={{ fontFamily: gFont.body, fontSize: 12, color: G.inkMute, marginTop: 2 }}>{sub}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <a href="#" className="g-cta" style={{
                  marginTop: 18, display: 'inline-flex', alignItems: 'center', justifyContent: 'space-between',
                  fontFamily: gFont.body, fontSize: 13, fontWeight: 500,
                  color: G.white, background: G.ink,
                  padding: '11px 16px', borderRadius: 999, textDecoration: 'none', width: '100%',
                }}>
                  Start step 01 · book the call
                  <span>→</span>
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// TRUST BAND — light marquee of certifications
// ─────────────────────────────────────────────────────────────
function GTrustBand() {
  const items = ['ISO 22000', 'FSSAI', 'HACCP', 'GMP', 'USDA Organic*', 'EU Organic*', 'Kosher*', 'Halal*', 'BRCGS-ready', 'Non-GMO', 'USP / EP'];
  return (
    <section style={{
      padding: '32px 0', background: G.cream,
      borderTop: `1px solid ${G.rule}`, borderBottom: `1px solid ${G.rule}`,
      overflow: 'hidden'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 56, padding: '0 56px', marginBottom: 20 }}>
        <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.22em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
          Compliance stack
        </span>
        <span style={{ height: 1, background: G.rule, flex: 1 }}></span>
        <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.18em', whiteSpace: 'nowrap' }}>
          Audited or in-progress
        </span>
      </div>
      <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'g-marquee 48s linear infinite' }}>
        {[...items, ...items, ...items].map((t, i) =>
        <span key={i} style={{
          display: 'inline-flex', alignItems: 'center', gap: 14,
          paddingRight: 56, fontFamily: gFont.display, fontSize: 32,
          color: G.ink, letterSpacing: '-0.01em', fontWeight: 400
        }}>
            {t}
            <span style={{ color: G.sage, fontSize: 14 }}>✦</span>
          </span>
        )}
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// CHAPTER STORY — Seed / Land / Mill / World
// ─────────────────────────────────────────────────────────────
const CHAPTERS = [
{
  no: 'I',
  title: 'The seed',
  sub: '\u2003Plantago ovata',
  body: 'A wild plant tamed across the arid belts of Gujarat and Rajasthan. Sown in November, drinks little, asks for nothing, and gives back the world\u2019s finest soluble fibre. Eighty percent of the global supply still comes from a 200-km radius around our facility.',
  stat: '120 days',
  statLabel: 'seed to harvest',
  tone: 'sage'
},
{
  no: 'II',
  title: 'The land',
  sub: '\u2003Banaskantha · Patan · Mehsana',
  body: '4,500 acres under direct contract with 1,200+ smallholder farmers. Three-generation relationships, no middlemen, fair prices locked at sowing. We pay above APMC, and we pay on the day of weighing.',
  stat: '1,200+',
  statLabel: 'contracted farmers',
  tone: 'warm'
},
{
  no: 'III',
  title: 'The mill',
  sub: '\u2003GIDC Phase II, Unjha',
  body: 'A new 4.2-acre facility commissioned in 2024. Roller mills with software-controlled gap, in-house NIR & HPLC lab, and a single line so every kilogram is traceable to the exact half-hour it was milled.',
  stat: '12,000 MT',
  statLabel: 'annual capacity',
  tone: 'sage'
},
{
  no: 'IV',
  title: 'The world',
  sub: '\u2003Thirty-eight countries · one operator',
  body: 'FOB Mundra, CIF anywhere. We handle phyto, fumigation, EUR.1, certificate of origin, and the customs questions you\u2019d rather not field. A 47-parameter COA arrives before the bill of lading.',
  stat: '38',
  statLabel: 'export markets',
  tone: 'warm'
}];


function GStory() {
  return (
    <section style={{ padding: '120px 56px', background: G.white }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>Our story</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
        </div>
      </Reveal>
      <Reveal delay={80}>
        <h2 style={{
          fontFamily: gFont.display, fontSize: 80, color: G.ink, margin: '0 0 80px',
          letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400, maxWidth: 1100
        }}>
          Four chapters,<br />one obsession with the <span style={{ fontStyle: 'italic', color: G.sage }}>cleanest husk.</span>
        </h2>
      </Reveal>
      {CHAPTERS.map((c, i) =>
      <Reveal key={c.no} delay={i * 80}>
          <div style={{
          display: 'grid', gridTemplateColumns: '120px 1fr 1.1fr',
          gap: 56, alignItems: 'start',
          padding: '40px 0', borderTop: `1px solid ${G.rule}`,
          ...(i === CHAPTERS.length - 1 ? { borderBottom: `1px solid ${G.rule}` } : {})
        }}>
            <div>
              <div style={{ fontFamily: gFont.display, fontStyle: 'italic', fontSize: 56, color: G.sage, lineHeight: 1, letterSpacing: '-0.02em' }}>{c.no}</div>
              <div style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.2em', marginTop: 10 }}>0{i + 1} / 04</div>
            </div>
            <div>
              <h3 style={{ fontFamily: gFont.display, fontSize: 48, color: G.ink, margin: 0, letterSpacing: '-0.02em', fontWeight: 400, lineHeight: 1.05 }}>{c.title}</h3>
              <div style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.16em', marginTop: 10, textTransform: 'uppercase' }}>{c.sub}</div>
              <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, marginTop: 20, fontWeight: 400 }}>{c.body}</p>
              <div style={{ marginTop: 24, display: 'flex', alignItems: 'baseline', gap: 14 }}>
                <span style={{ fontFamily: gFont.display, fontSize: 36, color: G.ink, letterSpacing: '-0.02em', fontWeight: 500 }}>{c.stat}</span>
                <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{c.statLabel}</span>
              </div>
            </div>
            <GPlaceholder label={`Chapter ${i + 1} · ${c.title.toLowerCase()}`} ratio="5/4" tone={c.tone} />
          </div>
        </Reveal>
      )}
    </section>);

}

// ─────────────────────────────────────────────────────────────
// PLANT & MACHINERY — equipment cards with specs
// ─────────────────────────────────────────────────────────────
const MACHINES = [
{ code: 'M01', name: 'Roller mill line 02', mfr: 'Bühler · Switzerland', specs: [['Throughput', '500 kg/hr'], ['Gap control', 'PLC ±5μm'], ['Wear life', '8,000 hr']], note: 'Software-controlled roller gap means the same mesh, every kilogram. No chemical bleaching, no de-husking acids.', tone: 'paper' },
{ code: 'M02', name: 'Air classifier', mfr: 'Hosokawa · Germany', specs: [['Cut size', '25–150μm'], ['Capacity', '800 kg/hr'], ['Yield', '99.4%']], note: 'Splits husk from seed kernel by aerodynamic drag, not friction. Mucilage stays cold, stays intact.', tone: 'paper' },
{ code: 'M03', name: 'NIR spectrometer', mfr: 'FOSS NIRS DS2500', specs: [['Wavelength', '400–2500 nm'], ['Scan time', '8 sec'], ['Library', '12,400 spectra']], note: 'Every 500 kg sub-batch is fingerprinted. Spectra are archived — we can re-run a complaint two years later.', tone: 'sage' },
{ code: 'M04', name: 'HPLC bench', mfr: 'Agilent 1260 Infinity II', specs: [['Columns', '4 × Zorbax'], ['Detection', 'UV-DAD + RID'], ['Run time', '11 min']], note: 'Wet-lab quantification of purity, ash, swelling volume. SGS-cross-validated quarterly.', tone: 'sage' },
{ code: 'M05', name: 'Magnetic separator', mfr: 'Eriez · India', specs: [['Field strength', '12,000 G'], ['Throughput', '2 MT/hr'], ['Catch', '< 50 μm Fe']], note: 'Pulls every speck of ferrous contamination before milling. Buyers don\u2019t see foreign matter in their COA.', tone: 'paper' },
{ code: 'M06', name: 'De-stoner + sieve', mfr: 'Cimbria · Denmark', specs: [['Capacity', '3 MT/hr'], ['Foreign matter', '< 0.5%'], ['Sieve decks', '5']], note: 'Density separation + vibratory sieve. Bird-strike from the field gets caught here, never in your container.', tone: 'paper' },
{ code: 'M07', name: 'Storage silos × 8', mfr: 'GSI · India', specs: [['Capacity', '8,400 MT'], ['Aeration', 'Active 24/7'], ['Sensors', 'Temp + RH per silo']], note: 'Eight silos, one per mesh size. No re-mixing between SKUs. Aeration keeps moisture < 10% year-round.', tone: 'warm' },
{ code: 'M08', name: 'Big-bag filler', mfr: 'Spiroflow · UK', specs: [['Speed', '24 bags/hr'], ['Accuracy', '±0.1%'], ['Bag sizes', '500 / 1,000 kg']], note: 'Food-grade PE liner, gentle filling, no compaction. Drop-tested for sea freight.', tone: 'warm' }];


function GMachinery() {
  return (
    <section style={{ padding: '140px 56px', background: G.paper }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>Plant & machinery</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
        </div>
      </Reveal>
      <Reveal delay={80}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 80, marginBottom: 96, alignItems: 'end' }}>
          <h2 style={{
            fontFamily: gFont.display, fontSize: 80, color: G.ink, margin: 0,
            letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400
          }}>
            Eight machines.<br />
            One <span style={{ fontStyle: 'italic', color: G.sage }}>uncompromising</span> line.
          </h2>
          <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, margin: 0, maxWidth: 460, fontWeight: 400 }}>
            Most psyllium in the market is milled on a forty-year-old roller
            line, bleached, and sold. Ours isn't. Every machine in our facility
            was specified for purity, not throughput. Walk the line below —
            machine by machine, in the order the seed passes through.
          </p>
        </div>
      </Reveal>

      {/* Alternating editorial blocks — image on one side, story on the other. */}
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {MACHINES.map((m, i) => {
          const imageRight = i % 2 === 1;
          return (
            <Reveal key={m.code}>
              <article style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: 80, alignItems: 'center',
                padding: '56px 0',
                borderTop: `1px solid ${G.rule}`,
                ...(i === MACHINES.length - 1 ? { borderBottom: `1px solid ${G.rule}` } : {}),
              }}>
                {/* image side */}
                <div className="g-equip" style={{
                  order: imageRight ? 2 : 1,
                  overflow: 'hidden', position: 'relative',
                }}>
                  <div className="g-equip-img">
                    <GPlaceholder label={`${m.code} · ${m.name.toLowerCase()}`} ratio="5/4" tone={m.tone} />
                  </div>
                  <span style={{
                    position: 'absolute', top: 14, left: 14,
                    fontFamily: gFont.mono, fontSize: 10, color: G.white,
                    background: 'rgba(26,28,24,0.78)',
                    padding: '5px 10px', letterSpacing: '0.2em',
                  }}>{m.code}</span>
                </div>

                {/* content side */}
                <div style={{ order: imageRight ? 1 : 2, paddingLeft: imageRight ? 0 : 24, paddingRight: imageRight ? 24 : 0 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, marginBottom: 14 }}>
                    <span style={{ fontFamily: gFont.display, fontStyle: 'italic', fontSize: 56, color: G.sage, letterSpacing: '-0.02em', lineHeight: 1 }}>
                      0{i + 1}
                    </span>
                    <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
                      Step {i + 1} of {MACHINES.length}
                    </span>
                  </div>
                  <h3 style={{
                    fontFamily: gFont.display, fontSize: 56, color: G.ink, margin: 0,
                    letterSpacing: '-0.025em', lineHeight: 1.02, fontWeight: 400,
                  }}>{m.name}</h3>
                  <div style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.18em', marginTop: 12, textTransform: 'uppercase' }}>
                    {m.mfr}
                  </div>
                  <p style={{ fontFamily: gFont.body, fontSize: 17, color: G.inkSoft, lineHeight: 1.6, marginTop: 24, marginBottom: 28, fontWeight: 400, maxWidth: 520 }}>
                    {m.note}
                  </p>
                  <div style={{
                    display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
                    borderTop: `1px solid ${G.rule}`, paddingTop: 18,
                  }}>
                    {m.specs.map(([k, v], j) => (
                      <div key={k} style={{
                        paddingLeft: j ? 20 : 0, paddingRight: j < m.specs.length - 1 ? 20 : 0,
                        borderLeft: j ? `1px solid ${G.ruleSoft}` : 'none',
                      }}>
                        <div style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{k}</div>
                        <div style={{ fontFamily: gFont.display, fontSize: 22, color: G.ink, marginTop: 6, letterSpacing: '-0.015em', fontWeight: 500 }}>{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </article>
            </Reveal>
          );
        })}
      </div>

      <Reveal delay={120}>
        <div style={{
          marginTop: 80, padding: '32px 36px', background: G.white, border: `1px solid ${G.rule}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 32
        }}>
          <div>
            <div style={{ fontFamily: gFont.display, fontSize: 26, color: G.ink, letterSpacing: '-0.015em', fontWeight: 500 }}>See the line for yourself.</div>
            <div style={{ fontFamily: gFont.body, fontSize: 14, color: G.inkMute, marginTop: 6, fontWeight: 400 }}>
              A 90-second walk-through of every machine, in the order the seed passes through. No sign-up.
            </div>
          </div>
          <a href="#" className="g-cta" style={{
            fontFamily: gFont.body, fontSize: 14, color: G.white, background: G.sage,
            padding: '14px 24px', borderRadius: 999, textDecoration: 'none', fontWeight: 500,
            display: 'inline-flex', alignItems: 'center', gap: 10, whiteSpace: 'nowrap',
          }}>
            <span style={{
              width: 24, height: 24, borderRadius: '50%', background: G.white, color: G.sage,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10,
            }}>▶</span>
            Watch the virtual tour
          </a>
        </div>
      </Reveal>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// PROCESS DIAGRAM — animated seed-to-powder flow
// ─────────────────────────────────────────────────────────────
function GProcessDiagram() {
  const stages = [
    { n: '01', t: 'Seed', phase: 'seed' },
    { n: '02', t: 'Clean', phase: 'seed' },
    { n: '03', t: 'Condition', phase: 'seed' },
    { n: '04', t: 'Mill', phase: 'split' },
    { n: '05', t: 'Grade', phase: 'husk' },
    { n: '06', t: 'NIR', phase: 'husk' },
    { n: '07', t: 'Lab', phase: 'husk' },
    { n: '08', t: 'Pack', phase: 'powder' },
    { n: '09', t: 'Ship', phase: 'powder' },
  ];
  const CYCLE = 9; // seconds per full traversal
  const DOT_COUNT = 14;

  return (
    <Reveal>
      <div style={{
        margin: '0 0 96px',
        padding: '56px 48px 40px',
        background: G.white, border: `1px solid ${G.rule}`,
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 36 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.22em', textTransform: 'uppercase' }}>
            ◉ Live process flow
          </span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.16em' }}>
            9 stages · 1 line · zero co-packers
          </span>
        </div>

        {/* Phase ribbon ABOVE the diagram — shows material state transition */}
        <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr 3fr 2fr', gap: 0, marginBottom: 24, position: 'relative' }}>
          {[
            ['Seed', 'Whole · cleaned · conditioned', G.warmPale, G.warm],
            ['Split', 'Husk ↔ kernel', G.cream, G.inkSoft],
            ['Husk', 'Graded · NIR-tested · lab-validated', G.sagePale, G.sageDeep],
            ['Packed', 'Shipped', G.creamDeep, G.ink],
          ].map(([label, sub, bg, fg], i) => (
            <div key={i} style={{
              background: bg, padding: '14px 18px',
              borderRight: i < 3 ? `1px solid ${G.ruleSoft}` : 'none',
            }}>
              <div style={{ fontFamily: gFont.mono, fontSize: 10, color: fg, letterSpacing: '0.2em', textTransform: 'uppercase', opacity: 0.85 }}>{label}</div>
              <div style={{ fontFamily: gFont.body, fontSize: 12, color: fg, marginTop: 4, opacity: 0.75 }}>{sub}</div>
            </div>
          ))}
        </div>

        {/* The diagram itself */}
        <div style={{ position: 'relative', height: 140 }}>
          {/* horizontal rail */}
          <div style={{
            position: 'absolute', left: '5%', right: '5%', top: 30, height: 2,
            background: G.ruleSoft, borderRadius: 1,
          }}></div>
          {/* active overlay rail (sage tinted) */}
          <div style={{
            position: 'absolute', left: '5%', right: '5%', top: 30, height: 2,
            background: `linear-gradient(90deg, ${G.warm} 0%, ${G.warm} 28%, ${G.sage} 50%, ${G.sage} 72%, ${G.ink} 100%)`,
            opacity: 0.45, borderRadius: 1,
          }}></div>

          {/* Flowing dots */}
          <div style={{
            position: 'absolute', left: '5%', right: '5%', top: 26, height: 10,
            pointerEvents: 'none',
          }}>
            {Array.from({ length: DOT_COUNT }).map((_, i) => {
              const delay = -(i * CYCLE / DOT_COUNT);
              // Color the dot based on its position via three overlapping dots of different colors
              return (
                <span key={i} style={{
                  position: 'absolute', top: 0, left: 0,
                  width: 8, height: 8, borderRadius: '50%',
                  background: G.warm,
                  animation: `g-flow ${CYCLE}s linear infinite`,
                  animationDelay: `${delay}s`,
                  marginLeft: -4, marginTop: 0,
                }} />
              );
            })}
            {/* Second layer — sage dots offset by half the cycle (represents husk material) */}
            {Array.from({ length: DOT_COUNT }).map((_, i) => {
              const delay = -(i * CYCLE / DOT_COUNT) - CYCLE / 3;
              return (
                <span key={`s${i}`} style={{
                  position: 'absolute', top: 0, left: 0,
                  width: 6, height: 6, borderRadius: '50%',
                  background: G.sage,
                  animation: `g-flow ${CYCLE}s linear infinite`,
                  animationDelay: `${delay}s`,
                  marginLeft: -3, marginTop: 1,
                }} />
              );
            })}
          </div>

          {/* Stage circles — absolute positioned, evenly spaced */}
          {stages.map((s, i) => {
            const leftPct = 5 + (i * 90 / (stages.length - 1));
            const phaseColor =
              s.phase === 'seed' ? G.warm :
              s.phase === 'split' ? G.inkSoft :
              s.phase === 'husk' ? G.sage :
              G.ink;
            return (
              <div key={s.n} style={{
                position: 'absolute', top: 0, left: `${leftPct}%`,
                transform: 'translateX(-50%)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
              }}>
                <div style={{
                  width: 60, height: 60, borderRadius: '50%',
                  background: G.white,
                  border: `1.5px solid ${G.rule}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: gFont.mono, fontSize: 12, color: phaseColor,
                  fontWeight: 600, letterSpacing: '0.04em',
                  position: 'relative', zIndex: 2,
                  animation: `g-stage-glow ${CYCLE}s ease-in-out infinite`,
                  animationDelay: `${(i * CYCLE) / stages.length - 0.2}s`,
                  transition: 'border-color .3s',
                }}>
                  {s.n}
                </div>
                <div style={{
                  fontFamily: gFont.display, fontSize: 16, color: G.ink,
                  fontWeight: 500, letterSpacing: '-0.01em',
                }}>{s.t}</div>
              </div>
            );
          })}
        </div>

        {/* Footer caption */}
        <div style={{
          marginTop: 32, paddingTop: 24, borderTop: `1px solid ${G.ruleSoft}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.14em',
        }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: G.warm }}></span>
            seed material
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: G.sage }}></span>
            graded husk
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 14, height: 4, borderRadius: 2, background: `linear-gradient(90deg, ${G.warm} 0%, ${G.sage} 60%, ${G.ink} 100%)` }}></span>
            material flow (left → right)
          </span>
          <span>cycle · {CYCLE}s</span>
        </div>
      </div>
    </Reveal>
  );
}

// ─────────────────────────────────────────────────────────────
// PROCESS — 9-step timeline
// ─────────────────────────────────────────────────────────────
function GProcess() {
  const steps = [
  ['Sourcing', 'Direct from 1,200+ contracted farmers across Banaskantha, Patan, Mehsana — same villages our family has bought from since 1983.'],
  ['Pre-clean', 'Magnetic separation, de-stoner, vibratory sieve. Foreign matter dropped to under 0.5%.'],
  ['Conditioning', '12-hour rest at 18% humidity to optimise the husk-to-seed split without scorching the mucilage.'],
  ['Milling', 'Bühler roller mills with software-controlled gap. Husk separated, never bleached, never chemically treated.'],
  ['Grading', 'Hosokawa air classifier + vibratory sieve to 30 / 40 / 60 / 80 / 100 mesh. Each mesh stored in its own silo.'],
  ['NIR fingerprint', 'Every 500 kg sub-batch is NIR-scanned on a FOSS DS2500. Spectra archived for 5 years.'],
  ['Wet lab', 'HPLC for purity, swelling volume in 1L cylinder, heavy metals by ICP-MS at SGS partner lab.'],
  ['Packing', 'Food-grade 25kg multi-wall paper, 500kg big bag, or your private label. Container linered, not stuffed loose.'],
  ['Documentation', 'COA, COO, phyto, fumigation, EUR.1, MSDS, allergen statement — sent before B/L is released.']];

  return (
    <section style={{ padding: '120px 56px', background: G.white }} data-comment-anchor="ef3e5c7cbe-section-416-5">
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>The process</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.18em' }}>9 steps · 1 site · 0 co-packers</span>
        </div>
      </Reveal>
      <Reveal delay={80}>
        <h2 style={{
          fontFamily: gFont.display, fontSize: 72, color: G.ink, margin: '0 0 64px',
          letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400, maxWidth: 1100
        }}>
          From <span style={{ fontStyle: 'italic', color: G.sage }}>seed</span><br />to your fill-line.
        </h2>
      </Reveal>
      <GProcessDiagram />
      <div style={{ position: 'relative', maxWidth: 980, marginLeft: 'auto', marginRight: 'auto' }}>
        {/* vertical timeline rail */}
        <div style={{
          position: 'absolute', left: 26, top: 12, bottom: 12, width: 1,
          background: G.rule,
        }}></div>
        {steps.map(([t, d], i) => (
          <Reveal key={i} delay={i * 60}>
            <div className="g-row" style={{
              position: 'relative',
              display: 'grid', gridTemplateColumns: '54px 110px 1fr',
              gap: 28, alignItems: 'start',
              padding: '28px 24px 28px 0',
              borderTop: i ? `1px solid ${G.ruleSoft}` : 'none',
            }}>
              {/* dot on rail */}
              <div style={{ paddingTop: 10, display: 'flex', justifyContent: 'center' }}>
                <span style={{
                  width: 14, height: 14, borderRadius: '50%', background: G.white,
                  border: `2px solid ${G.sage}`, position: 'relative', zIndex: 2,
                  boxShadow: `0 0 0 6px ${G.white}`,
                }}></span>
              </div>
              {/* number + label */}
              <div>
                <div style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.16em', marginBottom: 6 }}>STEP 0{i + 1}</div>
                <div style={{ fontFamily: gFont.display, fontSize: 28, color: G.ink, fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1.05 }}>{t}</div>
              </div>
              {/* description */}
              <div style={{ paddingTop: 8 }}>
                <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, margin: 0, fontWeight: 400, maxWidth: 640 }}>{d}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// PRODUCTS
// ─────────────────────────────────────────────────────────────
const G_PRODUCTS = [
{ code: 'PSH-99', name: 'Husk · 99%', use: 'Pharma · clinical · USP/EP', mesh: '30 / 40', accent: true },
{ code: 'PSH-98', name: 'Husk · 98%', use: 'Premium nutraceutical', mesh: '40 / 60' },
{ code: 'PSH-95', name: 'Husk · 95%', use: 'General supplement & food', mesh: '40 / 60 / 80' },
{ code: 'PSH-85', name: 'Husk · 85%', use: 'Bulk food & industrial fibre', mesh: '40 / 60 / 80' },
{ code: 'PHP-98', name: 'Husk Powder · 98%', use: 'Pharma drink mixes, fine bakery', mesh: '80 / 100' },
{ code: 'PHP-95', name: 'Husk Powder · 95%', use: 'Drink mixes, bakery, fibre', mesh: '80 / 100 / 200' },
{ code: 'PHP-85', name: 'Husk Powder · 85%', use: 'Cost-effective bulk fibre', mesh: '80 / 100 / 200' },
{ code: 'PSD-WH', name: 'Whole Seed', use: 'Pet food, milling, sowing', mesh: '—' },
{ code: 'PSI-IN', name: 'Industrial Powder', use: 'Drilling mud, paint binders', mesh: '60 / 80' },
{ code: 'PCF-CT', name: 'Cattle Feed', use: 'Dairy & livestock nutrition', mesh: 'Granular' },
{ code: 'PSP-RX', name: 'Pharma Grade', use: 'OTC laxatives, formulations', mesh: '30 / 40', accent: true },
{ code: 'PSF-FD', name: 'Food Grade', use: 'Cereal, bakery, gluten-free', mesh: '40 / 60' },
{ code: 'PSO-OR', name: 'Organic Range', use: 'USDA / EU pending', mesh: '40 / 60 / 80' }];


function GProducts() {
  return (
    <section style={{ padding: '120px 56px', background: G.cream }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>The range</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.18em' }}>13 SKUs · custom mesh & private label on request</span>
        </div>
      </Reveal>
      <Reveal delay={80}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 80, marginBottom: 56, alignItems: 'end' }}>
          <h2 style={{
            fontFamily: gFont.display, fontSize: 80, color: G.ink, margin: 0,
            letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400
          }}>
            Every grade.<br />
            <span style={{ fontStyle: 'italic', color: G.sage }}>One</span> obsession with cleanliness.
          </h2>
          <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, margin: 0, maxWidth: 460, fontWeight: 400 }}>
            From bulk industrial powder to pharmacopoeia-grade husk — every SKU
            milled on the same line, batch-tested 47 ways, shipped with a
            plain-language COA. No hidden blends. No mystery binders.
          </p>
        </div>
      </Reveal>
      <div style={{ background: G.white, border: `1px solid ${G.rule}` }} data-comment-anchor="62942547ee-div-497-7">
        {G_PRODUCTS.map((p, i) =>
        <Reveal key={p.code} delay={i * 40}>
            <a href="#" className="g-row" style={{
            display: 'grid', gridTemplateColumns: '110px 1.6fr 1.6fr 1fr 50px',
            padding: '24px 28px', gap: 24, alignItems: 'center',
            borderTop: i ? `1px solid ${G.ruleSoft}` : 'none',
            textDecoration: 'none', color: G.ink
          }}>
              <span style={{ fontFamily: gFont.mono, fontSize: 11, color: p.accent ? G.warm : G.sage, letterSpacing: '0.16em' }}>{p.code}</span>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
                <span style={{ fontFamily: gFont.display, fontSize: 26, color: G.ink, fontWeight: 500, letterSpacing: '-0.015em' }}>{p.name}</span>
                {p.accent && <span style={{ fontFamily: gFont.mono, fontSize: 9, color: G.warm, background: G.warmPale, padding: '3px 8px', borderRadius: 4, letterSpacing: '0.16em' }}>FLAGSHIP</span>}
              </div>
              <span style={{ fontFamily: gFont.body, fontSize: 14, color: G.inkSoft }}>{p.use}</span>
              <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.14em' }}>MESH · {p.mesh}</span>
              <span className="g-row-arrow" style={{ fontFamily: gFont.body, fontSize: 18, color: G.sage, textAlign: 'right' }}>→</span>
            </a>
          </Reveal>
        )}
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// QUALITY — sample COA panel
// ─────────────────────────────────────────────────────────────
function GQuality() {
  const rows = [
  ['Purity (husk)', '≥ 99.0%', '99.4%'],
  ['Swelling volume', '≥ 45 ml/g', '47.2 ml/g'],
  ['Moisture', '≤ 10%', '8.1%'],
  ['Total ash', '≤ 3.0%', '2.4%'],
  ['Heavy metals (total)', '≤ 10 ppm', '2.1 ppm'],
  ['Salmonella / 25g', 'Absent', 'Absent'],
  ['E. coli / 10g', 'Absent', 'Absent'],
  ['Aflatoxin total', '≤ 4 ppb', '< 0.5 ppb'],
  ['Pesticide (EU MRL)', 'Conforms', 'Conforms'],
  ['Extraneous matter', '≤ 0.5%', '0.18%']];

  return (
    <section style={{ padding: '120px 56px', background: G.white }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>Quality</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.18em' }}>Every container ships with a 47-param COA</span>
        </div>
      </Reveal>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 80, alignItems: 'start' }}>
        <Reveal delay={80}>
          <div>
            <h2 style={{
              fontFamily: gFont.display, fontSize: 80, color: G.ink, margin: 0,
              letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400
            }}>
              A COA<br />with every<br />
              <span style={{ fontStyle: 'italic', color: G.sage }}>kilogram.</span>
            </h2>
            <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, marginTop: 28, maxWidth: 460, fontWeight: 400 }}>
              Every batch is fingerprinted at our in-house NIR & HPLC lab and
              cross-checked at SGS. Forty-seven parameters, in plain language,
              attached to your invoice — not hidden behind a buyer portal you
              forgot the password to.
            </p>
            <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
              <a href="#" className="g-cta" style={{
                fontFamily: gFont.body, fontSize: 14, color: G.white, background: G.sage,
                padding: '14px 22px', borderRadius: 999, textDecoration: 'none', fontWeight: 500
              }}>See a sample COA →</a>
              <a href="#" className="g-link" style={{
                fontFamily: gFont.body, fontSize: 14, color: G.ink, padding: '14px 6px',
                textDecoration: 'none', fontWeight: 500
              }}>How we test (3 min read)</a>
            </div>
          </div>
        </Reveal>
        <Reveal delay={160}>
          <div style={{ background: G.paper, border: `1px solid ${G.rule}`, padding: '24px 28px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 16, borderBottom: `1px solid ${G.rule}` }}>
              <div>
                <div style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.2em' }}>COA · SAMPLE</div>
                <div style={{ fontFamily: gFont.display, fontSize: 22, color: G.ink, marginTop: 4, fontWeight: 500, letterSpacing: '-0.01em' }}>Lot RM-26-0512 · Husk 99%</div>
              </div>
              <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.white, background: G.sage, padding: '6px 12px', borderRadius: 999, letterSpacing: '0.18em', fontWeight: 600 }}>● PASS</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr', padding: '14px 0 8px', fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
              <span>Parameter</span><span>Spec</span><span>Result</span>
            </div>
            {rows.map(([k, s, r], i) =>
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr',
              padding: '11px 0', borderTop: `1px solid ${G.ruleSoft}`,
              fontFamily: gFont.mono, fontSize: 12
            }}>
                <span style={{ color: G.ink }}>{k}</span>
                <span style={{ color: G.inkMute }}>{s}</span>
                <span style={{ color: G.sageDeep, fontWeight: 500 }}>{r}</span>
              </div>
            )}
            <div style={{ marginTop: 16, paddingTop: 14, borderTop: `1px solid ${G.rule}`, display: 'flex', justifyContent: 'space-between', fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.1em' }}>
              <span>+ 37 more parameters on the full COA</span>
              <span>SGS Ref · GJ-26-0512-A</span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// EDUCATION — Psyllium 101 for buyers new to the category
// ─────────────────────────────────────────────────────────────
const LESSONS = [
{ tag: 'PSYLLIUM 101', t: 'What is psyllium husk?', d: 'The seed coat of Plantago ovata. Mostly soluble fibre (arabinoxylan). When it meets water, it forms a clear gel — the property that drives both pharma and food applications.', read: '4 min' },
{ tag: 'BUYING GUIDE', t: 'Purity grades, decoded', d: '95%, 98%, 99% — what those numbers actually mean (purity by weight of husk vs. seed kernel & extraneous matter), why pharma needs 99% and food rarely does.', read: '6 min' },
{ tag: 'BUYING GUIDE', t: 'Mesh size, decoded', d: 'Why a 40-mesh husk gels faster than a 60-mesh, and why a drink-mix formulator wants 80 mesh while a tablet press wants 30. Charts, not jargon.', read: '5 min' },
{ tag: 'COMPLIANCE', t: 'USP vs. EP vs. IP', d: 'Three pharmacopoeias, three sets of methods, three slightly different swelling-volume targets. How we test against all three for every pharma-grade lot.', read: '7 min' },
{ tag: 'INDUSTRY', t: 'Why prices move (and why ours don\u2019t)', d: 'Psyllium is monsoon-dependent. Spot prices swing ±40% in a bad year. We index our long-term contracts to a 3-year rolling average so your costing stays sane.', read: '5 min' },
{ tag: 'LOGISTICS', t: 'Mundra to anywhere, by the day', d: 'How long FOB takes, what fumigation actually involves, when to ask for EUR.1, why you should never agree to loose container stuffing. Real numbers.', read: '8 min' }];


function GEducation() {
  return (
    <section style={{ padding: '120px 56px', background: G.paper }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>The Journal</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.18em' }}>Education for procurement teams</span>
        </div>
      </Reveal>
      <Reveal delay={80}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 80, marginBottom: 56, alignItems: 'end' }}>
          <h2 style={{
            fontFamily: gFont.display, fontSize: 80, color: G.ink, margin: 0,
            letterSpacing: '-0.025em', lineHeight: 0.98, fontWeight: 400
          }}>
            Bought it before?<br />Skim. <span style={{ fontStyle: 'italic', color: G.sage }}>New to psyllium?</span><br />Start here.
          </h2>
          <p style={{ fontFamily: gFont.body, fontSize: 16, color: G.inkSoft, lineHeight: 1.6, margin: 0, maxWidth: 460, fontWeight: 400 }}>
            Procurement teams new to the category get a fair, jargon-free
            primer here. No SEO listicles — just the things we wish someone had
            told us the first time we sat across from a buyer who knew the
            spec sheet better than we did.
          </p>
        </div>
      </Reveal>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, alignItems: 'stretch' }}>
        {LESSONS.map((l, i) =>
        <Reveal key={i} delay={i % 3 * 80} style={{ height: '100%', display: 'flex' }}>
            <a href="#" className="g-card" style={{
            background: G.white, border: `1px solid ${G.rule}`,
            padding: '28px 28px 24px', display: 'flex', flexDirection: 'column', gap: 16,
            textDecoration: 'none', width: '100%', flex: 1,
          }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.sage, letterSpacing: '0.2em' }}>{l.tag}</span>
                <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.16em' }}>{l.read}</span>
              </div>
              <h3 style={{ fontFamily: gFont.display, fontSize: 28, color: G.ink, margin: 0, lineHeight: 1.1, letterSpacing: '-0.02em', fontWeight: 500 }}>{l.t}</h3>
              <p style={{ fontFamily: gFont.body, fontSize: 14, color: G.inkSoft, lineHeight: 1.55, margin: 0, fontWeight: 400 }}>{l.d}</p>
              <span className="g-link" style={{ marginTop: 'auto', fontFamily: gFont.body, fontSize: 13, color: G.ink, fontWeight: 500 }}>Read the brief →</span>
            </a>
          </Reveal>
        )}
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// NUMBERS — animated counters
// ─────────────────────────────────────────────────────────────
function GNumbers() {
  return (
    <section style={{ padding: '120px 56px', background: G.sageDeep, color: G.cream }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 56 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sagePale, letterSpacing: '0.24em', textTransform: 'uppercase' }}>By the numbers</span>
          <span style={{ height: 1, background: 'rgba(245,243,236,0.2)', flex: 1, maxWidth: 480 }}></span>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sagePale, letterSpacing: '0.18em', opacity: 0.8 }}>Updated weekly · last sync 2026-05-13</span>
        </div>
      </Reveal>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32 }}>
        {[
        { n: 12000, suf: '', sub: 'MT', label: 'Annual milling capacity' },
        { n: 4500, suf: '', sub: 'acres', label: 'Under farmer contract' },
        { n: 38, suf: '', sub: 'mkt', label: 'Export destinations' },
        { n: 47, suf: '', sub: 'tests', label: 'Per shipment COA' }].
        map((d, i) =>
        <Reveal key={i} delay={i * 100}>
            <div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
                <Counter to={d.n} style={{ fontFamily: gFont.display, fontSize: 100, lineHeight: 0.95, color: G.cream, letterSpacing: '-0.03em', fontWeight: 400 }} />
                <span style={{ fontFamily: gFont.mono, fontSize: 12, color: G.sagePale, letterSpacing: '0.18em' }}>{d.sub}</span>
              </div>
              <div style={{ fontFamily: gFont.mono, fontSize: 11, color: 'rgba(245,243,236,0.7)', letterSpacing: '0.18em', marginTop: 12, textTransform: 'uppercase' }}>{d.label}</div>
            </div>
          </Reveal>
        )}
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// FOUNDER
// ─────────────────────────────────────────────────────────────
function GFounder() {
  return (
    <section style={{ padding: '140px 56px', background: G.cream }}>
      <Reveal>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>The operator</span>
          <span style={{ height: 1, background: G.rule, flex: 1, maxWidth: 480 }}></span>
        </div>
      </Reveal>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 80, alignItems: 'center' }}>
        <Reveal delay={80}>
          <GPlaceholder label="Founder · Ramji Mehta · Unjha" ratio="4/5" tone="warm" />
        </Reveal>
        <Reveal delay={160}>
          <div>
            <p style={{
              fontFamily: gFont.display, fontStyle: 'italic', fontSize: 40, color: G.ink,
              lineHeight: 1.25, margin: 0, fontWeight: 400, letterSpacing: '-0.015em'
            }}>
              "My grandfather sold ispaghol in jute sacks at the Unjha mandi. My
              father exported the first container to Hamburg in 1989. RM
              Psyllium is the same family — finally with the facility the seed
              deserves."
            </p>
            <div style={{ fontFamily: gFont.mono, fontSize: 12, color: G.inkMute, letterSpacing: '0.2em', textTransform: 'uppercase', marginTop: 28 }}>
              — Ramji Mehta · Founder · Third-generation Unjha trader
            </div>
            <div style={{ marginTop: 48, display: 'grid', gridTemplateColumns: '90px 1fr', rowGap: 16, columnGap: 28 }}>
              {[
              ['1983', 'Mehta family begins trading psyllium at Unjha APMC'],
              ['1989', 'First container exported to West Germany'],
              ['2007', 'Banaskantha farmer-contract programme begins'],
              ['2019', 'In-house NIR & HPLC lab commissioned'],
              ['2024', 'RM Psyllium facility opens — 12,000 MT/yr'],
              ['2026', 'Direct relationships in 38 export markets']].
              map(([y, t]) =>
              <React.Fragment key={y}>
                  <span style={{ fontFamily: gFont.mono, fontSize: 12, color: G.sage, fontWeight: 500, letterSpacing: '0.08em' }}>{y}</span>
                  <span style={{ fontFamily: gFont.body, fontSize: 15, color: G.inkSoft, lineHeight: 1.55, fontWeight: 400 }}>{t}</span>
                </React.Fragment>
              )}
            </div>
          </div>
        </Reveal>
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// CTA — form + paths
// ─────────────────────────────────────────────────────────────
function GCTA() {
  return (
    <section style={{ padding: '140px 56px', background: G.white }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 80, alignItems: 'start' }}>
        <Reveal>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
              <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.sage, letterSpacing: '0.24em', textTransform: 'uppercase' }}>Talk</span>
              <span style={{ height: 1, background: G.rule, flex: 1 }}></span>
            </div>
            <h2 style={{
              fontFamily: gFont.display, fontSize: 96, color: G.ink, margin: 0,
              letterSpacing: '-0.03em', lineHeight: 0.96, fontWeight: 400
            }}>
              Let's talk<br />
              <span style={{ fontStyle: 'italic', color: G.sage }}>sourcing.</span>
            </h2>
            <p style={{ fontFamily: gFont.body, fontSize: 17, color: G.inkSoft, lineHeight: 1.6, marginTop: 32, maxWidth: 460, fontWeight: 400 }}>
              Twenty minutes with our export desk. A 250g sample dispatched the
              same day. An indicative landed price before the call ends. That's
              the whole offer.
            </p>
            <div style={{ marginTop: 40, display: 'flex', flexDirection: 'column', gap: 14 }}>
              {[
              ['Schedule a 20-min call', 'export desk · same-day sample · landed price'],
              ['Email export@rmpsyllium.com', '4 hr avg response · 24/5'],
              ['WhatsApp +91 2767 333 444', 'fastest path · we read everything']].
              map(([t, sub], i) =>
              <a key={i} href="#" className="g-row" style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '18px 24px', textDecoration: 'none', color: G.ink,
                border: `1px solid ${G.rule}`
              }}>
                  <div>
                    <div style={{ fontFamily: gFont.display, fontSize: 22, fontWeight: 500, letterSpacing: '-0.015em' }}>{t}</div>
                    <div style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.08em', marginTop: 4 }}>{sub}</div>
                  </div>
                  <span className="g-row-arrow" style={{ fontFamily: gFont.body, fontSize: 22, color: G.sage }}>→</span>
                </a>
              )}
            </div>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div style={{ background: G.paper, border: `1px solid ${G.rule}`, padding: 40 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontFamily: gFont.mono, fontSize: 11, color: G.inkMute, letterSpacing: '0.2em', textTransform: 'uppercase' }}>Request a quote</span>
              <span style={{ fontFamily: gFont.mono, fontSize: 10, color: G.sage, letterSpacing: '0.18em' }}>● 4 hr response</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 28 }}>
              {['Name', 'Company', 'Country', 'Email', 'Phone (or WhatsApp)', 'Volume per month (MT)'].map((f, i) =>
              <label key={i} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span style={{ fontFamily: gFont.mono, fontSize: 9, letterSpacing: '0.2em', color: G.inkMute, textTransform: 'uppercase' }}>{f}</span>
                  <input className="g-input" style={{
                  fontFamily: gFont.body, fontSize: 14, color: G.ink,
                  padding: '12px 0 10px', border: 'none', borderBottom: `1px solid ${G.rule}`,
                  background: 'transparent', outline: 'none'
                }} />
                </label>
              )}
            </div>
            <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 24 }}>
              <span style={{ fontFamily: gFont.mono, fontSize: 9, letterSpacing: '0.2em', color: G.inkMute, textTransform: 'uppercase' }}>Product interest</span>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
                {['Husk 99%', 'Husk 98%', 'Husk 95%', 'Husk 85%', 'Husk Powder', 'Pharma', 'Industrial', 'Cattle Feed', 'Organic', 'Other'].map((t) =>
                <span key={t} className="g-chip" style={{
                  fontFamily: gFont.body, fontSize: 12, color: G.ink,
                  padding: '7px 14px', border: `1px solid ${G.rule}`, borderRadius: 999,
                  background: G.white, fontWeight: 500
                }}>{t}</span>
                )}
              </div>
            </label>
            <label style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 24 }}>
              <span style={{ fontFamily: gFont.mono, fontSize: 9, letterSpacing: '0.2em', color: G.inkMute, textTransform: 'uppercase' }}>Anything else?</span>
              <textarea rows={3} className="g-input" style={{
                fontFamily: gFont.body, fontSize: 14, color: G.ink, resize: 'none',
                padding: '12px 0 10px', border: 'none', borderBottom: `1px solid ${G.rule}`,
                background: 'transparent', outline: 'none'
              }} />
            </label>
            <button className="g-cta" style={{
              marginTop: 32, width: '100%', fontFamily: gFont.body, fontSize: 14, fontWeight: 500,
              color: G.white, background: G.ink, padding: '16px 22px', borderRadius: 999,
              border: 'none', cursor: 'pointer', letterSpacing: '0.01em',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 10
            }}>
              Send · we'll reply within 4 hours
              <span>→</span>
            </button>
            <div style={{ fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.16em', marginTop: 16, textAlign: 'center' }}>
              Or schedule a call directly · cal.com/rmpsyllium
            </div>
          </div>
        </Reveal>
      </div>
    </section>);

}

// ─────────────────────────────────────────────────────────────
// FOOTER
// ─────────────────────────────────────────────────────────────
function GFooter() {
  return (
    <footer style={{ background: G.cream, color: G.ink, padding: '80px 56px 32px', borderTop: `1px solid ${G.rule}` }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr 1fr', gap: 48 }}>
        <div>
          <GLogo />
          <p style={{ fontFamily: gFont.body, fontSize: 13, color: G.inkSoft, lineHeight: 1.6, marginTop: 18, maxWidth: 280, fontWeight: 400 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
          <div style={{ marginTop: 16, fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.16em' }}>
            IEC 0124007841 · APEDA RCMC/UNJ/2024
          </div>
        </div>
        {[
        ['Products', ['Husk 99% / 98%', 'Husk 95% / 85%', 'Husk Powder · 98%', 'Husk Powder · 95%', 'Husk Powder · 85%', 'Whole Seed', 'Pharma Grade', 'Food Grade', 'Industrial Powder', 'Cattle Feed', 'Organic Range']],
        ['By sector', ['Pharma', 'Food brands', 'Industrial', 'Pet food', 'Private label']],
        ['Company', ['Story', 'Facility', 'Sustainability', 'Journal', 'Press', 'Careers']],
        ['Contact', ['Book a call', 'WhatsApp', 'RFQ', 'Sample request', 'export@rmpsyllium.com']]].
        map(([h, items], i) =>
        <div key={i}>
            <div style={{ fontFamily: gFont.mono, fontSize: 10, letterSpacing: '0.22em', color: G.inkMute, textTransform: 'uppercase' }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
              {items.map((t, j) =>
            <a key={j} href="#" className="g-link" style={{ fontFamily: gFont.body, fontSize: 13, color: G.ink, textDecoration: 'none', fontWeight: 400 }}>{t}</a>
            )}
            </div>
          </div>
        )}
      </div>
      <div style={{ marginTop: 80, lineHeight: 0.84, overflow: 'hidden', borderTop: `1px solid ${G.rule}`, paddingTop: 40 }}>
        <div style={{ fontFamily: gFont.display, fontSize: 220, color: G.creamDeep, letterSpacing: '-0.05em', fontWeight: 400 }}>
          RM Psyllium
        </div>
      </div>
      <div style={{
        marginTop: 24, paddingTop: 20, borderTop: `1px solid ${G.rule}`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: gFont.mono, fontSize: 10, color: G.inkMute, letterSpacing: '0.18em'
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD · UNJHA · GUJARAT</span>
        <span>PRIVACY · TERMS · CODE OF CONDUCT</span>
      </div>
    </footer>);

}

// ─────────────────────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────────────────────
function VariantG() {
  return (
    <div style={{ background: G.white, fontFamily: gFont.body, color: G.ink, width: '100%' }}>
      <GNav />
      <GHero />
      <GTrustBand />
      <GStory />
      <GMachinery />
      <GProcess />
      <GProducts />
      <GQuality />
      <GEducation />
      <GNumbers />
      <GFounder />
      <GCTA />
      <GFooter />
    </div>);

}

window.VariantG = VariantG;