// Variant B — "Spec Sheet"
// Industrial B2B precision. IBM Plex Sans + Mono. Off-white, near-black, sage.
// Ruled grids, tabular numbers, every section is labelled like a datasheet.

const B = {
  paper: '#fafaf7',
  paperAlt: '#f1f0e8',
  ink: '#0e0f0c',
  inkSoft: '#3a3b35',
  sage: '#7e8b65',
  sageDeep: '#5a6748',
  signal: '#d94a1a',
  rule: 'rgba(14,15,12,0.16)',
  ruleSoft: 'rgba(14,15,12,0.08)',
  mute: 'rgba(14,15,12,0.55)',
};

const bFont = {
  sans: '"IBM Plex Sans", -apple-system, system-ui, sans-serif',
  mono: '"IBM Plex Mono", ui-monospace, monospace',
  serif: '"IBM Plex Serif", Georgia, serif',
};

(function ensureBFonts() {
  if (document.getElementById('b-fonts')) return;
  const link = document.createElement('link');
  link.id = 'b-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Serif:ital,wght@0,400;1,400&display=swap';
  document.head.appendChild(link);
})();

function BPlaceholder({ label, h = 320, dark = false }) {
  return (
    <div style={{
      width: '100%', height: h, position: 'relative', overflow: 'hidden',
      background: dark ? B.ink : B.paperAlt,
      backgroundImage: dark
        ? 'repeating-linear-gradient(90deg, rgba(126,139,101,0.18) 0 1px, transparent 1px 24px), repeating-linear-gradient(0deg, rgba(126,139,101,0.18) 0 1px, transparent 1px 24px)'
        : 'repeating-linear-gradient(90deg, rgba(14,15,12,0.06) 0 1px, transparent 1px 24px), repeating-linear-gradient(0deg, rgba(14,15,12,0.06) 0 1px, transparent 1px 24px)',
      border: `1px solid ${dark ? 'rgba(126,139,101,0.3)' : B.rule}`,
    }}>
      <div style={{
        position: 'absolute', left: 12, top: 12,
        fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.15em',
        color: dark ? '#7e8b65' : B.mute, textTransform: 'uppercase',
      }}>[ img ]</div>
      <div style={{
        position: 'absolute', right: 12, bottom: 12,
        fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.15em',
        color: dark ? 'rgba(250,250,247,0.6)' : B.mute,
      }}>{label}</div>
    </div>
  );
}

function BLogo({ inverted }) {
  const fg = inverted ? B.paper : B.ink;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 32, height: 32, background: fg, color: inverted ? B.ink : B.paper,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: bFont.mono, fontSize: 14, fontWeight: 600, letterSpacing: '-0.04em',
      }}>RM</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: bFont.sans, fontSize: 16, color: fg, fontWeight: 600, letterSpacing: '-0.01em' }}>RM Psyllium</div>
        <div style={{ fontFamily: bFont.mono, fontSize: 9, color: fg, opacity: 0.6, letterSpacing: '0.16em', marginTop: 3 }}>UNJHA · IN · EST 2024</div>
      </div>
    </div>
  );
}

function BSectionLabel({ num, title, kicker }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', gap: 16, borderTop: `1px solid ${B.ink}`,
      paddingTop: 18, marginBottom: 36,
    }}>
      <span style={{ fontFamily: bFont.mono, fontSize: 11, color: B.signal, letterSpacing: '0.12em', fontWeight: 500 }}>§{num}</span>
      <span style={{ fontFamily: bFont.mono, fontSize: 11, color: B.mute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{title}</span>
      <span style={{ flex: 1, height: 1 }}></span>
      <span style={{ fontFamily: bFont.mono, fontSize: 11, color: B.mute, letterSpacing: '0.16em' }}>{kicker}</span>
    </div>
  );
}

function BNav() {
  const link = { fontFamily: bFont.sans, fontSize: 13, color: B.ink, textDecoration: 'none', fontWeight: 500 };
  return (
    <nav style={{
      display: 'grid', gridTemplateColumns: 'auto 1fr auto', alignItems: 'center', gap: 40,
      padding: '20px 56px', borderBottom: `1px solid ${B.ink}`, background: B.paper,
    }}>
      <BLogo />
      <div style={{ display: 'flex', gap: 28, justifyContent: 'center' }}>
        {['Products', 'Specifications', 'Quality', 'Facility', 'Sourcing', 'Logistics', 'Contact'].map(t => (
          <a key={t} href="#" style={link}>{t}</a>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <span style={{ fontFamily: bFont.mono, fontSize: 10, color: B.mute, letterSpacing: '0.16em' }}>RFQ ↗ &nbsp;·&nbsp; +91 2767 333 444</span>
        <a href="#" style={{
          fontFamily: bFont.sans, fontSize: 13, color: B.paper, background: B.ink,
          padding: '10px 16px', textDecoration: 'none', fontWeight: 500,
          display: 'inline-flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ width: 6, height: 6, background: B.signal, borderRadius: '50%' }}></span>
          Schedule a call
        </a>
      </div>
    </nav>
  );
}

function BHero() {
  return (
    <section style={{ padding: '32px 56px 64px', borderBottom: `1px solid ${B.ink}` }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        fontFamily: bFont.mono, fontSize: 11, color: B.mute, letterSpacing: '0.16em',
        textTransform: 'uppercase', paddingBottom: 16, marginBottom: 56,
      }}>
        <span>Doc · index.html / v.2026.01</span>
        <span style={{ color: B.signal }}>● Quoting now · 4hr response</span>
        <span>Reviewed by R.M. / 16 May 2026</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 80, alignItems: 'start' }}>
        <div>
          <h1 style={{
            fontFamily: bFont.sans, fontSize: 100, lineHeight: 0.94, color: B.ink, margin: 0,
            letterSpacing: '-0.04em', fontWeight: 500,
          }}>
            Psyllium,<br/>
            specified.<span style={{ color: B.signal }}>_</span>
          </h1>
          <p style={{
            fontFamily: bFont.sans, fontSize: 19, lineHeight: 1.45, color: B.inkSoft,
            maxWidth: 540, marginTop: 36, fontWeight: 400,
          }}>
            B2B supply of pharma-, food- and industrial-grade Psyllium husk,
            powder and seed — milled to your spec sheet at our 12,000&nbsp;MT
            facility in Unjha, Gujarat. Every container ships with a 47-parameter
            COA.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 40 }}>
            <a href="#" style={{
              fontFamily: bFont.sans, fontSize: 14, color: B.paper, background: B.ink,
              padding: '14px 22px', textDecoration: 'none', fontWeight: 500,
              display: 'inline-flex', alignItems: 'center', gap: 10,
            }}>
              <span style={{ width: 6, height: 6, background: B.signal, borderRadius: '50%' }}></span>
              Schedule a call
            </a>
            <a href="#" style={{
              fontFamily: bFont.sans, fontSize: 14, color: B.ink, padding: '14px 22px',
              textDecoration: 'none', fontWeight: 500, border: `1px solid ${B.ink}`,
            }}>Download spec PDF</a>
            <a href="#" style={{
              fontFamily: bFont.sans, fontSize: 14, color: B.ink, padding: '14px 22px',
              textDecoration: 'none', fontWeight: 500,
            }}>Request 250g sample →</a>
          </div>
        </div>
        <div style={{ border: `1px solid ${B.ink}`, background: B.paperAlt }}>
          <div style={{ padding: '12px 16px', borderBottom: `1px solid ${B.ink}`, display: 'flex', justifyContent: 'space-between', fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
            <span>Spec card · Husk 99%</span>
            <span style={{ color: B.signal }}>● in stock</span>
          </div>
          <div style={{ padding: 0 }}>
            {[
              ['Product code', 'PSH-99'],
              ['Purity', '≥ 99.0%'],
              ['Mesh size', '30 / 40'],
              ['Swelling vol.', '≥ 45 ml/g'],
              ['Moisture', '≤ 10%'],
              ['Total ash', '≤ 3.0%'],
              ['Heavy metals', '≤ 10 ppm'],
              ['Pesticide (EU MRL)', 'Conforms'],
              ['Salmonella / 25g', 'Absent'],
              ['Shelf life', '24 months'],
              ['MOQ', '1 × 20ft FCL (12 MT)'],
              ['Packing', '25kg paper / 500kg big bag'],
            ].map(([k, v], i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '1fr 1fr',
                padding: '11px 16px', borderTop: i ? `1px solid ${B.ruleSoft}` : 'none',
                fontFamily: bFont.mono, fontSize: 12,
              }}>
                <span style={{ color: B.mute, letterSpacing: '0.04em' }}>{k}</span>
                <span style={{ color: B.ink, fontWeight: 500 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function BNumbers() {
  return (
    <section style={{ padding: '0', borderBottom: `1px solid ${B.ink}`, background: B.ink, color: B.paper }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)' }}>
        {[
          ['12,000', 'MT', 'annual milling capacity'],
          ['4,500', 'ac', 'farmer-contract acreage'],
          ['38', 'mkt', 'export destinations'],
          ['47', 'tests', 'COA per shipment'],
          ['4 h', 'avg', 'RFQ response time'],
        ].map(([n, unit, label], i) => (
          <div key={i} style={{
            padding: '36px 28px', borderLeft: i ? `1px solid rgba(250,250,247,0.18)` : 'none',
            display: 'flex', flexDirection: 'column', gap: 10,
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
              <div style={{ fontFamily: bFont.sans, fontSize: 56, fontWeight: 500, letterSpacing: '-0.04em', lineHeight: 1 }}>{n}</div>
              <div style={{ fontFamily: bFont.mono, fontSize: 12, color: B.sage, letterSpacing: '0.16em' }}>{unit}</div>
            </div>
            <div style={{ fontFamily: bFont.mono, fontSize: 11, color: 'rgba(250,250,247,0.65)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>{label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

const B_PRODUCTS = [
  { code: 'PSH-95', name: 'Husk · 95%', purity: '≥ 95.0%', swell: '≥ 40 ml/g', mesh: '40 / 60 / 80', use: 'Supplement, food', stock: true },
  { code: 'PSH-98', name: 'Husk · 98%', purity: '≥ 98.0%', swell: '≥ 42 ml/g', mesh: '40 / 60', use: 'Nutraceutical', stock: true },
  { code: 'PSH-99', name: 'Husk · 99%', purity: '≥ 99.0%', swell: '≥ 45 ml/g', mesh: '30 / 40', use: 'Pharma, clinical', stock: true },
  { code: 'PHP-FN', name: 'Husk Powder', purity: '≥ 95.0%', swell: '≥ 38 ml/g', mesh: '80 / 100', use: 'Drink mixes', stock: true },
  { code: 'PSD-WH', name: 'Whole Seed', purity: '99% pure', swell: '—', mesh: '—', use: 'Pet food, sowing', stock: true },
  { code: 'PSI-IN', name: 'Industrial Powder', purity: 'Tech', swell: '—', mesh: '60 / 80', use: 'Drilling mud', stock: true },
  { code: 'PSP-RX', name: 'Pharma Grade', purity: 'USP / EP', swell: '≥ 45 ml/g', mesh: '30 / 40', use: 'OTC laxatives', stock: false },
  { code: 'PSF-FD', name: 'Food Grade', purity: 'BRCGS', swell: '≥ 42 ml/g', mesh: '40 / 60', use: 'Bakery, cereals', stock: true },
  { code: 'PSO-OR', name: 'Organic', purity: 'USDA / EU*', swell: '≥ 42 ml/g', mesh: '40 / 60 / 80', use: 'Organic SKUs', stock: false },
];

function BProducts() {
  return (
    <section style={{ padding: '80px 56px', background: B.paper }}>
      <BSectionLabel num="01" title="Product Catalogue" kicker="09 SKUs · click any row for full datasheet" />
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 60, marginBottom: 48 }}>
        <h2 style={{ fontFamily: bFont.sans, fontSize: 56, color: B.ink, margin: 0, letterSpacing: '-0.03em', fontWeight: 500, lineHeight: 1 }}>
          One line. Nine grades. <span style={{ color: B.sage }}>Zero blends.</span>
        </h2>
        <p style={{ fontFamily: bFont.sans, fontSize: 15, color: B.inkSoft, lineHeight: 1.55, margin: 0, fontWeight: 400 }}>
          We mill one species — <i>Plantago ovata</i> — across nine specification
          grades. Custom mesh, custom packing, custom private label. Pricing is
          quoted against your spec, not ours.
        </p>
      </div>
      <div style={{ border: `1px solid ${B.ink}` }}>
        <div style={{
          display: 'grid', gridTemplateColumns: '90px 1.4fr 1fr 1fr 1.1fr 1.4fr 90px',
          background: B.ink, color: B.paper, padding: '10px 16px', gap: 16,
          fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase',
        }}>
          <span>Code</span><span>Product</span><span>Purity</span><span>Swelling</span><span>Mesh (US)</span><span>Application</span><span style={{ textAlign: 'right' }}>Stock</span>
        </div>
        {B_PRODUCTS.map((p, i) => (
          <div key={p.code} style={{
            display: 'grid', gridTemplateColumns: '90px 1.4fr 1fr 1fr 1.1fr 1.4fr 90px',
            padding: '18px 16px', gap: 16, alignItems: 'center',
            borderTop: i ? `1px solid ${B.ruleSoft}` : 'none',
            fontFamily: bFont.mono, fontSize: 12,
          }}>
            <span style={{ color: B.signal, fontWeight: 500 }}>{p.code}</span>
            <span style={{ fontFamily: bFont.sans, fontSize: 15, fontWeight: 500, color: B.ink }}>{p.name}</span>
            <span>{p.purity}</span>
            <span>{p.swell}</span>
            <span>{p.mesh}</span>
            <span style={{ color: B.inkSoft }}>{p.use}</span>
            <span style={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: p.stock ? B.sage : B.signal }}></span>
              <span style={{ color: B.mute, letterSpacing: '0.12em' }}>{p.stock ? 'IN' : 'MTO'}</span>
            </span>
          </div>
        ))}
        <div style={{ borderTop: `1px solid ${B.ink}`, padding: '14px 16px', background: B.paperAlt, display: 'flex', justifyContent: 'space-between', fontFamily: bFont.mono, fontSize: 11, letterSpacing: '0.12em', color: B.mute }}>
          <span>IN · in stock for 20ft FCL · ships from Mundra in 7–10 days</span>
          <span>MTO · made-to-order · 21–28 day lead time</span>
        </div>
      </div>
    </section>
  );
}

function BProcess() {
  return (
    <section style={{ padding: '80px 56px', borderTop: `1px solid ${B.ink}`, background: B.paperAlt }}>
      <BSectionLabel num="02" title="Seed to Container" kicker="9-step process, single-site, no co-packers" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, border: `1px solid ${B.ink}`, background: B.paper }}>
        {[
          ['Sourcing', 'Direct from 1,200+ contracted farmers across Banaskantha, Patan, Mehsana — same villages our family has bought from since 1983.'],
          ['Pre-clean', 'Magnetic separation, de-stoner, vibratory sieve. Foreign matter dropped to &lt; 0.5%.'],
          ['Conditioning', '12-hour rest at 18% humidity to optimise the husk-to-seed split without scorching the mucilage.'],
          ['Milling', 'Roller mills with software-controlled gap. Husk separated, never bleached, never chemically treated.'],
          ['Grading', 'Air-classifier + vibratory sieve to 30 / 40 / 60 / 80 / 100 mesh. Each mesh stored in its own silo.'],
          ['NIR fingerprint', 'Every 500kg sub-batch is NIR-scanned. Spectra are stored — re-run a complaint two years later.'],
          ['Wet lab', 'HPLC for purity, swelling volume in 1L cylinder, heavy metals by ICP-MS at SGS partner lab.'],
          ['Packing', 'Food-grade 25kg multi-wall paper, 500kg big bag, or your private label. Container linered, not stuffed loose.'],
          ['Documentation', 'COA, COO, phyto, fumigation, EUR.1, MSDS, allergen statement — sent before B/L is released.'],
        ].map(([t, d], i) => (
          <div key={i} style={{
            padding: '28px 24px',
            borderRight: (i % 3 !== 2) ? `1px solid ${B.ruleSoft}` : 'none',
            borderTop: i >= 3 ? `1px solid ${B.ruleSoft}` : 'none',
            minHeight: 180,
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 16 }}>
              <span style={{ fontFamily: bFont.mono, fontSize: 11, color: B.signal, letterSpacing: '0.12em' }}>0{i + 1}</span>
              <span style={{ fontFamily: bFont.sans, fontSize: 20, fontWeight: 500, color: B.ink, letterSpacing: '-0.01em' }}>{t}</span>
            </div>
            <p style={{ fontFamily: bFont.sans, fontSize: 13, color: B.inkSoft, lineHeight: 1.55, margin: 0, fontWeight: 400 }} dangerouslySetInnerHTML={{ __html: d }}></p>
          </div>
        ))}
      </div>
    </section>
  );
}

function BFacility() {
  return (
    <section style={{ padding: '80px 56px', borderTop: `1px solid ${B.ink}`, background: B.paper }}>
      <BSectionLabel num="03" title="The Facility" kicker="GIDC Unjha · 4.2 acre site · commissioned Q3 2024" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
        <BPlaceholder label="Facility · drone exterior" h={420} />
        <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 24 }}>
          <BPlaceholder label="Milling floor · roller line 02" h={198} />
          <BPlaceholder label="QC lab · NIR / HPLC bench" h={198} />
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, marginTop: 32, border: `1px solid ${B.rule}` }}>
        {[
          ['Site area', '4.2 acres', '17,000 m²'],
          ['Storage', '8,400 MT', 'seed + finished'],
          ['Lines', '3 × roller', '+ 1 industrial'],
          ['Lab', 'NIR + HPLC', '+ SGS partner'],
        ].map(([k, v, sub], i) => (
          <div key={i} style={{
            padding: '24px 20px', borderRight: i < 3 ? `1px solid ${B.ruleSoft}` : 'none',
          }}>
            <div style={{ fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.18em', color: B.mute, textTransform: 'uppercase' }}>{k}</div>
            <div style={{ fontFamily: bFont.sans, fontSize: 28, fontWeight: 500, color: B.ink, marginTop: 8, letterSpacing: '-0.02em' }}>{v}</div>
            <div style={{ fontFamily: bFont.mono, fontSize: 11, color: B.sageDeep, letterSpacing: '0.1em', marginTop: 4 }}>{sub}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function BCertifications() {
  return (
    <section style={{ padding: '64px 56px', background: B.ink, color: B.paper }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 32 }}>
        <span style={{ fontFamily: bFont.mono, fontSize: 11, color: B.sage, letterSpacing: '0.18em', textTransform: 'uppercase' }}>§04 · Compliance Stack</span>
        <span style={{ fontFamily: bFont.mono, fontSize: 11, color: 'rgba(250,250,247,0.5)', letterSpacing: '0.14em' }}>Audited / in-progress · updated monthly</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, border: `1px solid rgba(250,250,247,0.18)` }}>
        {[
          ['ISO 22000', 'Food safety mgmt', 'AUDITED'],
          ['FSSAI', 'License 10024021000123', 'AUDITED'],
          ['HACCP', 'Hazard analysis', 'AUDITED'],
          ['GMP', 'Good mfg practice', 'AUDITED'],
          ['USDA Organic', 'NOP standard', 'Q3 2026'],
          ['EU Organic', 'EC 834/2007', 'Q3 2026'],
          ['Kosher', 'Star-K', 'Q4 2026'],
          ['Halal', 'JAKIM / IFANCA', 'Q4 2026'],
        ].map(([cert, sub, status], i) => (
          <div key={i} style={{
            padding: '24px 20px',
            borderRight: (i % 4 !== 3) ? `1px solid rgba(250,250,247,0.12)` : 'none',
            borderTop: i >= 4 ? `1px solid rgba(250,250,247,0.12)` : 'none',
          }}>
            <div style={{ fontFamily: bFont.sans, fontSize: 22, fontWeight: 500, color: B.paper, letterSpacing: '-0.02em' }}>{cert}</div>
            <div style={{ fontFamily: bFont.mono, fontSize: 11, color: 'rgba(250,250,247,0.6)', marginTop: 6, letterSpacing: '0.06em' }}>{sub}</div>
            <div style={{
              fontFamily: bFont.mono, fontSize: 10, marginTop: 14, letterSpacing: '0.18em',
              color: status === 'AUDITED' ? B.sage : B.signal,
            }}>● {status}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function BStory() {
  return (
    <section style={{ padding: '96px 56px', borderTop: `1px solid ${B.ink}`, background: B.paper }}>
      <BSectionLabel num="05" title="The Operator" kicker="On record" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 64, alignItems: 'start' }}>
        <BPlaceholder label="Founder · Ramji Mehta" h={520} />
        <div>
          <p style={{ fontFamily: bFont.serif, fontStyle: 'italic', fontSize: 30, color: B.ink, lineHeight: 1.35, margin: 0, fontWeight: 400 }}>
            "Buyers don't want a story. They want a sample, a price, and someone
            who picks up the phone when the container hits Rotterdam two days
            late. We built this company to be that someone."
          </p>
          <div style={{
            marginTop: 28, fontFamily: bFont.mono, fontSize: 11, color: B.mute,
            letterSpacing: '0.18em', textTransform: 'uppercase',
          }}>— Ramji Mehta · Founder · third-gen Unjha trader</div>
          <div style={{
            marginTop: 48, display: 'grid', gridTemplateColumns: '90px 1fr',
            rowGap: 16, columnGap: 24, fontFamily: bFont.mono, fontSize: 13,
          }}>
            {[
              ['1983', 'Mehta family begins trading psyllium at Unjha APMC'],
              ['1989', 'First export container to West Germany'],
              ['2007', 'Banaskantha farmer-contract programme'],
              ['2019', 'In-house NIR + HPLC lab commissioned'],
              ['2024', 'RM Psyllium facility commissioned — 12,000 MT/yr'],
              ['2026', 'Active in 38 export markets'],
            ].map(([y, t]) => (
              <React.Fragment key={y}>
                <span style={{ color: B.signal, letterSpacing: '0.1em' }}>{y}</span>
                <span style={{ color: B.ink, lineHeight: 1.55 }}>{t}</span>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function BReach() {
  return (
    <section style={{ padding: '80px 56px', borderTop: `1px solid ${B.ink}`, background: B.paperAlt }}>
      <BSectionLabel num="06" title="Logistics" kicker="FOB Mundra · CIF anywhere · Incoterms 2020" />
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 48 }}>
        <div style={{ border: `1px solid ${B.ink}`, background: B.paper }}>
          {[
            ['North America', 'USA · Canada · Mexico', '28 d'],
            ['Western Europe', 'DE · NL · UK · IT · ES · FR', '19 d'],
            ['Middle East', 'UAE · KSA · Egypt · Oman', '6 d'],
            ['East Asia', 'JP · KR · CN · TW', '14 d'],
            ['South-east Asia', 'VN · ID · MY · PH · TH', '11 d'],
            ['Oceania', 'AU · NZ', '21 d'],
            ['South America', 'BR · CL · AR · PE', '32 d'],
            ['Africa', 'ZA · KE · MA · NG', '22 d'],
          ].map(([region, list, days], i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '1fr 1.4fr auto',
              padding: '16px 20px', gap: 16, alignItems: 'center',
              borderTop: i ? `1px solid ${B.ruleSoft}` : 'none',
            }}>
              <span style={{ fontFamily: bFont.sans, fontSize: 15, fontWeight: 500, color: B.ink }}>{region}</span>
              <span style={{ fontFamily: bFont.mono, fontSize: 12, color: B.inkSoft, letterSpacing: '0.08em' }}>{list}</span>
              <span style={{ fontFamily: bFont.mono, fontSize: 12, color: B.signal, letterSpacing: '0.1em' }}>~{days}</span>
            </div>
          ))}
        </div>
        <div>
          <div style={{ fontFamily: bFont.mono, fontSize: 11, letterSpacing: '0.18em', color: B.mute, textTransform: 'uppercase' }}>Packing options</div>
          <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[
              ['25 kg', 'Multi-wall paper sack', '480 / FCL'],
              ['500 kg', 'PP big bag, food-grade liner', '24 / FCL'],
              ['1 MT', 'IBC tote (industrial)', '20 / FCL'],
              ['Custom', 'Private label, retail-ready', 'on quote'],
            ].map(([w, t, n], i) => (
              <div key={i} style={{ border: `1px solid ${B.rule}`, padding: '18px 16px', background: B.paper }}>
                <div style={{ fontFamily: bFont.sans, fontSize: 22, fontWeight: 600, color: B.ink, letterSpacing: '-0.02em' }}>{w}</div>
                <div style={{ fontFamily: bFont.sans, fontSize: 13, color: B.inkSoft, marginTop: 4 }}>{t}</div>
                <div style={{ fontFamily: bFont.mono, fontSize: 11, color: B.signal, marginTop: 12, letterSpacing: '0.1em' }}>{n}</div>
              </div>
            ))}
          </div>
          <div style={{ fontFamily: bFont.mono, fontSize: 11, letterSpacing: '0.18em', color: B.mute, textTransform: 'uppercase', marginTop: 32 }}>Documentation included</div>
          <div style={{ marginTop: 14, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {['COA', 'COO', 'Phyto-sanitary', 'Fumigation', 'EUR.1', 'MSDS', 'Allergen stmt.', 'Non-GMO decl.', 'Halal*', 'Kosher*'].map(t => (
              <span key={t} style={{
                fontFamily: bFont.mono, fontSize: 11, color: B.ink, padding: '6px 12px',
                border: `1px solid ${B.rule}`, background: B.paper, letterSpacing: '0.08em',
              }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function BCTA() {
  return (
    <section style={{ padding: '96px 56px', borderTop: `1px solid ${B.ink}`, background: B.paper }}>
      <BSectionLabel num="07" title="Quote / Sample / Call" kicker="3 paths · pick one" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, border: `1px solid ${B.ink}` }}>
        {[
          { tag: 'FAST', t: 'Schedule a 20-min call', d: 'Direct line to the export desk. We send sample + indicative landed price before the call ends.', cta: 'Pick a time →', primary: true },
          { tag: 'DETAIL', t: 'Send us your spec', d: 'Upload your existing spec sheet or COA. We quote within 4 business hours against your exact parameters.', cta: 'Upload spec →' },
          { tag: 'TRIAL', t: 'Request a 250 g sample', d: 'Free sample with full COA. Shipped via FedEx, lands in 5–7 days anywhere we have a DDP lane.', cta: 'Request sample →' },
        ].map((c, i) => (
          <div key={i} style={{
            padding: '36px 32px',
            borderRight: i < 2 ? `1px solid ${B.ruleSoft}` : 'none',
            background: c.primary ? B.ink : B.paper,
            color: c.primary ? B.paper : B.ink,
            display: 'flex', flexDirection: 'column', gap: 16,
          }}>
            <div style={{ fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.22em', color: c.primary ? B.sage : B.signal }}>● {c.tag}</div>
            <h3 style={{ fontFamily: bFont.sans, fontSize: 28, fontWeight: 500, margin: 0, letterSpacing: '-0.02em', lineHeight: 1.1 }}>{c.t}</h3>
            <p style={{ fontFamily: bFont.sans, fontSize: 14, opacity: c.primary ? 0.75 : 0.7, lineHeight: 1.55, margin: 0, fontWeight: 400 }}>{c.d}</p>
            <a href="#" style={{
              marginTop: 'auto', fontFamily: bFont.sans, fontSize: 14, fontWeight: 500,
              color: c.primary ? B.ink : B.paper, background: c.primary ? B.sage : B.ink,
              padding: '12px 18px', textDecoration: 'none', alignSelf: 'flex-start',
              display: 'inline-flex', alignItems: 'center', gap: 8,
            }}>{c.cta}</a>
          </div>
        ))}
      </div>
    </section>
  );
}

function BFooter() {
  return (
    <footer style={{ background: B.ink, color: B.paper, padding: '64px 56px 28px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr 1fr', gap: 48 }}>
        <div>
          <BLogo inverted />
          <p style={{ fontFamily: bFont.sans, fontSize: 13, opacity: 0.7, lineHeight: 1.55, marginTop: 16, maxWidth: 280, fontWeight: 400 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
          <div style={{ marginTop: 16, fontFamily: bFont.mono, fontSize: 11, opacity: 0.55, letterSpacing: '0.14em' }}>
            IEC 0124007841 · APEDA RCMC/UNJ/2024 · CIN U15499GJ2024PTC141802
          </div>
        </div>
        {[
          ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Husk Powder', 'Seed', 'Pharma', 'Industrial', 'Food', 'Organic']],
          ['Resources', ['Spec sheets', 'COA samples', 'Compliance docs', 'Sustainability', 'Whitepapers', 'Journal']],
          ['Company', ['Story', 'Facility', 'Careers', 'Press', 'Sourcing']],
          ['Contact', ['+91 2767 333 444', 'export@rmpsyllium.com', 'WhatsApp', 'Schedule a call']],
        ].map(([h, items], i) => (
          <div key={i}>
            <div style={{ fontFamily: bFont.mono, fontSize: 10, letterSpacing: '0.2em', opacity: 0.55, textTransform: 'uppercase' }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 16 }}>
              {items.map((t, j) => (
                <a key={j} href="#" style={{ fontFamily: bFont.sans, fontSize: 13, color: B.paper, opacity: 0.85, textDecoration: 'none', fontWeight: 400 }}>{t}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 56, paddingTop: 20, borderTop: `1px solid rgba(250,250,247,0.16)`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: bFont.mono, fontSize: 10, opacity: 0.5, letterSpacing: '0.18em',
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD</span>
        <span>SITEMAP · PRIVACY · TERMS · MODERN SLAVERY STATEMENT</span>
      </div>
    </footer>
  );
}

function VariantB() {
  return (
    <div style={{ background: B.paper, fontFamily: bFont.sans, color: B.ink, width: '100%' }}>
      <BNav />
      <BHero />
      <BNumbers />
      <BProducts />
      <BProcess />
      <BFacility />
      <BCertifications />
      <BStory />
      <BReach />
      <BCTA />
      <BFooter />
    </div>
  );
}

window.VariantB = VariantB;
