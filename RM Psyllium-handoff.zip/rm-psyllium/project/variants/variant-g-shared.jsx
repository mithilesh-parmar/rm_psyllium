// Variant G — "Pure"
// Light, minimal, story-driven. White + cream + sage. Newsreader + Geist.
// Plant & Machinery deep-dive, chapter storytelling, motion.dev-style micro-interactions.
//
// SHARED HELPERS — Reveal, Counter, hooks, palette, fonts.
// Component sections live in variant-g-sections.jsx.

const G = {
  white: '#ffffff',
  paper: '#fafaf7',
  cream: '#f5f3ec',
  creamDeep: '#ece9df',
  ink: '#1a1c18',
  inkSoft: '#4a4f44',
  inkMute: '#7a7e72',
  rule: 'rgba(26,28,24,0.10)',
  ruleSoft: 'rgba(26,28,24,0.05)',
  sage: '#5f7044',
  sageDeep: '#42542c',
  sagePale: '#dfe4cf',
  warm: '#b8753a',
  warmPale: '#f1dfc8',
};

const gFont = {
  display: '"Newsreader", "Instrument Serif", Georgia, serif',
  body: '"Geist", -apple-system, BlinkMacSystemFont, system-ui, sans-serif',
  mono: '"Geist Mono", "JetBrains Mono", ui-monospace, monospace',
};

(function ensureGFonts() {
  if (document.getElementById('g-fonts')) return;
  const link = document.createElement('link');
  link.id = 'g-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,300;0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Geist:wght@300;400;500;600&family=Geist+Mono:wght@400;500&display=swap';
  document.head.appendChild(link);
})();

// keyframes + utility CSS injected once
(function ensureGKeyframes() {
  if (document.getElementById('g-keyframes')) return;
  const s = document.createElement('style');
  s.id = 'g-keyframes';
  s.textContent = `
    @keyframes g-rise { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    @keyframes g-fade { from{opacity:0} to{opacity:1} }
    @keyframes g-marquee { from{transform:translateX(0)} to{transform:translateX(-50%)} }
    @keyframes g-pulse { 0%,100%{transform:scale(1);opacity:.9} 50%{transform:scale(1.06);opacity:1} }
    @keyframes g-spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
    @keyframes g-shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
    @keyframes g-blink { 0%,55%{opacity:1} 60%,100%{opacity:0.25} }
    @keyframes g-drift { 0%,100%{transform:translate(0,0)} 50%{transform:translate(2%,-2%)} }
    @keyframes g-flow { 0%{left:0%;opacity:0} 4%{opacity:1} 96%{opacity:1} 100%{left:100%;opacity:0} }
    @keyframes g-stage-glow {
      0%, 90%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(95,112,68,0); border-color: rgba(95,112,68,0.4); background: #ffffff; }
      4% { transform: scale(1.12); box-shadow: 0 0 0 6px rgba(95,112,68,0.18); border-color: #5f7044; background: #ffffff; }
      8% { transform: scale(1); box-shadow: 0 0 0 0 rgba(95,112,68,0); border-color: #5f7044; }
    }
    @keyframes g-phase-shift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .g-card { transition: transform .35s cubic-bezier(.2,.7,.3,1), box-shadow .35s, border-color .25s; }
    .g-card:hover { transform: translateY(-4px); box-shadow: 0 18px 40px -22px rgba(26,28,24,0.25); }

    .g-cta { transition: transform .25s cubic-bezier(.2,.7,.3,1), box-shadow .25s, background .2s, color .2s; }
    .g-cta:hover { transform: translateY(-2px); box-shadow: 0 14px 28px -16px rgba(95,112,68,0.6); }
    .g-cta-ghost:hover { background: rgba(26,28,24,0.04); }

    .g-link { position: relative; }
    .g-link::after { content: ''; position: absolute; left: 0; right: 0; bottom: -3px; height: 1px; background: currentColor; transform: scaleX(0); transform-origin: left; transition: transform .35s cubic-bezier(.2,.7,.3,1); }
    .g-link:hover::after { transform: scaleX(1); }

    .g-nav-link { transition: color .2s; position: relative; }
    .g-nav-link::after { content: ''; position: absolute; left: 0; right: 0; bottom: -6px; height: 1px; background: currentColor; transform: scaleX(0); transform-origin: center; transition: transform .3s cubic-bezier(.2,.7,.3,1); }
    .g-nav-link:hover::after { transform: scaleX(1); }

    .g-chip { transition: background .2s, color .2s, border-color .2s; cursor: pointer; }
    .g-chip:hover { background: #1a1c18; color: #fafaf7; border-color: #1a1c18; }

    .g-row { transition: background .2s; }
    .g-row:hover { background: rgba(95,112,68,0.05); }
    .g-row:hover .g-row-arrow { transform: translateX(6px); opacity: 1; }
    .g-row-arrow { transition: transform .25s cubic-bezier(.2,.7,.3,1), opacity .25s; opacity: 0; }

    .g-equip { transition: transform .4s cubic-bezier(.2,.7,.3,1), box-shadow .4s; }
    .g-equip:hover { transform: translateY(-6px); box-shadow: 0 22px 50px -28px rgba(26,28,24,0.3); }
    .g-equip:hover .g-equip-img { transform: scale(1.04); }
    .g-equip-img { transition: transform .6s cubic-bezier(.2,.7,.3,1); }

    .g-input { transition: border-color .2s, background .2s; }
    .g-input:focus { outline: none; border-color: #5f7044; background: #fff; }

    .g-grad-shimmer {
      background: linear-gradient(90deg, transparent 0%, rgba(26,28,24,0.04) 50%, transparent 100%);
      background-size: 200% 100%;
      animation: g-shimmer 3s linear infinite;
    }
  `;
  document.head.appendChild(s);
})();

// useInView — observe ref, set true when intersecting. Runs once by default.
function useInView(opts = {}) {
  const { threshold = 0.15, once = true, rootMargin = '0px 0px -10% 0px' } = opts;
  const ref = React.useRef(null);
  const [inView, setInView] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!('IntersectionObserver' in window)) { setInView(true); return; }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setInView(true);
        if (once) io.disconnect();
      } else if (!once) {
        setInView(false);
      }
    }, { threshold, rootMargin });
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, once, rootMargin]);
  return [ref, inView];
}

// <Reveal> — fade-up wrapper. Falls back to instant if reduced motion / no observer.
function Reveal({ children, delay = 0, y = 20, as: As = 'div', style = {}, ...rest }) {
  const [ref, inView] = useInView();
  return (
    <As
      ref={ref}
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? 'translateY(0)' : `translateY(${y}px)`,
        transition: `opacity .9s cubic-bezier(.2,.7,.3,1) ${delay}ms, transform .9s cubic-bezier(.2,.7,.3,1) ${delay}ms`,
        ...style,
      }}
      {...rest}
    >
      {children}
    </As>
  );
}

// <Counter> — animates number from 0 → target when in view.
function Counter({ to, duration = 1600, suffix = '', prefix = '', decimals = 0, style }) {
  const [ref, inView] = useInView();
  const [val, setVal] = React.useState(0);
  React.useEffect(() => {
    if (!inView) return;
    let raf, start;
    const target = parseFloat(to);
    const tick = (t) => {
      if (!start) start = t;
      const p = Math.min((t - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to, duration]);
  const display = decimals > 0 ? val.toFixed(decimals) : Math.round(val).toLocaleString();
  return <span ref={ref} style={style}>{prefix}{display}{suffix}</span>;
}

// Placeholder photo for variant G — soft, light, off-white with mono tag.
function GPlaceholder({ label, h, tone = 'cream', ratio }) {
  const palettes = {
    cream: { bg: G.cream, stripe: 'rgba(26,28,24,0.06)', fg: 'rgba(26,28,24,0.55)' },
    sage: { bg: G.sagePale, stripe: 'rgba(66,84,44,0.18)', fg: 'rgba(26,28,24,0.65)' },
    warm: { bg: G.warmPale, stripe: 'rgba(184,117,58,0.22)', fg: 'rgba(26,28,24,0.6)' },
    paper: { bg: G.paper, stripe: 'rgba(26,28,24,0.05)', fg: 'rgba(26,28,24,0.5)' },
  };
  const p = palettes[tone] || palettes.cream;
  const style = {
    width: '100%',
    background: p.bg,
    position: 'relative',
    overflow: 'hidden',
    backgroundImage: `repeating-linear-gradient(135deg, ${p.stripe} 0 1px, transparent 1px 18px)`,
  };
  if (ratio) style.aspectRatio = ratio;
  if (h) style.height = h;
  return (
    <div style={style}>
      <div style={{
        position: 'absolute', left: 16, bottom: 14,
        fontFamily: gFont.mono, fontSize: 10, letterSpacing: '0.18em',
        textTransform: 'uppercase', color: p.fg,
      }}>{label}</div>
    </div>
  );
}

// Make helpers available globally for variant-g-sections.jsx
Object.assign(window, { G, gFont, useInView, Reveal, Counter, GPlaceholder });
