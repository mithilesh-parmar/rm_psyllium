// Variant F — "Aurora"
// Bold disruptor. Animated gradient mesh hero (CSS), Space Grotesk + Mono.
// Bleeding-edge SaaS energy, but rooted in green + warm yellow.

const F = {
  bg: '#06120a',
  bgDeep: '#040b06',
  chalk: '#eef1e3',
  yellow: '#fde047',
  lime: '#a3e635',
  pink: '#ff7676',
  blue: '#7ab8ff',
  rule: 'rgba(238,241,227,0.16)',
  mute: 'rgba(238,241,227,0.65)',
};

const fFont = {
  display: '"Space Grotesk", -apple-system, system-ui, sans-serif',
  body: '"Space Grotesk", -apple-system, system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
};

(function ensureFFonts() {
  if (document.getElementById('f-fonts')) return;
  const link = document.createElement('link');
  link.id = 'f-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap';
  document.head.appendChild(link);
})();

(function ensureFKeyframes() {
  if (document.getElementById('f-keyframes')) return;
  const s = document.createElement('style');
  s.id = 'f-keyframes';
  s.textContent = `
    @keyframes f-blob-a { 0%,100%{transform:translate(0,0) scale(1)} 33%{transform:translate(8%,-6%) scale(1.15)} 66%{transform:translate(-6%,4%) scale(0.95)} }
    @keyframes f-blob-b { 0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(-10%,8%) scale(1.2)} }
    @keyframes f-blob-c { 0%,100%{transform:translate(0,0) scale(1)} 40%{transform:translate(6%,10%) scale(1.1)} 80%{transform:translate(-8%,-4%) scale(0.9)} }
    @keyframes f-blob-d { 0%,100%{transform:translate(0,0) scale(0.9)} 45%{transform:translate(-4%,-10%) scale(1.25)} }
    @keyframes f-fade-up { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    @keyframes f-marquee { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
    @keyframes f-blink { 0%,55%{opacity:1} 60%,100%{opacity:0.3} }
    @keyframes f-glow { 0%,100%{box-shadow:0 0 30px rgba(253,224,71,0.3)} 50%{box-shadow:0 0 60px rgba(253,224,71,0.5)} }
    @keyframes f-spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
  `;
  document.head.appendChild(s);
})();

function FAuroraMesh({ height = 760 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, overflow: 'hidden',
      background: F.bg, filter: 'blur(0px)',
    }}>
      {/* Four soft blobs that drift on independent loops. */}
      <div style={{
        position: 'absolute', top: '-10%', left: '-10%', width: '60%', height: '70%',
        background: 'radial-gradient(circle at 40% 40%, rgba(163,230,53,0.55) 0%, transparent 60%)',
        filter: 'blur(80px)',
        animation: 'f-blob-a 18s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute', top: '20%', right: '-15%', width: '55%', height: '65%',
        background: 'radial-gradient(circle at 50% 50%, rgba(253,224,71,0.45) 0%, transparent 60%)',
        filter: 'blur(80px)',
        animation: 'f-blob-b 22s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute', bottom: '-20%', left: '20%', width: '50%', height: '60%',
        background: 'radial-gradient(circle at 50% 50%, rgba(122,184,255,0.32) 0%, transparent 60%)',
        filter: 'blur(90px)',
        animation: 'f-blob-c 26s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute', bottom: '-15%', right: '-10%', width: '45%', height: '55%',
        background: 'radial-gradient(circle at 50% 50%, rgba(255,118,118,0.28) 0%, transparent 60%)',
        filter: 'blur(90px)',
        animation: 'f-blob-d 20s ease-in-out infinite',
      }} />
      {/* faint grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(rgba(238,241,227,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(238,241,227,0.06) 1px, transparent 1px)`,
        backgroundSize: '64px 64px',
        opacity: 0.6,
      }} />
      {/* grain */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'radial-gradient(rgba(238,241,227,0.04) 1px, transparent 1px)',
        backgroundSize: '3px 3px', mixBlendMode: 'overlay',
      }} />
    </div>
  );
}

function FLogo() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 36, height: 36, borderRadius: 12, background: F.yellow, color: F.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: fFont.display, fontSize: 17, fontWeight: 700, letterSpacing: '-0.05em',
        animation: 'f-glow 4s ease-in-out infinite',
      }}>RM</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <div style={{ fontFamily: fFont.display, fontSize: 17, color: F.chalk, fontWeight: 600, letterSpacing: '-0.02em' }}>RM Psyllium</div>
        <div style={{ fontFamily: fFont.mono, fontSize: 9, color: F.chalk, opacity: 0.55, letterSpacing: '0.2em', marginTop: 3 }}>NEW · STANDARD · 2026</div>
      </div>
    </div>
  );
}

function FNav() {
  const link = { fontFamily: fFont.display, fontSize: 13, color: F.chalk, textDecoration: 'none', fontWeight: 500 };
  return (
    <nav style={{
      position: 'relative', zIndex: 10,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '22px 48px', backdropFilter: 'blur(12px)',
      background: 'rgba(6,18,10,0.4)',
      borderBottom: `1px solid ${F.rule}`,
    }}>
      <FLogo />
      <div style={{ display: 'flex', gap: 28 }}>
        {['Products', 'Quality', 'Facility', 'For pharma', 'For food', 'Talk'].map(t => (
          <a key={t} href="#" style={link}>{t}</a>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <a href="#" style={{ fontFamily: fFont.display, fontSize: 13, color: F.chalk, opacity: 0.7, textDecoration: 'none' }}>Sign in</a>
        <a href="#" style={{
          fontFamily: fFont.display, fontSize: 13, color: F.bg, background: F.yellow,
          padding: '10px 18px', borderRadius: 999, textDecoration: 'none', fontWeight: 600,
        }}>Book a call →</a>
      </div>
    </nav>
  );
}

function FHero() {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', minHeight: 880 }}>
      <FAuroraMesh height={880} />
      <div style={{ position: 'relative', zIndex: 2 }}>
        <FNav />
        <div style={{ padding: '88px 48px 96px', textAlign: 'center', animation: 'f-fade-up 1.2s ease-out' }}>
          {/* Pill */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            fontFamily: fFont.mono, fontSize: 11, letterSpacing: '0.18em',
            color: F.chalk, padding: '8px 16px',
            background: 'rgba(238,241,227,0.08)',
            border: `1px solid ${F.rule}`, borderRadius: 999,
            backdropFilter: 'blur(8px)',
          }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: F.lime, animation: 'f-blink 1.6s ease-in-out infinite' }}></span>
            2026 SOURCING WINDOW · OPEN · Q3 BOOKINGS LIVE
          </div>

          <h1 style={{
            fontFamily: fFont.display, fontSize: 180, lineHeight: 0.86, color: F.chalk,
            margin: '32px auto 0', letterSpacing: '-0.06em', fontWeight: 500, maxWidth: 1300,
          }}>
            Psyllium,<br/>
            <span style={{
              background: 'linear-gradient(135deg, #fde047 0%, #a3e635 50%, #7ab8ff 100%)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text', fontStyle: 'italic',
            }}>reimagined</span><br/>
            from the seed.
          </h1>

          <p style={{
            fontFamily: fFont.display, fontSize: 22, color: F.chalk, opacity: 0.78,
            margin: '36px auto 0', maxWidth: 760, lineHeight: 1.45, fontWeight: 400,
          }}>
            A new 12,000&nbsp;MT facility in Unjha, India. Software-controlled
            milling, NIR fingerprint per batch, COA on your invoice. The
            commodity, finally treated like a product.
          </p>

          <div style={{ display: 'inline-flex', gap: 14, marginTop: 44, alignItems: 'center' }}>
            <a href="#" style={{
              fontFamily: fFont.display, fontSize: 16, fontWeight: 600,
              color: F.bg, background: F.yellow,
              padding: '18px 32px', borderRadius: 999, textDecoration: 'none', letterSpacing: '-0.01em',
            }}>Book a 20-min call →</a>
            <a href="#" style={{
              fontFamily: fFont.display, fontSize: 16, fontWeight: 500,
              color: F.chalk, padding: '18px 24px', textDecoration: 'none',
              background: 'rgba(238,241,227,0.08)', border: `1px solid ${F.rule}`,
              borderRadius: 999, backdropFilter: 'blur(8px)',
              display: 'inline-flex', alignItems: 'center', gap: 10,
            }}>
              <span style={{
                width: 24, height: 24, borderRadius: '50%', background: F.chalk, color: F.bg,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10,
              }}>▶</span>
              Watch the 3-min film
            </a>
          </div>

          {/* trust row */}
          <div style={{ marginTop: 64, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 32, opacity: 0.85 }}>
            {['ISO 22000', 'FSSAI', 'HACCP', 'GMP', 'USP / EP', 'BRCGS-ready', 'Non-GMO'].map(t => (
              <span key={t} style={{
                fontFamily: fFont.mono, fontSize: 12, color: F.chalk, letterSpacing: '0.16em',
                display: 'inline-flex', alignItems: 'center', gap: 8,
              }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: F.lime }}></span>
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* floating spec card */}
        <div style={{
          position: 'absolute', right: 48, top: 200,
          background: 'rgba(6,18,10,0.6)',
          backdropFilter: 'blur(16px)',
          border: `1px solid ${F.rule}`,
          borderRadius: 16, padding: '20px 22px', width: 260,
          animation: 'f-fade-up 1.6s ease-out',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <span style={{ fontFamily: fFont.mono, fontSize: 10, letterSpacing: '0.18em', color: F.lime }}>● LIVE QC</span>
            <span style={{ fontFamily: fFont.mono, fontSize: 10, opacity: 0.5, letterSpacing: '0.14em', color: F.chalk }}>14:48 IST</span>
          </div>
          <div style={{ fontFamily: fFont.display, fontSize: 22, color: F.chalk, fontWeight: 600, letterSpacing: '-0.02em' }}>Lot RM-26-0512</div>
          <div style={{ fontFamily: fFont.mono, fontSize: 11, color: F.chalk, opacity: 0.6, letterSpacing: '0.1em', marginTop: 4 }}>Husk · 99% · mesh 40</div>
          <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${F.rule}`, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[['Purity', '99.4%'], ['Swelling', '47.2'], ['Moisture', '8.1%'], ['Ash', '2.4%']].map(([k, v]) => (
              <div key={k}>
                <div style={{ fontFamily: fFont.mono, fontSize: 9, color: F.chalk, opacity: 0.5, letterSpacing: '0.16em' }}>{k.toUpperCase()}</div>
                <div style={{ fontFamily: fFont.display, fontSize: 18, color: F.yellow, fontWeight: 600 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* floating capacity badge */}
        <div style={{
          position: 'absolute', left: 48, top: 240,
          width: 160, height: 160, borderRadius: '50%',
          border: `1px solid ${F.rule}`,
          background: 'rgba(6,18,10,0.4)',
          backdropFilter: 'blur(12px)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          animation: 'f-fade-up 1.8s ease-out',
        }}>
          <div style={{ fontFamily: fFont.display, fontSize: 48, color: F.chalk, fontWeight: 600, letterSpacing: '-0.04em' }}>12k</div>
          <div style={{ fontFamily: fFont.mono, fontSize: 10, color: F.lime, letterSpacing: '0.2em', marginTop: 4 }}>MT / YR</div>
          <div style={{ fontFamily: fFont.mono, fontSize: 9, color: F.chalk, opacity: 0.5, letterSpacing: '0.16em', marginTop: 6 }}>FACILITY · LIVE</div>
        </div>
      </div>
    </section>
  );
}

function FMarquee() {
  const items = ['● ISO 22000', '● FSSAI', '● HACCP', '● GMP', '● USDA Organic*', '● EU Organic*', '● Kosher*', '● Halal*', '● BRCGS-ready', '● Non-GMO', '● USP / EP'];
  return (
    <section style={{ background: F.yellow, color: F.bg, padding: '18px 0', overflow: 'hidden' }}>
      <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'f-marquee 35s linear infinite', fontFamily: fFont.display, fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em' }}>
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i} style={{ paddingRight: 48 }}>{t}</span>
        ))}
      </div>
    </section>
  );
}

function FNumbers() {
  return (
    <section style={{ padding: '120px 48px', background: F.bgDeep, color: F.chalk, position: 'relative', overflow: 'hidden' }}>
      <div style={{
        position: 'absolute', top: '-30%', right: '-15%', width: '60%', height: '120%',
        background: 'radial-gradient(circle, rgba(253,224,71,0.12) 0%, transparent 60%)',
        filter: 'blur(60px)',
      }} />
      <div style={{ position: 'relative', zIndex: 2 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 20, borderTop: `2px solid ${F.chalk}`, paddingTop: 18, marginBottom: 48 }}>
          <span style={{ fontFamily: fFont.mono, fontSize: 12, letterSpacing: '0.22em', color: F.yellow }}>01 — RECEIPTS</span>
          <span style={{ fontFamily: fFont.mono, fontSize: 12, color: F.mute, letterSpacing: '0.16em' }}>Updated 2026-05-13 · weekly sync</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
          {[
            ['12,000', 'MT', 'Annual capacity'],
            ['4,500', 'ac', 'Contract farms'],
            ['38', 'mkt', 'Export countries'],
            ['47', 'tests', 'Per COA'],
          ].map(([n, u, l], i) => (
            <div key={i} style={{
              background: 'rgba(238,241,227,0.04)', border: `1px solid ${F.rule}`,
              borderRadius: 20, padding: '32px 28px',
              backdropFilter: 'blur(8px)',
            }}>
              <div style={{ fontFamily: fFont.mono, fontSize: 11, color: F.mute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{l}</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 18 }}>
                <span style={{ fontFamily: fFont.display, fontSize: 96, fontWeight: 500, color: F.chalk, letterSpacing: '-0.06em', lineHeight: 0.95 }}>{n}</span>
                <span style={{ fontFamily: fFont.mono, fontSize: 14, color: F.yellow, letterSpacing: '0.14em' }}>{u}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FProducts() {
  const items = [
    { n: 'Husk · 99%', tag: 'PHARMA', color: F.yellow },
    { n: 'Husk · 98%', tag: 'PREMIUM', color: F.lime },
    { n: 'Husk · 95%', tag: 'GENERAL', color: F.chalk },
    { n: 'Husk Powder', tag: 'FOOD', color: F.chalk },
    { n: 'Whole Seed', tag: 'BULK', color: F.chalk },
    { n: 'Industrial', tag: 'TECH', color: F.pink },
    { n: 'Pharma Grade', tag: 'USP/EP', color: F.yellow },
    { n: 'Food Grade', tag: 'BRCGS', color: F.lime },
    { n: 'Organic', tag: 'USDA*', color: F.lime },
  ];
  return (
    <section style={{ padding: '120px 48px', background: F.bg, color: F.chalk }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 20, borderTop: `2px solid ${F.chalk}`, paddingTop: 18, marginBottom: 32 }}>
        <span style={{ fontFamily: fFont.mono, fontSize: 12, letterSpacing: '0.22em', color: F.yellow }}>02 — THE RANGE</span>
        <span style={{ fontFamily: fFont.mono, fontSize: 12, color: F.mute, letterSpacing: '0.16em' }}>09 grades · 1 species · 0 blends</span>
      </div>
      <h2 style={{
        fontFamily: fFont.display, fontSize: 140, color: F.chalk, margin: 0,
        letterSpacing: '-0.06em', fontWeight: 500, lineHeight: 0.88,
      }}>
        Built for<br/><span style={{
          background: 'linear-gradient(135deg, #fde047 0%, #a3e635 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          fontStyle: 'italic',
        }}>every line.</span>
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginTop: 64 }}>
        {items.map((p, i) => (
          <article key={i} style={{
            position: 'relative', overflow: 'hidden',
            background: 'rgba(238,241,227,0.04)', border: `1px solid ${F.rule}`,
            borderRadius: 24, padding: '32px 28px', minHeight: 220,
            display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
              <span style={{
                fontFamily: fFont.mono, fontSize: 10, color: F.bg, background: p.color,
                padding: '5px 10px', borderRadius: 999, letterSpacing: '0.16em', fontWeight: 600,
              }}>{p.tag}</span>
              <span style={{ fontFamily: fFont.mono, fontSize: 11, color: F.mute, letterSpacing: '0.14em' }}>0{i + 1}/09</span>
            </div>
            <div>
              <div style={{ fontFamily: fFont.display, fontSize: 36, fontWeight: 500, color: F.chalk, letterSpacing: '-0.03em', lineHeight: 1 }}>{p.n}</div>
              <div style={{ marginTop: 18, paddingTop: 14, borderTop: `1px solid ${F.rule}`, display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: fFont.mono, fontSize: 11, color: F.mute, letterSpacing: '0.14em' }}>SPEC · COA · QUOTE</span>
                <span style={{ fontFamily: fFont.display, fontSize: 14, color: F.yellow, fontWeight: 600 }}>Open →</span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function FCTA() {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', minHeight: 560, background: F.bgDeep }}>
      <FAuroraMesh height={560} />
      <div style={{ position: 'relative', zIndex: 2, padding: '120px 48px', textAlign: 'center' }}>
        <div style={{ fontFamily: fFont.mono, fontSize: 12, letterSpacing: '0.22em', color: F.lime }}>● TALK TO US</div>
        <h2 style={{
          fontFamily: fFont.display, fontSize: 180, color: F.chalk, margin: '24px 0',
          letterSpacing: '-0.06em', fontWeight: 500, lineHeight: 0.86,
        }}>
          Book.<br/>
          <span style={{
            background: 'linear-gradient(135deg, #fde047 0%, #a3e635 50%, #7ab8ff 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            fontStyle: 'italic',
          }}>The call.</span>
        </h2>
        <p style={{ fontFamily: fFont.display, fontSize: 20, color: F.chalk, opacity: 0.8, maxWidth: 580, margin: '0 auto', lineHeight: 1.5, fontWeight: 400 }}>
          Twenty minutes. Sample dispatched the same day. Indicative landed
          price before the call ends. That's the offer.
        </p>
        <div style={{ display: 'inline-flex', gap: 14, marginTop: 40 }}>
          <a href="#" style={{
            fontFamily: fFont.display, fontSize: 18, fontWeight: 600,
            color: F.bg, background: F.yellow,
            padding: '20px 36px', borderRadius: 999, textDecoration: 'none', letterSpacing: '-0.01em',
            animation: 'f-glow 3s ease-in-out infinite',
          }}>Pick a time →</a>
          <a href="#" style={{
            fontFamily: fFont.display, fontSize: 18, fontWeight: 500, color: F.chalk,
            padding: '20px 32px', borderRadius: 999, textDecoration: 'none', letterSpacing: '-0.01em',
            background: 'rgba(238,241,227,0.08)', border: `1px solid ${F.rule}`, backdropFilter: 'blur(8px)',
          }}>WhatsApp the desk</a>
        </div>
        <div style={{ marginTop: 36, display: 'inline-flex', gap: 40, fontFamily: fFont.mono, fontSize: 12, color: F.chalk, opacity: 0.7, letterSpacing: '0.16em' }}>
          <span>● 4 hr avg response</span>
          <span>● export@rmpsyllium.com</span>
          <span>● +91 2767 333 444</span>
        </div>
      </div>
    </section>
  );
}

function FFooter() {
  return (
    <footer style={{ background: F.bgDeep, color: F.chalk, padding: '64px 48px 28px', borderTop: `1px solid ${F.rule}` }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 48 }}>
        <div>
          <FLogo />
          <p style={{ fontFamily: fFont.display, fontSize: 14, opacity: 0.7, lineHeight: 1.6, marginTop: 20, maxWidth: 320, fontWeight: 400 }}>
            RM Psyllium Pvt. Ltd. · Survey 412/3, GIDC Phase II, Unjha, Mehsana, Gujarat 384170, India
          </p>
        </div>
        {[
          ['Products', ['Husk 99%', 'Husk 98%', 'Husk 95%', 'Powder', 'Pharma', 'Industrial', 'Organic']],
          ['Company', ['Story', 'Facility', 'Sustainability', 'Journal']],
          ['Contact', ['+91 2767 333 444', 'export@rmpsyllium.com', 'WhatsApp', 'Book a call']],
        ].map(([h, items], i) => (
          <div key={i}>
            <div style={{ fontFamily: fFont.mono, fontSize: 10, letterSpacing: '0.22em', opacity: 0.6, textTransform: 'uppercase' }}>{h}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
              {items.map((t, j) => (
                <a key={j} href="#" style={{ fontFamily: fFont.display, fontSize: 14, color: F.chalk, opacity: 0.85, textDecoration: 'none' }}>{t}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 48, paddingTop: 18, borderTop: `1px solid ${F.rule}`,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: fFont.mono, fontSize: 10, opacity: 0.55, letterSpacing: '0.18em',
      }}>
        <span>© 2026 RM PSYLLIUM PVT LTD</span>
        <span>PRIVACY · TERMS · COOKIES</span>
      </div>
    </footer>
  );
}

function VariantF() {
  return (
    <div style={{ background: F.bg, fontFamily: fFont.body, color: F.chalk, width: '100%' }}>
      <FHero />
      <FMarquee />
      <FNumbers />
      <FProducts />
      <FCTA />
      <FFooter />
    </div>
  );
}

window.VariantF = VariantF;
